<?php

	/*	

	*	crunchpress Sidebar Generator

	*	---------------------------------------------------------------------

	*	This file create the class that help you to controls the sidebar 

	*	at the appearance > widget area

	*	---------------------------------------------------------------------

	*/

	

	if( !class_exists('word_mag_sidebar_generator') ){

		

		class word_mag_sidebar_generator{

			

			var $option_name = 'word_mag_sidebar_name';

			

			var $word_mag_sidebars = array();

			var $footer_widgets = array();

			

			function __construct(){

				global $pagenow;

				if( is_admin() && $pagenow == 'customize.php' ) return;

				

				
				

				$this->sidebars = get_option($this->option_name, array());

				if( !is_array($this->sidebars) ){ $this->sidebars = array(); }

				

				$this->register_sidebar();

				

				// add the script when opening the admin widget section

				add_action('load-widgets.php', array(&$this, 'load_admin_script') );

				add_action('load-widgets.php', array(&$this, 'load_admin_script') );

				

				// set the hook for adding/removing sidebar

				add_action('wp_ajax_word_mag_add_sidebar', array(&$this, 'word_mag_add_sidebar'));	

				add_action('wp_ajax_word_mag_remove_sidebar', array(&$this, 'word_mag_remove_sidebar'));	

								

			}

			

			// register sidebar to use in widget area

			function register_sidebar(){

			

				$args = array(

					'before_widget' => '<div id="%1$s" class="widget %2$s cp-item cp-widget">',
					'after_widget'  => '</span></div></div>',
					'before_title'  => '<div class="titleborder"><h3 class="cp-widget-title"><span>',
					'after_title'   => '</h3></div><div class="clear"></div><div class="widgetinnter">' );		



				// sidebar for footer section

				$footer_args = apply_filters('word_mag_footer_widget_args', array());

				$footer_args = wp_parse_args($footer_args, $args);

				foreach ( $this->footer_widgets as $widget ){

					if( !is_array($widget) ){

						$footer_args['name'] = $widget;

						$footer_args['description'] = esc_html__('Custom widget area', 'word-mag');

					}else{

						$footer_args['name'] = $widget['name'];

						$footer_args['description'] = $widget['description'];

					}

					

					register_sidebar($footer_args);

				}

				

				// sidebar for content section

				$word_mag_sidebar_args = apply_filters('word_mag_sidebar_widget_args', array());

				$word_mag_sidebar_args = wp_parse_args($word_mag_sidebar_args, $args);				

				$word_mag_sidebar_args['class'] = 'cp-dynamic';

				foreach ( $this->sidebars as $word_mag_sidebar ){

					$word_mag_sidebar_args['name'] = $word_mag_sidebar;

					$word_mag_sidebar_args['description'] = esc_html__('Custom widget area', 'word-mag');

					

					register_sidebar($word_mag_sidebar_args);

				}

				

			}

			

			// load the necessary script for the sidebar creator item

			function load_admin_script(){

				

				// include the sidebar generator style

				wp_enqueue_style('cp-alert-box', GDLR_PATH . '/framework/stylesheet/cp-alert-box.css');

				wp_enqueue_style('cp-sidebar-generator', GDLR_PATH . '/framework/stylesheet/cp-sidebar-generator.css');

			

				// include the sidebar generator script

				wp_enqueue_script('cp-alert-box', GDLR_PATH . '/framework/javascript/cp-alert-box.js');

				wp_enqueue_script('cp-sidebar-generator', GDLR_PATH . '/framework/javascript/cp-sidebar-generator.js');

				

				// execute the sidebar generator script

				add_action('admin_print_scripts', array(&$this, 'word_mag_create_sidebar_script') );

				

			}

			

			// add the necessary variable for ajax purpose

			function word_mag_create_sidebar_script(){

?>
<script type="text/javascript"> 

var word_mag_nonce = "<?php echo wp_create_nonce(THEME_SHORT_NAME . '-create-nonce'); ?>";

var word_mag_title = "<?php esc_html_e('Create New Sidebar' ,'word-mag'); ?>";

var word_mag_ajax = "<?php echo AJAX_URL; ?>";

</script>
<?php

			}

			

			// add new sidebar ajax module

			function word_mag_add_sidebar(){

				if( !check_ajax_referer(THEME_SHORT_NAME . '-create-nonce', 'security', false) ){

					die(json_encode(array(

						'status'=>'failed', 

						'message'=> '<span class="head">' . esc_html__('Invalid Nonce', 'word-mag') . '</span> ' .

							esc_html__('Please refresh the page and try this again.' ,'word-mag')

					)));

				}

				

				if( isset($_POST['sidebar_name']) ){		

					

					if( !in_array(trim($_POST['sidebar_name']), $this->sidebars) ){

						

						array_push($this->sidebars, word_mag_stripslashes(trim($_POST['sidebar_name'])));

						

						if( update_option($this->option_name, $this->sidebars) ){

							$ret = array(

								'status'=> 'success'

							);		

						}else{

							$ret = array(

								'status'=> 'failed', 

								'message'=> '<span class="head">' . esc_html__('Save Sidebar Failed', 'word-mag') . '</span> ' .

								esc_html__('Please try creating the sidebar again with different name.' ,'word-mag')

							);						

						}

	

					}else{

						$ret = array(

							'status'=> 'failed', 

							'message'=> '<span class="head">' . esc_html__('Duplicated Sidebar Name', 'word-mag') . '</span> ' .

							esc_html__('Please try creating the sidebar again with different name.' ,'word-mag')

						);					

					}

				}else{

					$ret = array(

						'status'=>'failed', 

						'message'=> '<span class="head">' . esc_html__('Cannot Retrieve Sidebar Name', 'word-mag') . '</span> ' .

							esc_html__('Please refresh the page and try this again.' ,'word-mag')

					);	

				}

				

				die(json_encode($ret));

			}	



			// add new sidebar ajax module

			function word_mag_remove_sidebar(){

				if( !check_ajax_referer(THEME_SHORT_NAME . '-create-nonce', 'security', false) ){

					die(json_encode(array(

						'status'=>'failed', 

						'message'=> '<span class="head">' . esc_html__('Invalid Nonce', 'word-mag') . '</span> ' .

							esc_html__('Please refresh the page and try this again.' ,'word-mag')

					)));

				}

				

				if( isset($_POST['sidebar_name']) ){		

				

					$current_sidebar = word_mag_stripslashes(trim(strip_tags($_POST['sidebar_name'])));

					

					$key = array_search($current_sidebar, $this->sidebars);

					unset($this->sidebars[$key]);

					

					if( update_option($this->option_name, $this->sidebars) ){

						$ret = array(

							'status'=> 'success'

						);		

					}else{

						$ret = array(

							'status'=> 'failed', 

							'message'=> '<span class="head">' . esc_html__('Save Failed', 'word-mag') . '</span> ' .

							esc_html__('Please try again.' ,'word-mag')

						);						

					}

				}else{

					$ret = array(

						'status'=>'failed', 

						'message'=> '<span class="head">' . esc_html__('Cannot Retrieve Sidebar Name', 'word-mag') . '</span> ' .

							esc_html__('Please try again.' ,'word-mag')

					);	

				}

				

				die(json_encode($ret));

			}



			// get all sidebar array

			function get_sidebar_array(){

				$ret = array();



				foreach ( $GLOBALS['wp_registered_sidebars'] as $word_mag_sidebar ) {

					if( !in_array( $word_mag_sidebar['name'], $this->footer_widgets ) ){

						$ret[$word_mag_sidebar['name']] = $word_mag_sidebar['name'];

					}

				}

				return $ret;

			}



		}

		

	}

	



?>