<?php

	/*	
	*	CrunchPress Brands Option File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		CrunchPress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) CrunchPress
	*	---------------------------------------------------------------------
	*	This file create and contains the portfolio post_type meta elements
	*	---------------------------------------------------------------------
	*/ 
	
	add_action( 'init', 'create_brand' );
	function create_brand() {
		$artist_translation = get_option(PLUGIN_NAME_S.'_cp_brand_slug','brand');
		
		$labels = array(
			'name' => _x('Brands', 'Brand General Name', 'crunchpress'),
			'singular_name' => _x('Brand Item', 'Brand Singular Name', 'crunchpress'),
			'add_new' => _x('Add New', 'Add New Brand Name', 'crunchpress'),
			'add_new_item' => __('Add New Brand', 'crunchpress'),
			'edit_item' => __('Edit Brand', 'crunchpress'),
			'new_item' => __('New Brand', 'crunchpress'),
			'view_item' => __('View Brand', 'crunchpress'),
			'search_items' => __('Search Brand', 'crunchpress'),
			'not_found' =>  __('Nothing found', 'crunchpress'),
			'not_found_in_trash' => __('Nothing found in Trash', 'crunchpress'),
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			//'menu_icon' => CP_PATH_URL . '/framework/images/artist-icon.png',
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => 5,
			'supports' => array('title','thumbnail'),
			'rewrite' => array('slug' => $artist_translation, 'with_front' => false)
		  ); 
		  
		register_post_type( 'brand' , $args);
		
		
	}
	
	
function brand_link_get_meta( $value ) {
	global $post;

	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}

function brand_link_add_meta_box() {
	add_meta_box(
		'brand_link-brand-link',
		__( 'Brand Link', 'brand_link' ),
		'brand_link_brand_link_html',
		'brand',
		'normal',
		'default'
	);
}
add_action( 'add_meta_boxes', 'brand_link_add_meta_box' );

function brand_link_brand_link_html( $post) {
	wp_nonce_field( '_brand_link_brand_link_nonce', 'brand_link_brand_link_nonce' ); ?>

	<p>
		<label for="brand_link_brand_link_brand_link"><?php _e( 'Brand URL', 'brand_link' ); ?></label><br>
		<input type="text" name="brand_link_brand_link_brand_link" id="brand_link_brand_link_brand_link" value="<?php echo brand_link_get_meta( 'brand_link_brand_link_brand_link' ); ?>">
	</p><?php
}

function brand_link_brand_link_save( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! isset( $_POST['brand_link_brand_link_nonce'] ) || ! wp_verify_nonce( $_POST['brand_link_brand_link_nonce'], '_brand_link_brand_link_nonce' ) ) return;
	if ( ! current_user_can( 'edit_post' ) ) return;

	if ( isset( $_POST['brand_link_brand_link_brand_link'] ) )
		update_post_meta( $post_id, 'brand_link_brand_link_brand_link', esc_attr( $_POST['brand_link_brand_link_brand_link'] ) );
}
add_action( 'save_post', 'brand_link_brand_link_save' );

/*
	Usage: brand_link_get_meta( 'brand_link_brand_link_brand_link' )
*/


	
?>