<?php 
	/*	

	*	crunchpress Page Option File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		crunchpress
	* 	@package    Children Store
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) crunchpress
	*	---------------------------------------------------------------------
	*	This file create and contains the page post_type meta elements
	*	---------------------------------------------------------------------
	*/

	// a type that each element can be ( also set in page-dragging.js )
     
    $div_size = array(
	     'Slider' => array('element1-4'=>'1/4','element1-3'=>'1/3','element1-2'=>'1/2','element2-3'=>'2/3','element3-4'=>'3/4','element1-1'=>'1/1'),
		 'Gallery' => array('element1-4'=>'1/4','element1-3'=>'1/3','element1-2'=>'1/2','element2-3'=>'2/3','element3-4'=>'3/4','element1-1'=>'1/1'),
		 'Message-Box' => array('element1-4'=>'1/4','element1-3'=>'1/3','element1-2'=>'1/2','element2-3'=>'2/3','element3-4'=>'3/4','element1-1'=>'1/1'),
		 'Tab' => array('element1-4'=>'1/4','element1-3'=>'1/3','element1-2'=>'1/2','element2-3'=>'2/3','element3-4'=>'3/4','element1-1'=>'1/1'),
		 'Accordion' => array('element1-4'=>'1/4','element1-3'=>'1/3','element1-2'=>'1/2','element2-3'=>'2/3','element3-4'=>'3/4','element1-1'=>'1/1'),
		 'Column' => array('element1-4'=>'1/4','element1-3'=>'1/3','element1-2'=>'1/2','element2-3'=>'2/3','element3-4'=>'3/4','element1-1'=>'1/1'),
		 'Blog' => array('element1-1'=>'1/1'),
		 'Divider' => array('element1-1'=>'1/1'),
		 'Contact-Form' => array('element1-1'=>'1/1'),
		 'Testimonial' => array('element1-1'=>'1/1'),
		 'Brands' => array('element1-1'=>'1/1'),
		 'Services' => array('element1-1'=>'1/1'),
		 'Products' => array('element1-1'=>'1/1'),
		 'Banner' => array('element1-1'=>'1/1'),
		 'Client' => array('element1-1'=>'1/1'),
		 'Team' => array('element1-1'=>'1/1'),
		 
	);	
	
	
	$page_meta_boxes = array(

		"Page Item" => array(
			'item'=>'page-option-item-type' ,
			'size'=>'page-option-item-size', 
			'xml'=>'page-option-item-xml', 
			'type'=>'page-option-item',
			'name'=> array(
				'Blog'=>array(
					'blog-style'=>array(
						'title'=>'BLOG STYLE',
						'name'=>'page-option-item-blog-style',
						'options'=>array('1'=>'Advance', '2'=>'Standard'),
						'type'=>'combobox',
						),
					'category'=>array(
						'title'=>'CHOOSE CATEGORY',
						'name'=>'page-option-item-blog-category',
						'options'=>array(),
						'type'=>'combobox',
						'description'=>'Choose the post category you want to fetch the post.'),
					'num-fetch'=>array(					
						'title'=> 'BLOG NUM FETCH',
						'name'=> 'page-option-item-blog-num-fetch',
						'type'=> 'inputtext',
						'default'=> 9,
						'description'=>'This is the number of fetched item in one page.'),
					'num-excerpt'=>array(					
						'title'=> 'LENGHT OF EXCERPT',
						'name'=> 'page-option-item-blog-num-excerpt',
						'type'=> 'inputtext',
						'default'=> 285,
						'description'=>'This is the number of thumbnail content character.'),
					'show-full-blog-post'=>array(					
						'title'=> 'SHOW FULL BLOG CONTENT',
						'name'=> 'page-option-item-show-full-blog',
						'type'=> 'combobox',
						'options'=> array('No','Yes'),
						'description'=>'Select this to yes will fetch the full posts to show ( only use for the 1/1 full thumbnail blog size. ).'),						
					'pagination'=>array(
						'title'=>'ENABLE PAGINATION',
						'name'=>'page-option-item-blog-pagination',
						'type'=> 'combobox',
						'options'=>array('0'=>'Yes', '1'=>'No'),
						'hr'=> 'none',
						'description'=>'Pagination will only appear when the number of blog post is greater than the number of fetched item in one page.'),
					'description'=>array(
						'title'=> 'Advance Blog Options',
						'name'=> 'no-name',
						'type'=> 'description',
						'description'=> 'These Options Will work for Advance blog stype.',
 					
				),	
				'social-icon'=>array(					
						'title'=> 'Social icon heading',
						'name'=> 'page-option-item-social-icon',
						'type'=> 'inputtext',
						'default'=> '<h3>Connect with us</h3>
						<strong class="title">ON</strong>
						<h4>Social networks</h4>',
						),
				'social-twitter'=>array(					
						'title'=> 'Social Icon Twitter Link.',
						'name'=> 'page-option-item-social-twitter',
						'type'=> 'inputtext',
						'default'=> '',
						),
				'social-facebook'=>array(					
						'title'=> 'Social Icon facebook Link.',
						'name'=> 'page-option-item-social-facebook',
						'type'=> 'inputtext',
						'default'=> '',
						),
				'social-rss'=>array(					
						'title'=> 'Social Icon Rss Link.',
						'name'=> 'page-option-item-social-rss',
						'type'=> 'inputtext',
						'default'=> '',
						),
				'map-heading'=>array(					
						'title'=> 'Map Heading',
						'name'=> 'page-option-item-map-heading',
						'type'=> 'inputtext',
						'default'=> '<h4>1600 Pacific Ave</h4>
<strong class="address">Venice, CA, United States</strong>',
						),	
				'map-code'=>array(					
						'title'=> 'Map Embed Code',
						'name'=> 'page-option-item-map-code',
						'type'=> 'textarea',
						'default'=> '<div id="map_canvas" style="width: 100%; height: 286px; text-align:center;"> </div>',
						),
				'top-product'=>array(					
						'title'=> 'Top Product',
						'name'=> 'page-option-item-top-product',
						'type'=> 'inputtext',
						'default'=> 'Top Rates',
						),					
				'browse-product'=>array(					
						'title'=> 'Browse Collection',
						'name'=> 'page-option-item-browse-prodcut',
						'type'=> 'inputtext',
						'default'=> '',
						),
				'top-category'=>array(
						'title'=>'CHOOSE CATEGORY',
						'name'=>'page-option-item-top-collection-category',
						'options'=>array(),
						'type'=>'combobox',
						'description'=>'Choose the post category you want to fetch the post.'),
									
				"banner-image" => array(
						'title'=> esc_html__('Banner  Image', 'word-mag'),
						'name'=>'page-option-item-banner-image',
						'type'=>'upload',
						'description'=>''),
			    'banner-url'=>array(					
						'title'=> 'Banner URL',
						'name'=> 'page-option-item-banner-url',
						'type'=> 'inputtext',
						'default'=> '',
						),														
						
				),
				'Accordion' =>array(
					'header'=>array(
						'title'=> esc_html__('HEADER TITLE', 'word-mag'),
						'name'=> 'page-option-item-accordion-header-title',
						'type'=> 'inputtext'),
					'tab-item'=>array(
						'tab-num'=>'page-option-item-accordion-num',
						'title'=>'page-option-item-accordion-title',
						'caption'=>'page-option-item-accordion-content',
						'active'=>'',
						'hr'=>'none')

				),
          	    'Contact-Form'=>array(
					'email'=>array(
						'title'=>'E-MAIL',
						'name'=>'page-option-item-contat-email',
						'type'=>'inputtext',
						'hr'=>'none',
						'description'=>'Place the destination of the email when user submit the contact form here.'),
					'map'=>array(
						'title'=>'Map Embed Code',
						'name'=>'page-option-item-contat-map',
						'type'=>'textarea',
						'hr'=>'none',
						'description'=>'Please enter map embed code here.'),	
					'address'=>array(
						'title'=>'Address',
						'name'=>'page-option-item-contat-address',
						'type'=>'textarea',
						'hr'=>'none',
						'description'=>'Please enter contact details here.'),	
					'address-details'=>array(
						'title'=>'Details',
						'name'=>'page-option-item-contat-address-details',
						'type'=>'textarea',
						'hr'=>'none',
						'description'=>'Please enter contact details here.')
							
				),
      		    'Content' => array(
					'description'=>array(
						'title'=> 'DESCRIPTION',
						'name'=> 'no-name',
						'type'=> 'description',
						'description'=> 'This item will get the content in the editor(wordpress visual/html editor) to show as a page item. ' .
							'Don\'t forget to hide the page content in page options, otherwise there will be a duplicated content in the page.',

 					'hr'=> 'none'
 
					),
				),
	            'Gallery' =>array(
					'item-size'=>array(
						'title'=> 'ELEMENT SIZE',
						'name'=> 'page-option-item-gallery-item-size',
						'type'=> 'combobox',
						'options'=> array('1/4', '1/3', '1/2')
					),
				'gallery'=>array(
						'title'=>'CHOOSE A Gallery',
						'name'=>'page-option-item-gallery',
						'options'=>array(),
						'type'=>'combobox',
						'description'=>'Choose the post category you want to fetch the post.'),		
				),
				'Divider' =>array(
					'text'=>array(
						'title'=> 'DIVIDER',
						'name'=> 'page-option-item-divider-text',
						'type'=> 'description',
						'hr'=> 'none',
						'description'=> "Add Divider in page"),				
				),
				'Message-Box'=>array(
					'color'=>array(
						'title'=>'BOX COLOR',
						'name'=>'page-option-item-message-color',
						'options'=>array('0'=>'red', '1'=>'green', '2'=>'yellow', '3'=>'blue'),
						'type'=>'combobox'),
					'title'=>array(
						'title'=> 'MESSAGE TITLE',
						'name'=> 'page-option-item-message-title',
						'type'=> 'inputtext'),		
					'content'=>array(
						'title'=> 'MESSAGE CONTENT',
						'name'=> 'page-option-item-message-content',
						'type'=> 'textarea',
						'hr'=> 'none'),				
				),
				'Tab' =>array(
				     'tab-widget'=>array(
						'title'=> esc_html__('Tab Widget Title', 'word-mag'),
						'name'=> 'page-option-item-tab-widget',
						'type'=> 'inputtext'),
					'tab-item'=>array(
						'tab-num'=>'page-option-item-tab-num',
						'title'=>'page-option-item-tab-title',
						'caption'=>'page-option-item-tab-content',
						'active'=>'',
						'hr'=>'none')
				),
				'Column'=>array(
					'column-text'=>array(
						'title'=> 'Column Text',
						'name'=> 'page-option-item-column-text',
						'type'=> 'textarea',
						'hr'=> 'none')
				),
				'Testimonial' =>array(
					'header'=>array(
						'title'=> 'HEADER TITLE',
						'name'=> 'page-option-item-testimonial-header-title',
						'type'=> 'inputtext'),
					/*'display-type'=>array(
						'title'=>'CHOOSE THE DISPLAY TYPE',
						'name'=>'page-option-item-testimonial-display-type',
						'options'=>array('0'=>'Testimonial Category', '1'=>'Specific Testimonial'),
						'type'=>'combobox'),*/
					'category'=>array(
						'title'=>'CHOOSE CATEGORY',
						'name'=>'page-option-item-testimonial-category',
						'options'=>array(),
						'type'=>'combobox',
						'hr'=>'none',
						'description'=>'Choose the category you want testimonial to be fetched. This theme will display testimonail using the jquery carousel.'),
					/*'specific'=>array(
						'title'=>'SPECIFIC TESTIMONIAL',
						'name'=>'page-option-item-testimonial-specific',
						'options'=>array(),
						'type'=>'combobox',
						'hr'=>'none',
						'description' => 'If you choose Specific Testimonial option, it will ignores the testimonial size above and' . 
							' use the wrapper size ( outside ) instead.'),	*/		
				),
			    'Products'=>array(
				  'product-type'=>array(
						'title'=>'PRODUCT STYLE',
						'name'=>'page-option-item-products-type',
						'type'=> 'combobox',
						'options'=>array('0'=>'Featured', '1'=>'Popular','2'=>'Standard'),
						),
						
				    'heading'=>array(					
						'title'=> 'HEADING',
						'name'=> 'page-option-item-products-heading',
						'type'=> 'inputtext',
						'default'=> 'Featured <span class="breck">Products</span>',
						'description'=> 'Heading section appears on featured and popular product styles only.'),
					'sub-heading'=>array(					
						'title'=> 'SUB HEADING',
						'name'=> 'page-option-item-products-sub-heading',
						'type'=> 'inputtext',
						'default'=> '<strong class="title">Check out our <span class="pink">latest</span> range of <span class="pink">winter</span> clothes</strong>',
						'description'=> 'Sub Heading section appears on featured and popular product styles only.'),
							
				   
					'product-style'=>array(
						'title'=>'PRODUCT STYLE',
						'name'=>'page-option-item-products-style',
						'type'=> 'combobox',
						'options'=>array('0'=>'GRID', '1'=>'LIST'),
						'description'=>'This option only work with standard product style.',
						),
					'category'=>array(
						'title'=>'CHOOSE CATEGORY',
						'name'=>'page-option-item-products-category',
						'options'=>array(),
						'type'=>'combobox',
						'hr'=> 'none',
						'description'=>'Choose the products category you want the item to be fetched.'),
					'num-fetch'=>array(					
						'title'=> 'PRODUCT NUM FETCH',
						'name'=> 'page-option-item-products-num-fetch',
						'type'=> 'inputtext',
						'default'=> 9,
						'description'=> 'This is the number of product thumbnail you want to fetch in one page.'),
					'pagination'=>array(
						'title'=>'ENABLE PAGINATION',
						'name'=>'page-option-item-products-pagination',
						'type'=> 'combobox',
						'options'=>array('0'=>'Yes', '1'=>'No'),
						'hr'=> 'none',
						'description'=>'Pagination will only appear when the number of selected page is greater than the number of fetched item in one page.'),
				),
			    'Services'=>array(
			               'heading'=>array(
							   'service-heading'=> esc_html__('SECTION HEADING', 'word-mag'),
								'name'=> 'page-option-item-service-heading',
								'description'=>'Section heading will appear at top of widgets',
								'type'=> 'inputtext'),
							'service-style'=>array(					
								'title'=> 'SERVICE WIDGHET ITEMS',
								'name'=> 'page-option-item-service-widget-2-col',
								'type'=> 'combobox',
								'options'=> array('Style 1','Style 2','Style 3'),
								'description'=>'There are 3 different services styles avalible.'),
				            'service-cat'=>array(
								'title'=>'CHOOSE CATEGORY',
								'name'=>'page-option-item-service-cat',
								'options'=>array(),
								'type'=>'combobox',
								'description'=>'Choose the services category you want to fetch the post.'),
		),
				'Brands'=>array(
                    'brands-block-title'=>array(
						'title'=> esc_html__('Heading', 'word-mag'),
						'name'=> 'page-option-item-brand-block-title',
						'default'=> 'Brands <span class="pink">We Sell</span>',
						'type'=> 'inputtext'),
				),
				'Client'=>array(
                    'client-heading'=>array(
						'title'=> esc_html__('Heading', 'word-mag'),
						'name'=> 'page-option-item-client',
						'default'=> 'Our <span class="pink">Clients</span>',
						'type'=> 'inputtext'),
				),
			    'Team'=>array(
			               'heading'=>array(
							   'team-heading'=> esc_html__('SECTION HEADING', 'word-mag'),
								'name'=> 'page-option-item-team-heading',
								'description'=>'Section heading will appear at top of widgets',
								'type'=> 'inputtext'),
					        'team-cat'=>array(
								'title'=>'CHOOSE CATEGORY',
								'name'=>'page-option-item-team-cat',
								'options'=>array(),
								'type'=>'combobox',
								'description'=>'Choose the teams category you want to fetch the post.'),
		        ),
				'Banner'=>array(
                   "banner-1" => array(
						'title'=> esc_html__('Banner 1 Image', 'word-mag'),
						'name'=>'page-option-item-banner-image-1',
						'type'=>'upload',
						'description'=>'Select proper image size according to service widget size'),				
					'banner-link'=>array(
						'title'=> esc_html__('Banner 1 URL', 'word-mag'),
						'name'=> 'page-option-item-banner-link',
						'type'=> 'inputtext'),
					"banner-2" => array(
						'title'=> esc_html__('Banner 2 Image', 'word-mag'),
						'name'=>'page-option-item-banner-image-2',
						'type'=>'upload',
						'description'=>'Select proper image size according to service widget size'),				
					'banner-link-2'=>array(
						'title'=> esc_html__('Banner 2 URL', 'word-mag'),
						'name'=> 'page-option-item-banner-link-2',
						'type'=> 'inputtext'),
				),
			),
		),

		/* "Page Header Template" => array(
			'title'=> esc_html__('SELECT HEADER TEMPLATE', 'word-mag'), 
			'name'=>'page-option-header-template', 
			'type'=>'radioimage', 
			'default'=>'no-sidebar',
			'hr'=>'none',
			'options'=>array(
				'1'=>array('value'=>'style-1','image'=>'/framework/assets/images/right-sidebar.png'),
				'2'=>array('value'=>'style-2','image'=>'/framework/assets/images/left-sidebar.png'),
				'3'=>array('value'=>'style-3','image'=>'/framework/assets/images/no-sidebar.png','default'=>'selected'),
				'4'=>array('value'=>'style-4','image'=>'/framework/assets/images/left-sidebar.png'),
				'5'=>array('value'=>'style-5','image'=>'/framework/assets/images/left-sidebar.png'),
				'6'=>array('value'=>'style-6','image'=>'/framework/assets/images/left-sidebar.png'),
			)
		),*/
		
		'header-style'=>array(
						'title'=>'HEADER STYLE',
						'name'=>'page-option-item-header-style',
						'type'=> 'combobox',
						'options'=>array(
						'default'=>'default',
						'style-1'=>'style-1',
						'style-2'=>'style-2',
						'style-3'=>'style-3',
						'style-4'=>'style-4',
						'style-5'=>'style-5',
						'style-6'=>'style-6',
						  ),
						'description'=>'Please select your desired header style.',
						),
		'header-shadow'=>array(
						'title'=>'HEADER SHADOW',
						'name'=>'page-option-item-header-shadow',
						'type'=> 'combobox',
						'options'=>array(
						'Yes'=>'Yes', 
						'No'=>'No',
						  ),
						'description'=>'',
						),
		'footer-show'=>array(
						'title'=>'DISPLAY FOOTER WIDGETS',
						'name'=>'page-option-item-footer-show',
						'type'=> 'combobox',
						'options'=>array(
						'Yes'=>'Yes', 
						'No'=>'No',
						  ),
						'description'=>'',
						),
		"Header Slider Category" => array(
			'title'=> esc_html__('CHOOSE CATEGORY FOR THE HEADER SLIDER', 'word-mag'),
			'name'=>'page-option-choose-header-cat',
			'type'=>'combobox',
		),
		
		"Header Slider Number" => array(
			'title'=> esc_html__('ITEM FETCH', 'word-mag'),
			'name'=>'page-option-choose-header-num',
			'type'=>'inputtext',
			'default'=> '5',
			'hr'=>'none',
			'description'=>'Set Numbers of Slides to Fetch.'
         ),						
						
	   "Page Sidebar Template" => array(
			'title'=> esc_html__('SELECT LAYOUT', 'word-mag'), 
			'name'=>'page-option-sidebar-template', 
			'type'=>'radioimage', 
			'default'=>'no-sidebar',
			'hr'=>'none',
			'options'=>array(
				'1'=>array('value'=>'right-sidebar','image'=>'/framework/assets/images/right-sidebar.png'),
				'2'=>array('value'=>'left-sidebar','image'=>'/framework/assets/images/left-sidebar.png'),
				/*'3'=>array('value'=>'both-sidebar','image'=>'/framework/assets/images/both-sidebar.png'),*/
				'4'=>array('value'=>'no-sidebar','image'=>'/framework/assets/images/no-sidebar.png','default'=>'selected')
			)
		),
		
		
	   "Choose Left Sidebar" => array(
			'title'=> esc_html__('Choose Left Sidebar', 'word-mag'),
			'name'=>'page-option-choose-left-sidebar',
			'type'=>'combobox',
			'hr'=>'none'
		),		
	   "Choose Right Sidebar" => array(
			'title'=> esc_html__('CHOOSE RIGHT SIDEBAR', 'word-mag'),
			'name'=>'page-option-choose-right-sidebar',
			'type'=>'combobox',
		),
	   "Page Title" => array(
			'type'=>'combobox',
			'name'=>'page-option-show-title',
			'options'=> array('Yes', 'No'),
			'default'=> 'Yes',
			'title'=> esc_html__('SHOW PAGE TITLE', 'word-mag'),
			'description' => 'Show Page title at the top of the page( below the main navigation menu and top slider ).'
		),	
       "Page Content" => array(
			'type'=>'combobox',
			'name'=>'page-option-show-content',
			'options'=> array('Yes', 'No'),
			'default'=> 'Yes',
			'title'=> esc_html__('SHOW PAGE CONTENT', 'word-mag'),
		),	
	  
    	"Video Slider Open" => array( 'type'=>'open', 'id'=>'post-slider-wrapper'),
		"product-slider-fetch" => array(
			'title'=> esc_html__('ITEM FETCH', 'word-mag'),
			'name'=>'page-option-slider-fetch',
			'type'=>'inputtext',
			'default'=> '5',
			'hr'=>'none',
			'description'=>'Set Numbers of Slides to Fetch.'
         ),			
		'product-slider-category'=>array(
						'title'=>'CHOOSE CATEGORY',
						'name'=>'page-option-item-slider-category',
						'options'=>array(),
						'type'=>'combobox',
						'description'=>'Choose the post category you want to fetch the post.'),
		"Vidoe Slider Close" => array( 'type'=>'close' , 'hr'=>'none',),
	    "Layer Slider Open" => array( 'type'=>'open', 'id'=>'cp-layer-slider-wrapper'),
		"Layer Slider ID" => array(
			'title'=> esc_html__('LAYER SLIDER ID', 'word-mag'),
			'name'=>'page-option-layer-slider-id',
			'type'=>'inputtext',
			'default'=> '1',
			'hr'=>'none',
			'description'=>'You have to create the layer slider ( by installing the plugin we provided within the zip file you downloaded from theme forest. )' .
						   ' and follows the instruction on the slider documentation before inputting this. <br><br><strong> Only Integer Number is allowed in this field</strong>.'

		),			
		"Layer Slider Close" => array( 'type'=>'close' , 'hr'=>'none',),
		"Top Slider Open" => array( 'type'=>'open', 'id'=>'cp-top-slider-wrapper', 'hr'=>'none'),
		"Top Slider Height" => array(
			'title'=> esc_html__('TOP SLIDER HEIGHT', 'word-mag'),
			'name'=>'page-option-top-slider-height',
			'type'=>'inputtext',
			'default'=> '360',
			'hr'=>'none'
		),		
    	"Top Slider" => array(
			'type'=>'imagepicker',
			'title'=> esc_html__('SELECT IMAGES', 'word-mag'),
			'xml'=>'page-option-top-slider-xml',
			'hr'=>'none',
			'name'=>array(
				'image'=>'page-option-top-slider-image',
				'title'=>'page-option-top-slider-title',
				'caption'=>'page-option-top-slider-caption',
				'link'=>'page-option-top-slider-link',
				'linktype'=>'page-option-top-slider-linktype'),
		),
		"Top Slider Close" => array( 'type'=>'close','hr'=>'none' )
	);


		
	add_action('add_meta_boxes', 'add_page_option');
	function add_page_option(){

		add_meta_box('page-option', esc_html__('Page Option','word-mag'), 'add_page_option_element',
			'page', 'normal', 'high');

	}
	
	
		

	function add_page_option_element(){	

		global $post, $page_meta_boxes;

		//init array
       
		/*$page_meta_boxes['Page Item']['name']['Featured-Author']['featured-book']['options'] = get_title_list( 'product' );*/
		$page_meta_boxes['Choose Left Sidebar']['options'] = get_sidebar_name();
		$page_meta_boxes['Choose Right Sidebar']['options'] = $page_meta_boxes['Choose Left Sidebar']['options'];
		$page_meta_boxes['Header Slider Category']['options'] = get_category_list('category');
		
		$page_meta_boxes['Page Item']['name']['Blog']['category']['options'] =  get_category_list('category');
	  
		
		echo '<div id="cp-overlay-wrapper">';
		echo '<div id="cp-overlay-content">';

		set_nonce();

		//get value

		foreach( $page_meta_boxes as $page_meta_box ){
			if( $page_meta_box['type'] == 'page-option-item' ){
				$page_meta_box['value'] = get_post_meta($post->ID, $page_meta_box['xml'], true);
				//word_mag_print_page_default_elements($page_meta_box);
				///word_mag_print_page_selected_elements($page_meta_box);
			}
			elseif( $page_meta_box['type'] == 'sidebar' ){ echo 'ok'; die;
				$page_meta_box['value'] = get_post_meta($post->ID, $page_meta_box['xml'], true);
				//word_mag_print_page_default_elements($page_meta_box);
			   //word_mag_print_page_selected_elements($page_meta_box);
			}else if( $page_meta_box['type'] == 'imagepicker' ){

				$slider_xml_string = get_post_meta($post->ID, $page_meta_box['xml'], true);
				
				if(!empty($slider_xml_string)){


					$slider_xml_val = new DOMDocument();
					$slider_xml_val->loadXML( $slider_xml_string );
					$page_meta_box['value'] = $slider_xml_val->documentElement;

	
				}

				word_mag_print_meta( $page_meta_box );
		

			}else{

				
				if( empty( $page_meta_box['name'] ) ){ $page_meta_box['name'] = ''; }
				$page_meta_box['value'] = get_post_meta($post->ID, $page_meta_box['name'], true);
				word_mag_print_meta( $page_meta_box );
			

			}
			echo "<div class='clear'></div>";
			echo empty($page_meta_box['hr'])? '<hr class="separator mt20">': '';

		
		}		

		echo '</div>';
		echo '</div>';

	}

	

	// call when update page with save_post action 

	function save_page_option_meta($post_id){
		global $page_meta_boxes;
		$edit_meta_boxes = $page_meta_boxes;
		foreach ($edit_meta_boxes as $edit_meta_box){
			if( $edit_meta_box['type'] == 'page-option-item' ){
				if(isset($_POST[$edit_meta_box['size']])){
					$num = sizeof($_POST[$edit_meta_box['size']]);
				}else{
					$num = 0;
				}
				$word_mag_item_xml = '<item-tag>';
				$item_content_num = array();
				for($i=0; $i<$num; $i++){
				
					$word_mag_item_type_new = $_POST[$edit_meta_box['item']][$i];
					$word_mag_item_xml = $word_mag_item_xml . '<' . $word_mag_item_type_new . '>';
					$word_mag_item_size_new = $_POST[$edit_meta_box['size']][$i];
					$word_mag_item_xml = $word_mag_item_xml . create_xml_tag('size',$word_mag_item_size_new);
					$item_content = $edit_meta_box['name'][$word_mag_item_type_new];
					if(!isset($item_content_num[$word_mag_item_type_new])){
						$item_content_num[$word_mag_item_type_new] = 1 ;
						if($word_mag_item_type_new == 'Slider'){
							$item_content_num['slider-item'] = 0;
						}else if($word_mag_item_type_new == 'Accordion'){
							$item_content_num['accordion-item'] = 0;
						}else if($word_mag_item_type_new == 'Tab'){
							$item_content_num['tab-item'] = 0;
						}else if($word_mag_item_type_new == 'Toggle-Box'){
							$item_content_num['toggle-box-item'] = 0;
						}
					}

					
					foreach($item_content as $key => $value){

					

						if($key == 'slider-item'){
							$word_mag_item_xml = $word_mag_item_xml . '<' . $key . '>';
							$slider_num = $_POST[$value['slider-num']][$item_content_num[$word_mag_item_type_new]];
							for($j=0; $j<$slider_num; $j++){
								$word_mag_item_xml = $word_mag_item_xml . '<slider>';
								$temp = isset( $_POST[$value['image']][$item_content_num['slider-item']] )? $_POST[$value['image']][$item_content_num['slider-item']] : '';
								$word_mag_item_xml = $word_mag_item_xml . create_xml_tag('image', $temp);
								$temp = isset( $_POST[$value['title']][$item_content_num['slider-item']] )? htmlspecialchars($_POST[$value['title']][$item_content_num['slider-item']]) : '';
								$word_mag_item_xml = $word_mag_item_xml . create_xml_tag('title', $temp);
								$temp = isset( $_POST[$value['linktype']][$item_content_num['slider-item']] )? $_POST[$value['linktype']][$item_content_num['slider-item']] : '';
								$word_mag_item_xml = $word_mag_item_xml . create_xml_tag('linktype', $temp);
								$temp = isset( $_POST[$value['link']][$item_content_num['slider-item']] )? htmlspecialchars($_POST[$value['link']][$item_content_num['slider-item']]) : '';
								$word_mag_item_xml = $word_mag_item_xml . create_xml_tag('link', $temp);
								$temp = isset( $_POST[$value['caption']][$item_content_num['slider-item']] )? htmlspecialchars($_POST[$value['caption']][$item_content_num['slider-item']]) : '';
								$word_mag_item_xml = $word_mag_item_xml . create_xml_tag('caption', $temp);
								$word_mag_item_xml = $word_mag_item_xml . '</slider>';
								$item_content_num['slider-item']++; 								

							}

							$word_mag_item_xml = $word_mag_item_xml . '</' . $key . '>';
						}else if($key == "tab-item"){
							$word_mag_item_xml = $word_mag_item_xml . '<' . $key . '>';
							if($word_mag_item_type_new == "Accordion"){
								$tab_type = 'accordion-item';
							}else if($word_mag_item_type_new == "Toggle-Box"){
								$tab_type = 'toggle-box-item';
							}else{
								$tab_type = 'tab-item';
							}
							$tab_num = $_POST[$value['tab-num']][$item_content_num[$word_mag_item_type_new]];

							for($j=0; $j<$tab_num; $j++){
								$word_mag_item_xml = $word_mag_item_xml . '<tab>';
								$temp = isset( $_POST[$value['title']][$item_content_num[$tab_type]] )? htmlspecialchars($_POST[$value['title']][$item_content_num[$tab_type]]) : '';
								$word_mag_item_xml = $word_mag_item_xml . create_xml_tag('title', $temp);
								$temp = isset( $_POST[$value['caption']][$item_content_num[$tab_type]] )? htmlspecialchars($_POST[$value['caption']][$item_content_num[$tab_type]]) : '';
								$word_mag_item_xml = $word_mag_item_xml . create_xml_tag('caption', $temp);
								$temp = isset( $_POST[$value['active']][$item_content_num[$tab_type]] )? $_POST[$value['active']][$item_content_num[$tab_type]] : '';
								$word_mag_item_xml = $word_mag_item_xml . create_xml_tag('active', $temp);
								$word_mag_item_xml = $word_mag_item_xml . '</tab>';
								$item_content_num[$tab_type]++;
							}

							$word_mag_item_xml = $word_mag_item_xml . '</' . $key . '>';

						}else{

							if(isset($_POST[$value['name']][$item_content_num[$word_mag_item_type_new]])){
								$item_value = htmlspecialchars($_POST[$value['name']][$item_content_num[$word_mag_item_type_new]]);
								$word_mag_item_xml = $word_mag_item_xml .  create_xml_tag($key, $item_value);
							}else{
								$word_mag_item_xml = $word_mag_item_xml .  create_xml_tag($key, '');
							}
						}
					}

					$word_mag_item_xml = $word_mag_item_xml . '</' . $word_mag_item_type_new . '>';
					$item_content_num[$word_mag_item_type_new]++;

				}

				$word_mag_item_xml = $word_mag_item_xml . '</item-tag>';
				$word_mag_item_xml_old = get_post_meta($post_id, $edit_meta_box['xml'], true);
				save_meta_data($post_id, $word_mag_item_xml, $word_mag_item_xml_old, $edit_meta_box['xml']);
				

			}else if( $edit_meta_box['type'] == 'imagepicker' ){
				if(isset($_POST[$edit_meta_box['name']['image']])){
					$num = sizeof($_POST[$edit_meta_box['name']['image']]) - 1;
				}else{
					$num = -1;
				}

				$slider_xml_old = get_post_meta($post_id,$edit_meta_box['xml'],true);
				$slider_xml = "<slider-item>";

			
				for($i=0; $i<=$num; $i++){
					$slider_xml = $slider_xml. "<slider>";
					$image_new = stripslashes($_POST[$edit_meta_box['name']['image']][$i]);
					$slider_xml = $slider_xml. create_xml_tag('image',$image_new);
					$title_new = stripslashes(htmlspecialchars($_POST[$edit_meta_box['name']['title']][$i]));
					$slider_xml = $slider_xml. create_xml_tag('title',$title_new);
					$caption_new = stripslashes(htmlspecialchars($_POST[$edit_meta_box['name']['caption']][$i]));
					$slider_xml = $slider_xml. create_xml_tag('caption',$caption_new);
					$linktype_new = stripslashes($_POST[$edit_meta_box['name']['linktype']][$i]);
					$slider_xml = $slider_xml. create_xml_tag('linktype',$linktype_new);
					$link_new = stripslashes(htmlspecialchars($_POST[$edit_meta_box['name']['link']][$i]));
					$slider_xml = $slider_xml. create_xml_tag('link',$link_new);
					$slider_xml = $slider_xml . "</slider>";
				}
				
				$slider_xml = $slider_xml . "</slider-item>";
				save_meta_data($post_id, $slider_xml, $slider_xml_old, $edit_meta_box['xml']);
			}else if($edit_meta_box['type'] == 'open' || $edit_meta_box['type'] == 'close'){
			}else{
				if(isset($_POST[$edit_meta_box['name']])){
					$new_data = stripslashes($_POST[$edit_meta_box['name']]);
				}else{
					$new_data = '';
				}
				$old_data = get_post_meta($post_id, $edit_meta_box['name'],true);
				save_meta_data($post_id, $new_data, $old_data, $edit_meta_box['name']);				
			}
		}
	}

	
	// print all elements that can be added to selected elements
	function word_mag_print_page_default_elements($args){
						extract($args);
		?>

<div class="meta-body">
  <div class="meta-title">
    <label>
      <?php esc_html_e('ADD ELEMENTS', 'word-mag'); ?>
    </label>
  </div>
  
  <!-- Select Item List -->
  
  <div class="meta-input">
    <div class="page-select-element-list-wrapper combobox">
      <select id="page-select-element-list">
        <option> Please select element </option>
        <?php

								foreach( $name as $key => $value ){

									echo '<option>' . $key . '</option>';

								}

							?>
      </select>
    </div>
    <input type="button" id="page-add-item-button" class="page-add-item-button" value="Add" />
    <br class="clear">
  </div>
  <br class="clear">
</div>

<!-- Default Item to Clone to-->

<div class="page-element-lists" id="page-element-lists">
  <?php
					foreach( $name as $key => $value ){
						word_mag_print_page_elements($args, '', $key);					
					}
				?>
  <br class="clear">
</div>
<?php
	}
	// chosen elements

	function word_mag_print_page_selected_elements($args){	
		    extract($args);

		?>
<div class="page-methodology" id="page-methodology">
  <div class="page-selected-elements-wrapper">
    <div class="page-selected-elements page-no-sidebar" id="page-selected-elements">
      <?php
						if($value != ''){
							$xml = new DOMDocument();
							$xml->loadXML($value);
							foreach($xml->documentElement->childNodes as $item){
								word_mag_print_page_elements($args, $item, $item->nodeName);
							}
						}
					?>
    </div>
    <br class="clear">
  </div>
</div>
<?php
	}

	// function that manage to print each elements from receiving arguments

	function word_mag_print_page_elements($args, $xml_val, $word_mag_item_type){
		extract($args);
		//echo "<pre>";print_r($name['Widget']);
		$head_type = $word_mag_item_type;
		if(empty($xml_val)){
			$head_size = '';
			$head_name = array('item'=>$item,'size'=>$size,'itemname'=>'','sizename'=>'');
		}else{
			$head_size = find_xml_value($xml_val, 'size');
			$head_name = array('item'=>$item,'size'=>$size,'itemname'=>$item.'[]','sizename'=>$size.'[]');
		}	
		word_mag_print_page_item_identical($head_name, $head_size, $head_type);

		?>
<div class="page-element-edit-box" id="page-element-edit-box">
  <?php

				foreach( $name[$word_mag_item_type] as $input_key => $input_value ){
					if( $input_key == 'slider-item' ){
						$slider_value = find_xml_node($xml_val, 'slider-item');
						word_mag_print_image_picker( array('name'=>$input_value, 'value'=>$slider_value ) );
					  }else if( $input_key == 'tab-item' ){
							   word_mag_print_box_tab($input_value, find_xml_node($xml_val, 'tab-item'));
				      }else if( $input_key == 'haji-item' ){
							   word_mag_print_panel_sidebar('lol',$input_value);
				      }else{
					    $input_value['value'] = find_xml_value($xml_val, $input_key);
						$input_value['name'] = $input_value['name'] . '[]';
						word_mag_print_meta( $input_value );
					}
					if( ( $input_key!= 'open' && $input_key != 'close') ){
						echo ( empty($input_value['hr']) )? '<hr class="separator mt20">': '';
					}
				}
			?>
</div>
</div>
<?php

		

	}

	

	// print the identical part of Page Item 

	function word_mag_print_page_item_identical($item, $size, $text){
		global $div_size;
		if(empty( $size )) { 
			foreach( $div_size[$text] as $key => $val ){
				$size = $key; 
				break;
			}
		} 

			
		?>
<div class="page-element <?php echo esc_attr( $size); ?>" id="page-element" rel="<?php echo esc_attr($text); ?>">
  <div class="page-element-item" id="page-element-item" >
    <div class="item-bar-left">
      <?php if( 
	 $text == 'Timeline'
	 || $text == 'Portfolio'
	 || $text == 'Team-Widget'
	 || $text == 'Portfolio'
	/* || $text == 'Testimonial'*/
	 || $text == 'Team-Block' 
	 ) {} else {
	 ?>
      <div class="change-element-size-temp">
        <div class="add-element-size" id="add-element-size" ></div>
        <div class="sub-element-size" id="sub-element-size" ></div>
      </div>
      <?php }?>
    </div>
    <span class="page-element-item-text"> <?php echo  esc_attr($text); ?> </span>
    <input type="hidden" id="<?php echo  esc_attr($item['item']);?>" class="<?php echo  esc_attr($item['item']);?>" value="<?php echo   esc_attr($text); ?>" name="<?php echo   esc_attr($item['itemname']);?>">
    <input type="hidden" id="<?php echo  esc_attr($item['size']);?>" class="<?php echo  esc_attr($item['size']);?>" value="<?php echo   esc_attr($size); ?>" name="<?php echo  esc_attr($item['sizename']);?>">
    <div class="item-bar-right">
      <div class="element-size-text" id="element-size-text"><?php echo esc_attr($div_size[$text][$size]); ?></div>
      <div class="change-element-property"> <a title="Edit">
        <div rel="cp-edit-box" id="page-element-edit-box" class="edit-element"></div>
        </a> <a title="Delete">
        <div class="delete-element" id="delete-element"></div>
        </a> </div>
    </div>
  </div>
  <?php
	}

	

	//Print exceptional input element ( from meta-template )

	function word_mag_print_box_tab($name, $values){

	

		?>
  <div class="meta-body">
    <div class="meta-title meta-tab">ADD MORE TABS</div>
    <div id="page-tab-add-more" class="page-tab-add-more" />
  </div>
  <br class="clear">
  <div class="meta-input">
    <input type='hidden' class="tab-num" id="tab-num" name='<?php echo  esc_attr($name['tab-num']); ?>[]' value=<?php 

					echo empty($values)? 0: $values->childNodes->length;

				?> />
    <div class="added-tab" id="added-tab">
      <ul>
        <li id="page-item-tab" class="default">
          <div class="meta-title meta-tab-title">TABS TITLE</div>
          <input type="text"  id='<?php echo  esc_attr($name['title']); ?>' />
          <br>
          <div class="meta-title meta-tab-title">TABS TEXT</div>
          <textarea id='<?php echo  esc_attr($name['caption']); ?>' ></textarea>
          <br>
          <?php if(!empty($name['active'])){ ?>
          <div class="meta-title meta-tab-title">Tabs Active</div>
          <div class="combobox">
            <select id='<?php echo  esc_attr($name['active']); ?>' >
              <option>Yes</option>
              <option selected>No</option>
            </select>
          </div>
          <?php } ?>
          <div id="unpick-tab" class="unpick-tab"></div>
        </li>
        <?php
							if(!empty($values)){

								foreach ($values->childNodes as $tab){ 

							?>
        <li id="page-item-tab" class="page-item-tab">
          <div class="meta-title meta-tab-title">TABS TITLE</div>
          <input type="text" name='<?php echo esc_attr($name['title']); ?>[]' id='<?php echo  esc_attr($name['title']); ?>' value="<?php echo find_xml_value($tab, 'title'); ?>" />
          <br>
          <div class="meta-title meta-tab-title">TABS TEXT</div>
          <textarea name='<?php echo esc_attr($name['caption']); ?>[]' id='<?php  echo esc_attr($name['caption']); ?>' ><?php echo find_xml_value($tab, 'caption'); ?></textarea>
          <br>
          <div id="unpick-tab" class="unpick-tab"></div>
          <?php if(!empty($name['active'])){ ?>
          <?php $is_active = find_xml_value($tab, 'active'); ?>
          <div class="meta-title meta-tab-title">Tabs Active</div>
          <div class="combobox">
            <select id='<?php echo  esc_attr($name['active']); ?>' name='<?php echo  esc_attr($name['active']); ?>[]' >
              <option <?php if($is_active=='Yes'){ echo 'selected'; } ?>>Yes</option>
              <option <?php if($is_active!='Yes'){ echo 'selected'; } ?>>No</option>
            </select>
          </div>
          <?php } ?>
        </li>
        <?php

							

								}

							}

						?>
      </ul>
      <br class=clear>
    </div>
  </div>
  <br class=clear>
</div>
<?php

	}

	// sidebar => name, value

	function word_mag_print_panel_sidebar($title, $values){
		extract($values);
		?>
<div class="panel-body" id="panel-body">
  <div class="panel-body-gimmick"></div>
  <div class="panel-title">
    <label> <?php printf(esc_html__('%s','word-mag'),$title ); ?> </label>
  </div>
  <div class="panel-input">
    <input type="text" id="add-more-sidebar" value="type title here" rel="type title here">
    <div id="add-more-sidebar" class="add-more-sidebar"></div>
  </div>
  <?php if(isset($description)){ ?>
  <div class="panel-description"> <?php printf(esc_html__('%s','word-mag'),$description ); ?> </div>
  <?php } ?>
  <br class="clear">
  <div id="selected-sidebar" class="selected-sidebar">
    <div class="default-sidebar-item" id="sidebar-item">
      <div class="panel-delete-sidebar"></div>
      <div class="slider-item-text"></div>
      <input type="hidden" id="<?php echo esc_attr($name); ?>">
    </div>
    <?php 
				if(!empty($value)){
					$xml = new DOMDocument();
					$xml->loadXML($value);
					foreach( $xml->documentElement->childNodes as $word_mag_sidebar_name ){
				?>
    <div class="sidebar-item" id="sidebar-item">
      <div class="panel-delete-sidebar"></div>
      <div class="slider-item-text"><?php echo  esc_attr($word_mag_sidebar_name->nodeValue); ?></div>
      <input type="hidden" name="<?php echo esc_attr($name); ?>[]" id="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($word_mag_sidebar_name->nodeValue); ?>">
    </div>
    <?php 

					} 

				} 

				?>
  </div>
</div>
<?php 
	}
