<?php

	/*	
	*	crunchpress Portfolio Option File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		crunchpress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) crunchpress
	*	---------------------------------------------------------------------
	*	This file create and contains the post post_type meta elements
	*	---------------------------------------------------------------------
	*/
	
	// post option meta array
	$post_meta_boxes = array(	
		
		// general options
		"Sidebar Template" => array(
			'title'=> esc_html__('SIDEBAR TEMPLATE', 'word-mag'), 
			'name'=>'post-option-sidebar-template', 
			'type'=>'radioimage', 
			'default'=>'',
			'hr'=>'none',
			'options'=>array(
				'1'=>array('value'=>'right-sidebar','default'=>'selected','image'=>'/framework/assets/images/right-sidebar.png'),
				'2'=>array('value'=>'left-sidebar','image'=>'/framework/assets/images/left-sidebar.png'),
				//'3'=>array('value'=>'both-sidebar','image'=>'/framework/assets/images/both-sidebar.png'),
				'4'=>array('value'=>'no-sidebar','image'=>'/framework/assets/images/no-sidebar.png'))),

		"Choose Left Sidebar" => array(
			'title'=> esc_html__('CHOOSE LEFT SIDEBAR', 'word-mag'),
			'name'=>'post-option-choose-left-sidebar',
			'type'=>'combobox',
			'hr'=>'none',
			'default'=>''
		),		
		
		"Choose Right Sidebar" => array(
			'title'=> esc_html__('CHOOSE RIGHT SIDEBAR', 'word-mag'),
			'name'=>'post-option-choose-right-sidebar',
			'type'=>'combobox',
			 'hr'=>'none',
			'default'=>''
		),
		
	/*	"Author Infomation" => array(
			'title'=> esc_html__('SHOW AUTHOR INFORMATION', 'word-mag'),
			'name'=>'post-option-author-info-enabled',
			'type'=>'combobox', 
			'options'=>array('0'=>'Yes','1'=>'No'),
			'description'=>'Show the author information in the blog page'),
			
		"Social Sharing" => array(
			'title'=> esc_html__('SOCIAL NETWORK SHARING', 'word-mag'),
			'name'=>'post-option-social-enabled',
			'type'=>'combobox', 
			'options'=>array('0'=>'Yes','1'=>'No'),
			'description'=>'Show the social network sharing in the blog page.'),*/
	/*		
		// thumbnail
		"Thumbnail Types" => array(
			'title'=> esc_html__('THUMBNAIL TYPES', 'word-mag'),
			'name'=>'post-option-thumbnail-types',
			'options'=>array(
				'0'=>'Image',
				'1'=>'Video',
				'2'=>'Slider'),
			'type'=>'combobox',
			'hr'=>'none',
			'description'=>'This is the thumbnail of the blog when using the blog item in page options.'),
			
		// image thumbnail
		"Open Thumbnail Image" => array('type'=>'open','id'=>'thumbnail-feature-image'),
		
		"Thumbnail Image" => array(
			'title'=> esc_html__('Use Featured Image as Thumbnail Image', 'word-mag'),
			'name'=>'post-option-featured-image',
			'type'=>'text',
			),
			
		"Close Thumbnail Image" => array('type'=>'close'),
		
		// video thumbnail
		"Open Thumbnail Video" => array('type'=>'open','id'=>'thumbnail-video'),
		
		"Thumbnail Video Url" => array(
			'title'=> esc_html__('VIDEO URL', 'word-mag'),
			'name'=>'post-option-thumbnail-video',
			'type'=>'inputtext',
			'description'=>'Place the url of video you want here. This theme only supports video from Youtube and Vimeo.'),
		
		"Close Thumbnail Video" => array('type'=>'close'),
		
		// slider thumbnail
		"Open Thumbnail Slider" => array('type'=>'open','id'=>'thumbnail-slider'),
		
		"Thumbnail Slider" => array(
			'type'=> 'imagepicker',
			'title'=> esc_html__('SELECT IMAGES', 'word-mag'),
			'xml'=>'post-option-thumbnail-xml',
			'name'=>array(
				'image'=>'post-option-thumbnail-slider-image',
				'title'=>'post-option-thumbnail-slider-title',
				'caption'=>'post-option-thumbnail-slider-caption',
				'link'=>'post-option-thumbnail-slider-link',
				'linktype'=>'post-option-thumbnail-slider-linktype'),
			'hr'=>'none'
		),
		
		"Close Thumbnail Slider" => array('type'=>'close'),*/
		
	
		
		// inside post thumbnails
		"Inside Thumbnail Types" => array(
			'title'=> esc_html__('INSIDE POST THUMBNAIL TYPES', 'word-mag'),
			'name'=>'post-option-inside-thumbnail-types',
			'options'=>array(
				'0'=>'Image',
				'1'=>'Quote',
				'2'=>'Audio',
				'3'=>'Link',
				'4'=>'Slider',
				'5'=>'Video',
				),
			'type'=>'combobox',
			'description'=>'This is the thumbnail inside blog post.'),
		
		// inside post thumbnail image
		"Open Thumbnail Image" => array('type'=>'open','id'=>'inside-thumbnail-image'),
			
		"Inside Thumbnail Image" => array(
			'title'=> esc_html__('SELECT IMAGE', 'word-mag'),
			'name'=>'post-option-inside-thumbnial-image',
			'type'=>'upload',
			),
			
		
		
		// inside post thumbnail video
		"Open Thumbnail Video" => array('type'=>'open','id'=>'inside-thumbnail-video'),
		
		"SELECT VIDEO TYPE" => array(
			'title'=> esc_html__('SELECT VIDEO TYPE', 'word-mag'),
			'name'=>'post-option-inside-video-types',
			'options'=>array(
				'1'=>'Video URL',
				),
			'type'=>'combobox',
		
			'description'=>'Please choose one of the following ways to embed the video into your post, the video is determined in the order: Video Code > Video URL > Video File.'),
			
		
		"Inside Thumbnail Video Url" => array(
			'title'=> esc_html__('VIDEO URL', 'word-mag'),
			'name'=>'post-option-inside-thumbnail-video-url',
			'type'=>'inputtext',
		
			'description'=>'Paste the url from popular video sites like YouTube or Vimeo. For example: <br>
				<code>http://www.youtube.com/watch?v=nTDNLUzjkpg</code><br>
				or<br>
				<code>http://vimeo.com/23079092</code><br><br>
				See <a target="_blank" href="http://codex.wordpress.org/Embeds#Okay.2C_So_What_Sites_Can_I_Embed_From.3F">Supported Video Sites</a>.'
			),
			
		"Open Thumbnail Video" => array('type'=>'close'),
		// Close Video URL Option
		
		// inside post thumbnail slider
		"Open Inside Thumbnail Slider" => array('type'=>'open','id'=>'inside-thumbnail-slider'),
		
		"Inside Thumbnail Slider" => array(
			'type'=>'imagepicker',
			'title'=> esc_html__('SELECT IMAGES', 'word-mag'),
			'xml'=>'post-option-inside-thumbnail-xml',
			'name'=>array(
				'image'=>'post-option-inside-thumbnail-slider-image',
				'title'=>'post-option-inside-thumbnail-slider-title',
				'caption'=>'post-option-inside-thumbnail-slider-caption',
				'link'=>'post-option-inside-thumbnail-slider-link',
				'linktype'=>'post-option-inside-thumbnail-slider-linktype'),
			
		),
		
		"Close Inside Thumbnail Slider" => array('type'=>'close'),
		
		
		"Quote Text" => array(
			'title'=> esc_html__('Quote Text', 'word-mag'),
			'name'=>'post-option-inside-thumbnail-quote',
			'type'=>'textarea',
			'description'=>'Please Enter Quote Text'
		),
		"Link Post URL" => array(
			'title'=> esc_html__('Link URL', 'word-mag'),
			'name'=>'post-option-inside-thumbnail-link',
			'type'=>'inputtext',
			'description'=>'Please Enter URL for the link post type.'
		),
		"Audio URL" => array(
			'title'=> esc_html__('Audio URL', 'word-mag'),
			'name'=>'post-option-inside-thumbnail-audio-url',
			'type'=>'inputtext',
			'description'=>'Please Enter URL of Mp3 File'
		),
			
	);
	
	add_action('add_meta_boxes', 'add_post_option');
	function add_post_option(){	
		add_meta_box('post-option', esc_html__('Post Option','word-mag'), 'add_post_option_element',
			'post', 'normal', 'high');
	}
	function add_post_option_element(){
		global $post, $post_meta_boxes;
		// init array
		$post_meta_boxes['Choose Left Sidebar']['options'] = get_sidebar_name();
		$post_meta_boxes['Choose Right Sidebar']['options'] = $post_meta_boxes['Choose Left Sidebar']['options'];
		
		echo '<div id="cp-overlay-wrapper">';
		
		?> <div class="post-option-meta" id="post-option-meta"> <?php
			set_nonce();
			foreach($post_meta_boxes as $meta_box){
				if( $meta_box['type'] == 'imagepicker' ){
					$xml_string = get_post_meta($post->ID, $meta_box['xml'], true);
					if( !empty($xml_string) ){
						$xml_val = new DOMDocument();
						$xml_val->loadXML( $xml_string );
						$meta_box['value'] = $xml_val->documentElement;
					}
				}else if( $meta_box['type'] == 'open' || $meta_box['type'] == 'close' ){
				
				}else{
					$meta_box['value'] = get_post_meta($post->ID, $meta_box['name'], true);
				}
				word_mag_print_meta($meta_box);
				if( ($meta_box['type'] != 'open' && $meta_box['type'] != 'close') ){
						echo "<div class='clear'></div>";
						echo ( empty($meta_box['hr']) )? '<hr class="separator mt20">': '';
				}
			}
			
		?> </div> <?php
		
		echo '</div>';
		
	}
	
	// call when user save the post
	function save_post_option_meta($post_id){
		global $post_meta_boxes;
		$edit_meta_boxes = $post_meta_boxes;
	
		// save
		foreach ($edit_meta_boxes as $edit_meta_box){
			if( $edit_meta_box['type'] != 'header' && $edit_meta_box['type'] != 'text' &&
				$edit_meta_box['type'] != 'open' && $edit_meta_box['type'] != 'close' ){
				
				// save function for slider
				if( $edit_meta_box['type'] == 'imagepicker' ){
					if(isset($_POST[$edit_meta_box['name']['image']])){
						$num = sizeof($_POST[$edit_meta_box['name']['image']]) - 1;
					}else{
						$num = -1;
					}
					
					$slider_xml_old = get_post_meta($post_id,$edit_meta_box['xml'],true);
					$slider_xml = "<slider-item>";
					
					for($i=0; $i<=$num; $i++){
						$slider_xml = $slider_xml. "<slider>";
						$image_new = stripslashes($_POST[$edit_meta_box['name']['image']][$i]);
						$slider_xml = $slider_xml. create_xml_tag('image',$image_new);
						$title_new = stripslashes(htmlspecialchars($_POST[$edit_meta_box['name']['title']][$i]));
						$slider_xml = $slider_xml. create_xml_tag('title',$title_new);
						$caption_new = stripslashes(htmlspecialchars($_POST[$edit_meta_box['name']['caption']][$i]));
						$slider_xml = $slider_xml. create_xml_tag('caption',$caption_new);
						$linktype_new = stripslashes($_POST[$edit_meta_box['name']['linktype']][$i]);
						$slider_xml = $slider_xml. create_xml_tag('linktype',$linktype_new);
						$link_new = stripslashes(htmlspecialchars($_POST[$edit_meta_box['name']['link']][$i]));
						$slider_xml = $slider_xml. create_xml_tag('link',$link_new);
						$slider_xml = $slider_xml . "</slider>";
					}
					$slider_xml = $slider_xml . "</slider-item>";
					save_meta_data($post_id, $slider_xml, $slider_xml_old, $edit_meta_box['xml']);
				}else{
					if(isset($_POST[$edit_meta_box['name']])){
						$new_data = stripslashes($_POST[$edit_meta_box['name']]);
					}else{
						$new_data = '';
					}
					$old_data = get_post_meta($post_id, $edit_meta_box['name'],true);
					save_meta_data($post_id, $new_data, $old_data, $edit_meta_box['name']);
				}
			}
		}
	}
?>