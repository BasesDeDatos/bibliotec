(function($){

	 "use strict";

	$.fn.cpAddSidebar = function(options){



        var settings = $.extend({

			title: 'Create New Sidebar',

			nonce: '',

			ajax: '',

			action: ''

        }, options);	



		var word_mag_form = $(' <form action="#" > \

								<input type="text" name="sidebar-name" /> \

								<input type="submit" value="+" /> \

							</form>');

		

		var word_mag_object = $('<div class="cp-sidebar-generator" id="cp-sidebar-generator"></div>');

		word_mag_object.append('<span class="cp-title">' + settings.title + '</span>');

		word_mag_object.append(word_mag_form);



		$(this).append('<div class="clear" style="height: 15px;" ></div>');

		$(this).append(word_mag_object);

		

		word_mag_form.submit(function(){

			

			// check if the name is empty

			var sidebar_name = $(this).children('input[name="sidebar-name"]').val();

			if( sidebar_name.length <= 0 ){ 



				$('body').word_mag_alert({

					text: '<span class="head">Sidebar Name Is Blank</span>', 

					status: 'failed',

					duration: 1000

				});			

				return false; 

			}

			

			// if not empty add the new sidebar to the theme

			$.ajax({

				type: 'POST',

				url: settings.ajax,

				data: { 'security': settings.nonce, 'action': settings.action, 'sidebar_name': sidebar_name  },

				dataType: 'json',

				error: function(a, b, c){

					console.log(a, b, c);

					$('body').word_mag_alert({

						text: '<span class="head">Sending Error</span> Please refresh the page and try this again.', 

						status: 'failed'

					});

				},

				success: function(data){

					if( data.status == 'success' ){

						location.reload();

					}else if( data.status == 'failed' ){

						$('body').word_mag_alert({

							text: data.message, 

							status: data.status

						});					

					}

				},

				

			});		

			

			return false;

		});		

		

	};

	

	// add and bind the delete sidebar button

	$.fn.cpDeleteSidebar = function(options){

        var settings = $.extend({

			nonce: '',

			ajax: '',

			action: ''

        }, options);	

		

		var delete_button = $('<div class="delete-sidebar-button"></div>');

		var widget_right = $(this);

		

		delete_button.click(function(){



			var current_widget = $(this).parents('.sidebar-cp-dynamic');

			var sidebar_name = $(this).siblings('h3').html();			

			

			// create confirm button

			$('body').word_mag_confirm({ 

				

				success: function(){

					

					// execute ajax command after user confirm the action

					$.ajax({

						type: 'POST',

						url: settings.ajax,

						data: { 'security': settings.nonce, 'action': settings.action, 'sidebar_name': sidebar_name },

						dataType: 'json',

						error: function(a, b, c){

							console.log(a, b, c);

							$('body').word_mag_alert({

								text: '<span class="head">Deleting Error</span> Please refresh the page and try this again.', 

								status: 'failed'

							});

						},

						success: function(data){

							if( data.status == 'success' ){

								current_widget.slideUp(function(){

								

									$(this).find('.widget-control-remove').trigger('click')

									$(this).remove();

									

									widget_right.find('.widgets-holder-wrap .widgets-sortables').each(function(i){

										$(this).attr('id','sidebar-' + (i + 1));

									});

									

									wpWidgets.saveOrder();							

								});

							}else if( data.status == 'failed' ){

								$('body').word_mag_alert({

									text: data.message, 

									status: data.status

								});					

							}

						},

						

					}); // ajax

					

				} // success

			});

			

			return false;

		});

		

		$(this).find('.sidebar-cp-dynamic .sidebar-name').append(delete_button);



	}

	

	// execute the script when document is ready

	$(document).ready(function(){

	

		// bind the add sidebar function

		$('#widgets-right').cpAddSidebar({

			title: word_mag_title,

			nonce: word_mag_nonce,

			ajax: word_mag_ajax,

			action: 'word_mag_add_sidebar'

		});

		

		// bind the delete sidebar function

		$('#widgets-right').cpDeleteSidebar({

			nonce: word_mag_nonce,

			ajax: word_mag_ajax,

			action: 'word_mag_remove_sidebar'		

		});

	});



})(jQuery);