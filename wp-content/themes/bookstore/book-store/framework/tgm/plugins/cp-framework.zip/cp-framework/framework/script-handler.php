<?php

	/*	
	*	Crunchpress Include Script File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		crunchpress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) crunchpress
	*	---------------------------------------------------------------------
	*	This file manage to embed the stylesheet and javascript to each page
	*	based on the content of that page.
	*	---------------------------------------------------------------------
	*/
	
		add_action('init', 'register_all_cp_framework_scripts');
	    function register_all_cp_framework_scripts(){
	
		if( $GLOBALS['pagenow'] != 'wp-login.php' ){
			if(is_admin()){
				add_action('add_meta_boxes', 'register_cp_framework_meta_script');
			}
		  }
		}
		
	
	/* 	---------------------------------------------------------------------
	*	This section include the back-end script
	*	---------------------------------------------------------------------
	*/ 
	
	
	function load_cp_framework_admin_things() {
		wp_enqueue_script('media-upload');
		wp_enqueue_script('thickbox');
    }

     add_action('admin_enqueue_scripts', 'load_cp_framework_admin_things');

	
	function register_cp_framework_meta_script(){
		global $post_type;
		
		// register style and script when access to the "page" post_type page
		if( $post_type == 'page' ){
		  
		
			wp_enqueue_style('meta-css',plugins_url( 'assets/stylesheet/meta-css.css', __FILE__ ));
			wp_enqueue_style('page-dragging',plugins_url( 'assets/stylesheet/page-dragging.css', __FILE__ ));
			wp_enqueue_style('image-picker',plugins_url( 'assets/stylesheet/image-picker.css', __FILE__ ));
			wp_enqueue_style('confirm-dialog',plugins_url( 'assets/stylesheet/jquery.confirm.css', __FILE__ ));

			wp_deregister_script('image-picker');
			wp_register_script('image-picker',plugins_url( 'assets/javascript/image-picker.js', __FILE__ ), false, '1.0', true);
			wp_enqueue_script('image-picker');
		
			wp_deregister_script('page-dragging');
			wp_register_script('page-dragging',plugins_url( 'assets/javascript/page-dragging.js', __FILE__ ) , false, '1.0', true);
			wp_enqueue_script('page-dragging');
			
			wp_deregister_script('edit-box');
			wp_register_script('edit-box',plugins_url( 'assets/javascript/edit-box.js', __FILE__ ) , false, '1.0', true);
			wp_enqueue_script('edit-box');

			wp_deregister_script('confirm-dialog');
			wp_register_script('confirm-dialog',plugins_url( 'assets/javascript/jquery.confirm.js', __FILE__ ), false, '1.0', true);
			wp_enqueue_script('confirm-dialog');
			
		 
			}else if( $post_type == 'post' || $post_type == 'portfolio' || $post_type == 'gallery' || $post_type == 'artist'){
		
			wp_enqueue_style('meta-css',plugins_url( 'assets/stylesheet/meta-css.css', __FILE__ ));
			wp_enqueue_style('image-picker',plugins_url( 'assets/stylesheet/image-picker.css', __FILE__ ));
			wp_enqueue_style('confirm-dialog',plugins_url( 'assets/stylesheet/jquery.confirm.css', __FILE__ ));
			
			wp_deregister_script('post-effects');
			wp_register_script('post-effects',plugins_url( 'assets/javascript/post-effects.js', __FILE__ ), false, '1.0', true);
			wp_enqueue_script('post-effects');
			
			wp_deregister_script('image-picker');
			wp_register_script('image-picker', plugins_url( 'assets/javascript/image-picker.js', __FILE__ ), false, '1.0', true);
			wp_localize_script( 'image-picker', 'URL', array('word-mag' => WORD_MAG_THEME_PATH_URL ));
			wp_enqueue_script('image-picker');
			
			wp_deregister_script('confirm-dialog');
			wp_register_script('confirm-dialog',plugins_url( 'assets/javascript/jquery.confirm.js', __FILE__ ), false, '1.0', true);
			wp_enqueue_script('confirm-dialog');
		
		// register style and script when access to the "testimonial" post_type page		
		}
	}
	
	
	// register script in crunchpress panel
	function register_cp_framework_panel_scripts($hook_suffix){

		//wp_enqueue_style('ie-style',WORD_MAG_THEME_PATH_URL . 'stylesheet/ie-style.php?path=' . WORD_MAG_THEME_PATH_URL);	
	    if($hook_suffix == 'toplevel_page_options') {
			   
		wp_register_script('jquery-ui',plugins_url( 'assets/javascript/jquery-ui.js', __FILE__ ) , false, '1.0', false);
		wp_register_script('jquery',plugins_url( 'assets/javascript/jquery.js', __FILE__ ), false, '1.0', false);
		wp_register_script('cufon',plugins_url( 'assets/javascript/cufon.js', __FILE__ ), false, '1.0', false);
		wp_register_script('cp-panel',plugins_url( 'assets/javascript/cp-panel.js', __FILE__ ), false, '1.0', false);
		wp_localize_script('cp-panel', 'URL', array('word-mag' => plugins_url('', __FILE__ ) , 'sample_text' => FONT_SAMPLE_TEXT ));
		wp_register_script('mini-color',plugins_url( 'assets/javascript/jquery.miniColors.js', __FILE__ ), false, '1.0', false);
		wp_register_script('confirm-dialog',plugins_url( 'assets/javascript/jquery.confirm.js', __FILE__ ), false, '1.0', false);
		wp_register_script('dummy_content',plugins_url( 'assets/javascript/dummy_content.js', __FILE__ ), false, '1.0', false);
		
		wp_enqueue_script('jquery-ui');
        wp_enqueue_script('jquery');
		wp_enqueue_script('cufon');
		wp_enqueue_script('cp-panel');
		wp_enqueue_script('mini-color');
    	wp_enqueue_script('media-upload');
		wp_enqueue_script('thickbox');
		wp_enqueue_script('confirm-dialog');
		wp_enqueue_script('dummy_content');
		
		wp_enqueue_style('jquery-ui',plugins_url( 'assets/stylesheet/jquery-ui-1.8.16.custom.css', __FILE__ ));
		wp_enqueue_style('cp-panel',plugins_url( 'assets/stylesheet/cp-panel.css', __FILE__ ));
		wp_enqueue_style('mini-color',plugins_url( 'assets/stylesheet/jquery.miniColors.css', __FILE__ ));
		wp_enqueue_style('thickbox');
		wp_enqueue_style('confirm-dialog',plugins_url( 'assets/stylesheet/jquery.confirm.css', __FILE__ ));
	}
}
