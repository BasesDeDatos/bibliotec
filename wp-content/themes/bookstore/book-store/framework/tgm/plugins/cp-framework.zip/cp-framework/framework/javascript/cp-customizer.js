(function($){

 "use strict";

var color_option = [

{name: "header-background-color", selector: ".cp-header-overlay{ background-color: #cp#; }"},

{name: "main-navigation-text", selector: ".cp-main-menu > li > a{ color: #cp#; }"},

{name: "main-navigation-text-hover", selector: ".cp-main-menu > li:hover > a, .cp-main-menu > li.current-menu-item > a, .cp-main-menu > li.current-menu-ancestor > a{ color: #cp#; }"},

{name: "main-navigation2-background", selector: ".cp-navigation-wrapper.cp-style-2{ background-color: #cp#; }"},

{name: "main-navigation2-top-border", selector: ".cp-navigation-wrapper.cp-style-2{ border-top-color: #cp#; }"},

{name: "main-navigation2-slide-bar", selector: ".cp-navigation-wrapper.cp-style-2 .cp-navigation-slide-bar{ background-color: #cp#; }"},

{name: "sub-menu-top-border", selector: ".cp-main-menu > .cp-normal-menu .sub-menu, .cp-main-menu > .cp-mega-menu .sf-mega{ border-top-color: #cp#; }"},

{name: "sub-menu-background", selector: ".cp-main-menu > .cp-normal-menu li , .cp-main-menu > .cp-mega-menu .sf-mega{ background-color: #cp#; }"},

{name: "sub-menu-text", selector: ".cp-main-menu > li > .sub-menu a, .cp-main-menu > li > .sf-mega a{ color: #cp#; }"},

{name: "sub-menu-text-hover", selector: ".cp-main-menu > li > .sub-menu a:hover, .cp-main-menu > li > .sub-menu .current-menu-item > a, .cp-main-menu > li > .sub-menu .current-menu-ancestor > a, .cp-main-menu > li > .sf-mega a:hover, .cp-main-menu > li > .sf-mega .current-menu-item > a, .cp-main-menu > li > .sf-mega .current-menu-ancestor > a{ color: #cp#; } .cp-main-menu .cp-normal-menu li > a.sf-with-ul:after { border-left-color: #cp#; } "},

{name: "sub-mega-menu-text-hover", selector: ".cp-main-menu .sf-mega-section-inner > ul > li > a:hover, .cp-main-menu .sf-mega-section-inner > ul > li.current-menu-item > a { background-color: #cp#; } "},

{name: "sub-menu-divider", selector: ".cp-main-menu > li > .sub-menu *, .cp-main-menu > li > .sf-mega *{ border-color: #cp#; }"},

{name: "sub-menu-mega-title", selector: ".cp-main-menu > li > .sf-mega .sf-mega-section-inner > a { color: #cp#; }"},

{name: "sub-menu-mega-title-hover", selector: ".cp-main-menu > li > .sf-mega .sf-mega-section-inner > a:hover, .cp-main-menu > li > .sf-mega .sf-mega-section-inner.current-menu-item > a, .cp-main-menu > li > .sf-mega .sf-mega-section-inner.current-menu-ancestor > a { color: #cp#; }"},

{name: "mobile-menu-background", selector: "#cp-responsive-navigation.dl-menuwrapper button { background-color: #cp#; }"},

{name: "mobile-menu-background-hover", selector: "#cp-responsive-navigation.dl-menuwrapper button:hover, #cp-responsive-navigation.dl-menuwrapper button.dl-active, #cp-responsive-navigation.dl-menuwrapper ul{ background-color: #cp#; }"},

{name: "menu-search-button-background", selector: ".cp-nav-search-form-button { background-color: #cp#; }"},

{name: "menu-search-button-icon", selector: ".cp-nav-search-form-button { color: #cp#; }"},

{name: "menu-search-button-border", selector: ".cp-nav-search-form-button { border-color: #cp#; }"},

{name: "menu-search-background", selector: ".cp-nav-search-form{ background-color: #cp#; }"},

{name: "menu-search-text", selector: ".cp-nav-search-form i, .cp-nav-search-form input[type=\"text\"]{ color: #cp#; }"},

{name: "body-background", selector: "body{ background-color: #cp#; }"},

{name: "container-backgrond", selector: ".body-overlay{ background-color: #cp#; }"},

{name: "page-title-color", selector: ".cp-page-title{ color: #cp#; }"},

{name: "page-caption-color", selector: ".cp-page-caption{ color: #cp#; }"},

{name: "page-title-icon-color", selector: ".cp-page-title-wrapper .cp-page-header-icon { border-color: #cp#; color: #cp#; }"},

{name: "heading-color", selector: "h1, h2, h3, h4, h5, h6, .cp-title, .cp-title a{ color: #cp#; }"},

{name: "item-title-color", selector: ".cp-item-title-wrapper .cp-item-title, .cp-item-title-wrapper .cp-separator{ color: #cp#; border-color: #cp#; }"},

{name: "item-title-caption-color", selector: ".cp-item-title-wrapper .cp-item-caption{ color: #cp#; }"},

{name: "body-text-color", selector: "body{ color: #cp#; }"},

{name: "body-link-color", selector: "a{ color: #cp#; }"},

{name: "body-link-hover-color", selector: "a:hover{ color: #cp#; }"},

{name: "border-color", selector: "body *{ border-color: #cp#; }"},

{name: "404-box-background", selector: ".page-not-found-block{ background-color: #cp#; }"},

{name: "404-box-text", selector: ".page-not-found-block{ color: #cp#; }"},

{name: "404-search-background", selector: ".page-not-found-search .gdl-search-form input[type=\"text\"]{ background-color: #cp#; }"},

{name: "404-search-text", selector: ".page-not-found-search .gdl-search-form input[type=\"text\"]{ color: #cp#; }"},

{name: "sidebar-title-color", selector: ".cp-sidebar .cp-widget-title{ color: #cp#; }"},

{name: "sidebar-border-color", selector: ".cp-sidebar *{ border-color: #cp#; }"},

{name: "sidebar-list-circle", selector: ".cp-sidebar ul li:before { border-color: #cp#; }"},

{name: "search-form-background", selector: ".gdl-search-form input{ background-color: #cp#; }"},

{name: "search-form-text-color", selector: ".gdl-search-form input{ color: #cp#; }"},

{name: "search-form-border-color", selector: ".gdl-search-form input{ border-color: #cp#; }"},

{name: "tag-cloud-text", selector: ".tagcloud a, .tagcloud a:hover{ color: #cp#; }"},

{name: "twitter-widget-icon", selector: "ul.cp-twitter-widget li:before{ color: #cp#; }"},

{name: "accordion-background", selector: ".cp-accordion-item.style-1 .accordion-title{ background-color: #cp#; }"},

{name: "accordion-text", selector: ".cp-accordion-item.style-1 .accordion-title{ color: #cp#; }"},

{name: "accordion-icon-background", selector: ".cp-accordion-item.style-1 .accordion-title i{ background-color: #cp#; }"},

{name: "accordion-icon-color", selector: ".cp-accordion-item.style-1 .accordion-title i{ color: #cp#; }"},

{name: "box-with-icon-background", selector: ".cp-box-with-icon-item{ background-color: #cp#; }"},

{name: "box-with-icon-title", selector: ".cp-box-with-icon-item > i, .cp-box-with-icon-item .box-with-icon-title{ color: #cp#; }"},

{name: "box-with-icon-text", selector: ".cp-box-with-icon-item{ color: #cp#; }"},

{name: "button-background", selector: ".cp-button, .cp-button:hover, input[type=\"button\"], input[type=\"submit\"]{ background-color: #cp#; }"},

{name: "button-text-color", selector: ".cp-button, .cp-button:hover, input[type=\"button\"], input[type=\"submit\"], .cp-top-menu > .cp-mega-menu .sf-mega a.cp-button{ color: #cp#; }"},

{name: "button-border-color", selector: ".cp-button, input[type=\"button\"], input[type=\"submit\"]{ border-color: #cp#; }"},

{name: "column-service-title-color", selector: ".column-service-icon, .column-service-title{ color: #cp#; }"},

{name: "list-with-icon-title-color", selector: ".list-with-icon .list-with-icon-title{ color: #cp#; }"},

{name: "pie-chart-title-color", selector: ".cp-pie-chart-item .pie-chart-title{ color: #cp#; }"},

{name: "price-background", selector: ".cp-price-inner-item{ background-color: #cp#; }"},

{name: "price-title-background", selector: ".cp-price-item .price-title-wrapper{ background-color: #cp#; }"},

{name: "price-title-text", selector: ".cp-price-item .price-title{ color: #cp#; }"},

{name: "price-tag-background", selector: ".cp-price-item .price-tag{ background-color: #cp#; }"},

{name: "active-price-tag-background", selector: ".cp-price-item .best-price .price-tag{ background-color: #cp#; }"},

{name: "price-tag-text", selector: ".cp-price-item .price-tag{ color: #cp#; }"},

{name: "process-icon-background", selector: ".cp-process-tab .cp-process-icon{ background-color: #cp#; }"},

{name: "process-icon-border", selector: ".cp-process-tab .cp-process-icon{ border-color: #cp#; }"},

{name: "process-icon-color", selector: ".cp-process-tab .cp-process-icon i{ color: #cp#; }"},

{name: "process-line-color", selector: ".cp-process-tab .process-line .process-line-divider{ border-color: #cp#; } .cp-process-tab .process-line .icon-chevron-down, .cp-process-tab .process-line .icon-chevron-right{ color: #cp#; }"},

{name: "process-title-color", selector: ".cp-process-wrapper .cp-process-tab .cp-process-title{ color: #cp#; }"},

{name: "stunning-text-title-color", selector: ".stunning-text-title{ color: #cp#; }"},

{name: "stunning-text-caption-color", selector: ".stunning-text-caption{ color: #cp#; }"},

{name: "stunning-text-background", selector: ".cp-stunning-text-item.with-padding{ background-color: #cp#; }"},

{name: "stunning-text-border", selector: ".cp-stunning-text-item.with-border{ border-color: #cp#; }"},

{name: "tab-title-background", selector: ".tab-title-wrapper .tab-title{ background-color: #cp#; }"},

{name: "tab-title-color", selector: ".tab-title-wrapper .tab-title{ color: #cp#; }"},

{name: "tab-title-content", selector: ".tab-title-wrapper .tab-title.active, .tab-content-wrapper{ background-color: #cp#; }"},

{name: "table-head-background", selector: "table tr th{ background-color: #cp#; }"},

{name: "table-head-text", selector: "table tr th{ color: #cp#; }"},

{name: "table-style2-odd-background", selector: "table.style-2 tr:nth-child(odd){ background-color: #cp#; }"},

{name: "table-style2-odd-text", selector: "table.style-2 tr:nth-child(odd){ color: #cp#; }"},

{name: "table-style2-even-background", selector: "table.style-2 tr:nth-child(even){ background-color: #cp#; }"},

{name: "table-style2-even-text", selector: "table.style-2 tr:nth-child(even){ color: #cp#; }"},

{name: "blog-title-color", selector: ".cp-blog-title, .cp-blog-title a{ color: #cp#; }"},

{name: "blog-title-hover-color", selector: ".cp-blog-title a:hover{ color: #cp#; }"},

{name: "blog-date-text-color", selector: ".blog-date-wrapper{ color: #cp#; }"},

{name: "blog-date-bottom-border", selector: ".blog-date-wrapper, .blog-date-wrapper *{ border-bottom-color: #cp#; }"},

{name: "blog-info-color", selector: ".blog-info, .blog-info a, .comment-time, .comment-time a{ color: #cp#; }"},

{name: "blog-grid-content-background", selector: ".cp-blog-grid .cp-standard-style{ background-color: #cp#; }"},

{name: "blog-info-icon-color", selector: ".blog-info i, .comment-time i, .comment-reply i{ color: #cp#; }"},

{name: "blog-sticky-background", selector: ".cp-blog-thumbnail .cp-sticky-banner{ background-color: #cp#; }"},

{name: "blog-sticky-text", selector: ".cp-blog-thumbnail .cp-sticky-banner{ color: #cp#; }"},

{name: "blog-tag-background", selector: ".cp-standard-style .cp-single-blog-tag a{ background-color: #cp#; }"},

{name: "blog-tag-text-color", selector: ".cp-standard-style .cp-single-blog-tag a{ color: #cp#; }"},

{name: "blog-aside-background", selector: ".format-aside .cp-blog-content{ background-color: #cp#; }"},

{name: "blog-aside-text", selector: ".format-aside .cp-blog-content{ color: #cp#; }"},

{name: "blog-quote-text-color", selector: ".format-quote .cp-top-quote blockquote{ color: #cp#; }"},

{name: "blog-quote-author-color", selector: ".format-quote .cp-quote-author{ color: #cp#; }"},

{name: "blog-navigation-background", selector: ".cp-single-nav > div i{ background-color: #cp#; }"},

{name: "blog-navigation-text", selector: ".cp-single-nav > div i{ color: #cp#; }"},

{name: "portfolio-filter-button-background", selector: ".portfolio-item-filter a{ background-color: #cp#; }"},

{name: "portfolio-filter-button-text", selector: ".portfolio-item-filter a{ color: #cp#; }"},

{name: "portfolio-filter-button-background-hover", selector: ".portfolio-item-filter a:hover, .portfolio-item-filter a.active{ background-color: #cp#; }"},

{name: "portfolio-filter-button-text-hover", selector: ".portfolio-item-filter a:hover, .portfolio-item-filter a.active{ color: #cp#; }"},

{name: "portfolio-thumbnail-hover-background", selector: ".cp-image-link-shortcode .cp-image-link-overlay, .portfolio-thumbnail .portfolio-overlay{ background-color: #cp#; }"},

{name: "portfolio-title-color", selector: ".portfolio-title a{ color: #cp#; }"},

{name: "portfolio-title-hover-color", selector: ".portfolio-title a:hover{ color: #cp#; }"},

{name: "portfolio-info-color", selector: ".portfolio-info, .portfolio-info a{ color: #cp#; }"},

{name: "modern-portfolio-title-background", selector: ".cp-modern-portfolio .portfolio-content-wrapper{ background-color: #cp#; }"},

{name: "modern-portfolio-title-color", selector: ".portfolio-item-holder .cp-modern-portfolio .portfolio-title a{ color: #cp#; }"},

{name: "pagination-background", selector: ".cp-pagination .page-numbers{ background-color: #cp#; }"},

{name: "pagination-text-color", selector: ".cp-pagination .page-numbers{ color: #cp#; }"},

{name: "pagination-background-hover", selector: ".cp-pagination .page-numbers:hover, .cp-pagination .page-numbers.current{ background-color: #cp#; }"},

{name: "pagination-text-color-hover", selector: ".cp-pagination .page-numbers:hover, .cp-pagination .page-numbers.current{ color: #cp#; }"},

{name: "single-album-playlist-background", selector: ".cp-album-song-list li{ background-color: #cp#; }"},

{name: "album-item-title-background", selector: ".cp-album-item .cp-album-content{ background-color: #cp#; }"},

{name: "album-item-title-background-hover", selector: ".cp-album-item .cp-album-content:hover{ background-color: #cp#; }"},

{name: "album-item-title-text", selector: ".cp-album-item .cp-album-content, .cp-album-item .cp-album-content a{ color: #cp#; }"},

{name: "player-list-background", selector: ".cp-top-player{ background: #cp#; }"},

{name: "player-list-song-title", selector: ".cp-top-player .cp-top-player-title{ color: #cp#; }"},

{name: "player-list-controller-background", selector: ".cp-top-player .mejs-container .mejs-controls{ background: #cp#; }"},

{name: "player-list-song-background", selector: ".cp-player-item .cp-player-list li{ background: #cp#; }"},

{name: "player-list-song-top-border", selector: ".cp-player-item .cp-player-list li, .cp-top-player .mejs-container .mejs-controls{ border-top-color: #cp#; } .cp-top-player .mejs-controls .mejs-time-rail{ border-left-color: #cp#; }"},

{name: "player-list-song-bottom-border", selector: ".cp-player-item .cp-player-list li, .cp-top-player .mejs-container .mejs-controls{ border-bottom-color: #cp#; } .cp-top-player .mejs-button.mejs-playpause-button{ border-right-color: #cp#; }"},

{name: "player-time-rail", selector: ".cp-top-player .mejs-controls .mejs-time-rail .mejs-time-total, .cp-float-player .mejs-controls .mejs-time-rail .mejs-time-total, .cp-float-player .mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-total{ background: #cp#; }"},

{name: "player-time-loaded", selector: ".cp-top-player .mejs-controls .mejs-time-rail .mejs-time-loaded, .cp-top-player .mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-total, .cp-float-player .mejs-controls .mejs-time-rail .mejs-time-loaded{ background: #cp#; }"},

{name: "player-time-current", selector: ".cp-top-player .mejs-controls .mejs-time-rail .mejs-time-current, .cp-top-player .mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-current, .cp-float-player .mejs-controls .mejs-time-rail .mejs-time-current, .cp-float-player .mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-current{ background: #cp#; }"},

{name: "single-event-info-head", selector: ".event-status-wrapper, .cp-single-event .cp-event-info .cp-head{ color: #cp#; }"},

{name: "single-event-title", selector: ".cp-single-event .cp-event-title, .event-status-wrapper .sold-out{ color: #cp#; }"},

{name: "single-event-location", selector: ".cp-single-event .cp-event-location{ color: #cp#; }"},

{name: "widget-event-title", selector: ".cp-widget-event .event-title a{ color: #cp#; }"},

{name: "widget-event-date", selector: ".cp-widget-event .event-date-wrapper{ color: #cp#; }"},

{name: "event-list-date-color", selector: ".cp-list-event .event-date-wrapper{ color: #cp#; }"},

{name: "event-list-title-color", selector: ".cp-list-event .event-location a, .cp-list-event .event-title a{ color: #cp#; }"},

{name: "personnel-box-background", selector: ".cp-personnel-item .personnel-item-inner{ background-color: #cp#; }"},

{name: "personnel-author-text", selector: ".cp-personnel-item .personnel-author{ color: #cp#; }"},

{name: "personnel-author-border", selector: ".cp-personnel-item .personnel-author-image{ border-color: #cp#; }"},

{name: "personnel-position-color", selector: ".cp-personnel-item .personnel-position{ color: #cp#; }"},

{name: "personnel-content-color", selector: ".cp-personnel-item .personnel-content{ color: #cp#; }"},

{name: "personnel-social-icon-color", selector: ".cp-personnel-item .personnel-social i{ color: #cp#; }"},

{name: "testimonial-box-background", selector: ".cp-testimonial-item .testimonial-item-inner, .cp-testimonial-item .testimonial-author-image{ background-color: #cp#; }"},

{name: "testimonial-content-color", selector: ".cp-testimonial-item .testimonial-content{ color: #cp#; }"},

{name: "testimonial-author-text", selector: ".cp-testimonial-item .testimonial-author{ color: #cp#; }"},

{name: "testimonial-author-position", selector: ".cp-testimonial-item .testimonial-position{ color: #cp#; }"},

{name: "testimonial-author-image-border", selector: ".cp-testimonial-item .testimonial-author-image{ border-color: #cp#; }"},

{name: "testimonial-boxed-style-shadow", selector: ".cp-testimonial-item.box-style .testimonial-item-inner:after{ border-top-color: #cp#; border-left-color: #cp#; }"},

{name: "gallery-thumbnail-frame", selector: ".cp-gallery-thumbnail .gallery-item{ background-color: #cp#; }"},

{name: "gallery-caption-background", selector: ".cp-gallery-thumbnail-container .gallery-caption{ background-color: #cp#; }"},

{name: "gallery-caption-text", selector: ".cp-gallery-thumbnail-container .gallery-caption{ color: #cp#; }"},

{name: "slider-bullet-background", selector: ".nivo-controlNav a, .flex-control-paging li a, .ls-flawless .ls-bottom-slidebuttons a{ background-color: #cp#; }"},

{name: "slider-bullet-background-hover", selector: ".nivo-controlNav a:hover, .nivo-controlNav a.active, .flex-control-paging li a:hover, .flex-control-paging li a.flex-active,.ls-flawless .ls-bottom-slidebuttons a.ls-nav-active, .ls-flawless .ls-bottom-slidebuttons a:hover { background-color: #cp#; }"},

{name: "slider-bullet-border", selector: ".nivo-controlNav a, .flex-control-paging li a, .ls-flawless .ls-bottom-slidebuttons a{ border-color: #cp# !important; }"},

{name: "slider-navigation-background", selector: ".nivo-directionNav a, .flex-direction-nav a, .ls-flawless .ls-nav-prev, .ls-flawless .ls-nav-next{ background-color: #cp#; }"},

{name: "slider-navigation-icon", selector: "body .nivo-directionNav a, body .flex-direction-nav a, body .flex-direction-nav a:hover, .ls-flawless .ls-nav-prev, .ls-flawless .ls-nav-next{ color: #cp#; }"},

{name: "slider-caption-background", selector: ".cp-caption{ background-color: #cp#; }"},

{name: "slider-caption-title", selector: ".cp-caption-title{ color: #cp#; }"},

{name: "slider-caption-text", selector: ".cp-caption-text{ color: #cp#; }"},

{name: "post-slider-caption-background", selector: ".cp-caption-wrapper.post-slider{ background-color: #cp#; }"},

{name: "post-slider-caption-title", selector: ".cp-caption-wrapper.post-slider .cp-caption-title{ color: #cp#; }"},

{name: "post-slider-caption-text", selector: ".cp-caption-wrapper.post-slider .cp-caption-text{ color: #cp#; }"},

{name: "slider-outer-navigation-border", selector: ".nav-container.style-1 .flex-direction-nav a{ border-color: #cp#; }"},

{name: "slider-outer-navigation-icon", selector: ".nav-container.style-1 .flex-direction-nav i{ color: #cp#; }"},

{name: "input-box-background", selector: "input[type=\"text\"], input[type=\"email\"], input[type=\"password\"], textarea{ background-color: #cp#; }"},

{name: "input-box-text", selector: "input[type=\"text\"], input[type=\"email\"], input[type=\"password\"], textarea{ color: #cp#; }"},

{name: "footer-top-border-color", selector: ".footer-wrapper{ border-top-color: #cp#; }"},

{name: "footer-background-color", selector: ".footer-wrapper{ background-color: #cp#; }"},

{name: "footer-title-color", selector: ".footer-wrapper .cp-widget-title, .footer-wrapper .cp-widget-title a{ color: #cp#; }"},

{name: "footer-text-color", selector: ".footer-wrapper{ color: #cp#; }"},

{name: "footer-link-color", selector: ".footer-wrapper a{ color: #cp#; }"},

{name: "footer-link-hover-color", selector: ".footer-wrapper a:hover{ color: #cp#; }"},

{name: "footer-border-color", selector: ".footer-wrapper *{ border-color: #cp#; }"},

{name: "footer-input-box-background", selector: ".footer-wrapper input[type=\"text\"], .footer-wrapper input[type=\"email\"], .footer-wrapper input[type=\"password\"], .footer-wrapper textarea{ background-color: #cp#; }"},

{name: "footer-input-box-text", selector: ".footer-wrapper input[type=\"text\"], .footer-wrapper input[type=\"email\"], .footer-wrapper input[type=\"password\"], .footer-wrapper textarea{ color: #cp#; }"},

{name: "footer-tag-cloud-background", selector: ".footer-wrapper .tagcloud a{ background-color: #cp#; }"},

{name: "footer-tag-cloud-text", selector: ".footer-wrapper .tagcloud a, .footer-wrapper .tagcloud a:hover{ color: #cp#; }"},

{name: "cp-copyright-background", selector: ".copyright-wrapper{ background-color: #cp#; }"},

{name: "cp-copyright-text-color", selector: ".copyright-wrapper{ color: #cp#; }"},

{name: "cp-copyright-top-border", selector: ".footer-wrapper .copyright-wrapper{ border-color: #cp#; }"},

{name: "woo-theme-color", selector: "html .woocommerce span.onsale, html .woocommerce-page span.onsale, html .woocommerce-message,html .woocommerce div.product .woocommerce-tabs ul.tabs li.active, html .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active,html .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, html .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active { background: #cp#; }html .woocommerce .star-rating, html .woocommerce-page .star-rating, html .woocommerce .star-rating:before, html .woocommerce-page .star-rating:before, html .woocommerce div.product span.price, html .woocommerce div.product p.price, html .woocommerce #content div.product span.price, html .woocommerce #content div.product p.price, html .woocommerce-page div.product span.price, html .woocommerce-page div.product p.price, html .woocommerce-page #content div.product span.price, html .woocommerce-page #content div.product p.price {color: #cp#; }"},

{name: "woo-text-in-element-color", selector: "html .woocommerce-message a.button, html .woocommerce-error a.button, html .woocommerce-info a.button, html .woocommerce-info a.showcoupon, html .woocommerce-message, html .woocommerce-error, html .woocommerce-info, html .woocommerce span.onsale, html .woocommerce-page span.onsale, html .woocommerce div.product .woocommerce-tabs ul.tabs li.active,html .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, html .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, html .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, html .woocommerce nav.woocommerce-pagination ul li span.current, html .woocommerce-page nav.woocommerce-pagination ul li span.current, html .woocommercenav.woocommerce-pagination ul li a:hover, html .woocommerce-page nav.woocommerce-pagination ul li a:hover{ color: #cp#; }"},

{name: "woo-notification-background", selector: "html .woocommerce-info{ background: #cp#; }"},

{name: "woo-error-background", selector: "html .woocommerce-error{ background: #cp#; }"},

{name: "woo-button-background", selector: "html .woocommerce a.button.alt:hover, html .woocommerce button.button.alt:hover, html .woocommerce input.button.alt:hover, html .woocommerce #respond input#submit.alt:hover, html .woocommerce #content input.button.alt:hover, html .woocommerce-page a.button.alt:hover, html .woocommerce-page button.button.alt:hover, html .woocommerce-page input.button.alt:hover, html .woocommerce-page #respond input#submit.alt:hover, html .woocommerce-page #content input.button.alt:hover, html .woocommerce a.button.alt, html .woocommerce button.button.alt, html .woocommerce input.button.alt, html .woocommerce #respond input#submit.alt, html .woocommerce #content input.button.alt, html .woocommerce-page a.button.alt, html .woocommerce-page button.button.alt, html .woocommerce-page input.button.alt, html .woocommerce-page #respond input#submit.alt, html .woocommerce-page #content input.button.alt, html .woocommerce a.button, html .woocommerce button.button, html .woocommerce input.button, html .woocommerce #respond input#submit, html .woocommerce #content input.button, html .woocommerce-page a.button, html .woocommerce-page button.button, html .woocommerce-page input.button, html .woocommerce-page #respond input#submit, html .woocommerce-page #content input.button, html .woocommerce a.button:hover, html .woocommerce button.button:hover, html .woocommerce input.button:hover, html .woocommerce #respond input#submit:hover, html .woocommerce #content input.button:hover, html .woocommerce-page a.button:hover, html .woocommerce-page button.button:hover, html .woocommerce-page input.button:hover, html .woocommerce-page #respond input#submit:hover, html .woocommerce-page #content input.button:hover, html .woocommerce ul.products li.product a.loading, html .woocommerce div.product form.cart .button, html .woocommerce #content div.product form.cart .button, html .woocommerce-page div.product form.cart .button, html .woocommerce-page #content div.product form.cart .button{ background: #cp#; }"},

{name: "woo-button-text", selector: "html .woocommerce a.button.alt:hover, html .woocommerce button.button.alt:hover, html .woocommerce input.button.alt:hover, html .woocommerce #respond input#submit.alt:hover, html .woocommerce #content input.button.alt:hover, html .woocommerce-page a.button.alt:hover, html .woocommerce-page button.button.alt:hover, html .woocommerce-page input.button.alt:hover, html .woocommerce-page #respond input#submit.alt:hover, html .woocommerce-page #content input.button.alt:hover, html .woocommerce a.button.alt, html .woocommerce button.button.alt, html .woocommerce input.button.alt, html .woocommerce #respond input#submit.alt, html .woocommerce #content input.button.alt, html .woocommerce-page a.button.alt, html .woocommerce-page button.button.alt, html .woocommerce-page input.button.alt, html .woocommerce-page #respond input#submit.alt, html .woocommerce-page #content input.button.alt, html .woocommerce a.button, html .woocommerce button.button, html .woocommerce input.button, html .woocommerce #respond input#submit, html .woocommerce #content input.button, html .woocommerce-page a.button, html .woocommerce-page button.button, html .woocommerce-page input.button, html .woocommerce-page #respond input#submit, html .woocommerce-page #content input.button, html .woocommerce a.button:hover, html .woocommerce button.button:hover, html .woocommerce input.button:hover, html .woocommerce #respond input#submit:hover, html .woocommerce #content input.button:hover, html .woocommerce-page a.button:hover, html .woocommerce-page button.button:hover, html .woocommerce-page input.button:hover, html .woocommerce-page #respond input#submit:hover, html .woocommerce-page #content input.button:hover, html .woocommerce ul.products li.product a.loading, html .woocommerce div.product form.cart .button, html .woocommerce #content div.product form.cart .button, html .woocommerce-page div.product form.cart .button, html .woocommerce-page #content div.product form.cart .button{ color: #cp#; }"},

{name: "woo-button-bottom-border", selector: "html .woocommerce a.button.alt:hover, html .woocommerce button.button.alt:hover, html .woocommerce input.button.alt:hover, html .woocommerce #respond input#submit.alt:hover, html .woocommerce #content input.button.alt:hover, html .woocommerce-page a.button.alt:hover, html .woocommerce-page button.button.alt:hover, html .woocommerce-page input.button.alt:hover, html .woocommerce-page #respond input#submit.alt:hover, html .woocommerce-page #content input.button.alt:hover, html .woocommerce a.button.alt, html .woocommerce button.button.alt, html .woocommerce input.button.alt, html .woocommerce #respond input#submit.alt, html .woocommerce #content input.button.alt, html .woocommerce-page a.button.alt, html .woocommerce-page button.button.alt, html .woocommerce-page input.button.alt, html .woocommerce-page #respond input#submit.alt, html .woocommerce-page #content input.button.alt, html .woocommerce a.button, html .woocommerce button.button, html .woocommerce input.button, html .woocommerce #respond input#submit, html .woocommerce #content input.button, html .woocommerce-page a.button, html .woocommerce-page button.button, html .woocommerce-page input.button, html .woocommerce-page #respond input#submit, html .woocommerce-page #content input.button, html .woocommerce a.button:hover, html .woocommerce button.button:hover, html .woocommerce input.button:hover, html .woocommerce #respond input#submit:hover, html .woocommerce #content input.button:hover, html .woocommerce-page a.button:hover, html .woocommerce-page button.button:hover, html .woocommerce-page input.button:hover, html .woocommerce-page #respond input#submit:hover, html .woocommerce-page #content input.button:hover, html .woocommerce ul.products li.product a.loading, html .woocommerce div.product form.cart .button, html .woocommerce #content div.product form.cart .button, html .woocommerce-page div.product form.cart .button, html .woocommerce-page #content div.product form.cart .button{ border-bottom: 3px solid #cp#; }"},

{name: "woo-border-color", selector: "html .woocommerce #reviews #comments ol.commentlist li img.avatar, html .woocommerce-page #reviews #comments ol.commentlist li img.avatar { background: #cp#; }html .woocommerce #reviews #comments ol.commentlist li img.avatar, html .woocommerce-page #reviews #comments ol.commentlist li img.avatar,html .woocommerce #reviews #comments ol.commentlist li .comment-text, html .woocommerce-page #reviews #comments ol.commentlist li .comment-text,html .woocommerce ul.products li.product a img, html .woocommerce-page ul.products li.product a img, html .woocommerce ul.products li.product a img:hover ,html .woocommerce-page ul.products li.product a img:hover, html .woocommerce-page div.product div.images img, html .woocommerce-page #content div.product div.images img,html .woocommerce form.login, html .woocommerce form.checkout_coupon, html .woocommerce form.register, html .woocommerce-page form.login,html .woocommerce-page form.checkout_coupon, html .woocommerce-page form.register, html .woocommerce table.cart td.actions .coupon .input-text,html .woocommerce #content table.cart td.actions .coupon .input-text, html .woocommerce-page table.cart td.actions .coupon .input-text,html .woocommerce-page #content table.cart td.actions .coupon .input-text { border: 1px solid #cp#; }html .woocommerce div.product .woocommerce-tabs ul.tabs:before, html .woocommerce #content div.product .woocommerce-tabs ul.tabs:before,html .woocommerce-page div.product .woocommerce-tabs ul.tabs:before, html .woocommerce-page #content div.product .woocommerce-tabs ul.tabs:before,html .woocommerce table.shop_table tfoot td, html .woocommerce table.shop_table tfoot th, html .woocommerce-page table.shop_table tfoot td,html .woocommerce-page table.shop_table tfoot th, html .woocommerce table.shop_table tfoot td, html .woocommerce table.shop_table tfoot th,html .woocommerce-page table.shop_table tfoot td, html .woocommerce-page table.shop_table tfoot th { border-bottom: 1px solid #cp#; }html .woocommerce .cart-collaterals .cart_totals table tr:first-child th, html .woocommerce .cart-collaterals .cart_totals table tr:first-child td,html .woocommerce-page .cart-collaterals .cart_totals table tr:first-child th, html .woocommerce-page .cart-collaterals .cart_totals table tr:first-child td { border-top: 3px #cp# solid; }html .woocommerce .cart-collaterals .cart_totals tr td, html .woocommerce .cart-collaterals .cart_totals tr th,html .woocommerce-page .cart-collaterals .cart_totals tr td, html .woocommerce-page .cart-collaterals .cart_totals tr th { border-bottom: 2px solid #cp#; }"},

{name: "woo-secondary-elements", selector: "html .woocommerce div.product .woocommerce-tabs ul.tabs li, html .woocommerce #content div.product .woocommerce-tabs ul.tabs li, html .woocommerce-page div.product .woocommerce-tabs ul.tabs li, html .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li ,html .woocommerce table.cart a.remove, html .woocommerce #content table.cart a.remove, html .woocommerce-page table.cart a.remove, html .woocommerce-page #content table.cart a.remove, html .woocommerce #payment, html .woocommerce-page #payment, html .woocommerce .customer_details,html .woocommerce ul.order_details, html .woocommerce nav.woocommerce-pagination ul li a, html .woocommerce-page nav.woocommerce-pagination ul li a,html .woocommerce form .form-row input.input-text, html .woocommerce form .form-row textarea, html .woocommerce-page form .form-row input.input-text, html .woocommerce-page form .form-row textarea, html .woocommerce .quantity input.qty, html .woocommerce #content .quantity input.qty, html .woocommerce-page .quantity input.qty, html .woocommerce-page #content .quantity input.qty,html .woocommerce .widget_shopping_cart .total, html .woocommerce-page .widget_shopping_cart .total { background: #cp#; }html .woocommerce .quantity input.qty, html .woocommerce #content .quantity input.qty, html .woocommerce-page .quantity input.qty, html .woocommerce-page #content .quantity input.qty { border: 1px solid #cp#; }"},

{name: "woo-secondary-elements-border", selector: "html .woocommerce .widget_shopping_cart .total, html .woocommerce-page .widget_shopping_cart .total { border-top: 2px solid #cp#; }html .woocommerce table.cart a.remove:hover, html .woocommerce #content table.cart a.remove:hover, html .woocommerce-page table.cart a.remove:hover,html .woocommerce-page #content table.cart a.remove:hover, html #payment div.payment_box, html .woocommerce-page #payment div.payment_box { background: #cp#; }"},

{name: "woo-cart-summary-price", selector: "html .woocommerce table.shop_table tfoot td, html .woocommerce table.shop_table tfoot th, html .woocommerce-page table.shop_table tfoot td,html .woocommerce-page table.shop_table tfoot th, .cart-subtotal th, .shipping th , .total th, html .woocommerce table.shop_attributes .alt th,html .woocommerce-page table.shop_attributes .alt th, html .woocommerce ul.products li.product .price, html.woocommerce-page ul.products li.product .price { color: #cp#; }"},

{name: "woo-discount-price", selector: "html .woocommerce ul.products li.product .price del, html .woocommerce-page ul.products li.product .price del,html .woocommerce table.cart a.remove, html .woocommerce #content table.cart a.remove, html .woocommerce-page table.cart a.remove,html .woocommerce-page #content table.cart a.remove { color: #cp#; }"},

{name: "woo-plus-minus-product-border", selector: "html .woocommerce .quantity .plus, html .woocommerce .quantity .minus, html .woocommerce #content .quantity .plus, html .woocommerce #content .quantity .minus, html .woocommerce-page .quantity .plus, html .woocommerce-page .quantity .minus, html .woocommerce-page #content .quantity .plus, html .woocommerce-page #content .quantity .minus { border: 1px solid #cp#; }"},

{name: "woo-plus-minus-product-sign", selector: "html .woocommerce .quantity .plus, html .woocommerce .quantity .minus, html .woocommerce #content .quantity .plus, html .woocommerce #content .quantity .minus, html .woocommerce-page .quantity .plus, html .woocommerce-page .quantity .minus, html .woocommerce-page #content .quantity .plus, html .woocommerce-page #content .quantity .minus { color: #cp#; }"},

{name: "woo-plus-product-background", selector: "html .woocommerce .quantity .plus, html .woocommerce #content .quantity .plus, html .woocommerce-page .quantity .plus,html .woocommerce-page #content .quantity .plus, html .woocommerce .quantity .plus:hover, html .woocommerce #content .quantity .plus:hover,html .woocommerce-page .quantity .plus:hover, html .woocommerce-page #content .quantity .plus:hover{ background: #cp#; }"},

{name: "woo-minus-product-background", selector: "html .woocommerce .quantity .minus, html .woocommerce #content .quantity .minus, html .woocommerce-page .quantity .minus,html .woocommerce-page #content .quantity .minus, html .woocommerce .quantity .minus:hover, html .woocommerce #content .quantity .minus:hover,html .woocommerce-page .quantity .minus:hover, html .woocommerce-page #content .quantity .minus:hover{ background: #cp#; }"},

];

	

	var customizer_style = $('<style id="customizer-style"></style>');

	$("head").append(customizer_style);	

	

	function generate_dynamic_style(index, value){

		color_option[index].style = color_option[index].selector.replace('#cp#', value);

		

		var new_style = '';

		for(var i=0; i<color_option.length; i++){

			if(color_option[i].style){

				new_style += color_option[i].style + '\r\n';

			}

		}

		customizer_style.html(new_style);

	}

	

	// Theme Color Option

	$.each(color_option, function(index, value){

		wp.customize('word_mag_customizer[' + value.name + ']', function(value){

			value.bind(function(to){

				generate_dynamic_style(index, to);

			});

		});		

	

	});

	

	// Site title and description.

	wp.customize('blogname', function(value){

		value.bind(function(to){

			$('.site-title').text(to);

		});

	});

	wp.customize('blogdescription', function(value){

		value.bind(function(to){

			$('.site-description').text(to);

		});

	});

	

})(jQuery);