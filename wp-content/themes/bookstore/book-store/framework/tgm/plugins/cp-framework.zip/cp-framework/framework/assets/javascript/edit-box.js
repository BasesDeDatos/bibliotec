/**
 *	crunchpress Edit Box File
 *	---------------------------------------------------------------------
 * 	@version	1.0
 * 	@author		crunchpress
 * 	@link		http://crunchpress.com
 * 	@copyright	Copyright (c) crunchpress
 * 	---------------------------------------------------------------------
 * 	This file contains the script of the editbox that create overlay over
 *	any elements and copy desired element to be showed in that overlay.
 *	---------------------------------------------------------------------
 */

jQuery(document).ready(function(){
	
	// initialize necessary variables
	var word_mag_div_wrapper = jQuery('#cp-overlay-wrapper');
	var word_mag_edit_box_elements = {
		editbox: '<div id="cp-edit-box">\
					<div id="cp-overlay"></div>\
					<div id="cp-overlay2"></div>\
					<div id="cp-inline-wrapper">\
						<div class="cp-inline-header">\
							<div class="cp-inline-header-wrapper">\
								<div class="cp-inline-header-inner-wrapper" >\
									<div class="cp-inline-header-text"> EDITOR </div>\
									<div id="cp-head-edit-img" class="cp-head-edit-img"></div>\
								</div>\
							</div>\
							<div id="close-cp-edit-box"></div>\
						</div>\
						<div id="cp-inline"></div>\
						<div class="cp-inline-footer">\
							<input type="button" value="Done" id="cp-inline-edit-done" class="cp-button">\
							<br class="clear">\
						</div>\
					</div>\
				</div>',
		opacity: 0.42
	};
	word_mag_div_wrapper.append(word_mag_edit_box_elements.editbox);
	
	var word_mag_editbox = word_mag_div_wrapper.find('#cp-edit-box');
	var word_mag_content = word_mag_editbox.siblings('#cp-overlay-content');
	var word_mag_overlay = word_mag_editbox.find('#cp-overlay');
	var word_mag_inline = word_mag_editbox.find('#cp-inline');
	var word_mag_clicked_item = '';
	var word_mag_item_size = '';
	var word_mag_edit_item = '';
	var word_mag_clone_item = '';
	
	// bind the initialize elements
	word_mag_editbox.children().css('display','none');
	word_mag_overlay.css('opacity',word_mag_edit_box_elements.opacity);
	jQuery('#close-cp-edit-box').click(function(){
		word_mag_close_editbox();
	});
	jQuery('#cp-inline-edit-done').click(function(){
		word_mag_close_editbox(); 
	});	
	jQuery('div[rel="cp-edit-box"]').click(function(){
		word_mag_clicked_item = jQuery(this);
		word_mag_item_size = word_mag_clicked_item.parents('#page-element-item').find('#element-size-text').html();
		word_mag_item_size = parseInt(word_mag_item_size.substr(0,1))  /  parseInt(word_mag_item_size.substr(2,1));
		word_mag_open_editbox();
	});
	jQuery('input#publish[name="save"]').click(function(){
		word_mag_close_editbox();
	});
	
	// copy the content and open the edit box to use
	function word_mag_open_editbox(){
		clicked_id = word_mag_clicked_item.attr('id');
		word_mag_edit_item = word_mag_clicked_item.parents('#page-element-item').siblings('#' + clicked_id);
		word_mag_clone_item = word_mag_edit_item.children().clone(true);
		
		var li_cloned = word_mag_clone_item.find('div.selected-image ul').children().clone(true);
		li_cloned = jQuery('<ul></ul>').append(li_cloned);
		word_mag_clone_item.find('div.selected-image ul').replaceWith(li_cloned)
		word_mag_clone_item.find('div.selected-image ul').sortable({ tolerance: 'pointer', forcePlaceholderSize: true, placeholder: 'slider-placeholder', cancel: '.slider-detail-wrapper' });

		//word_mag_clone_item.css('display','block');
		
		// Remove unnecessary size
		word_mag_clone_item.find("#page-option-item-testimonial-size, #page-option-item-portfolio-size, \
			#page-option-item-blog-size, #page-option-item-page-size").children("option").each(function(){
			var item_size = jQuery(this).html();
			
			if(item_size == "Widget Style"){
				item_size = 1/8;
			}else{
				item_size = parseInt(item_size.substr(0,1))  /  parseInt(item_size.substr(2,1));
			}
			
			if(word_mag_item_size >= item_size){
				jQuery(this).css('display','block');
			}else{
				jQuery(this).css('display','none');
			}
		});
		
		word_mag_inline.append(word_mag_clone_item);
		
		// Open Process
		word_mag_editbox.children().fadeIn(600);
		word_mag_content.hide(function(){
			jQuery(this).css('position','absolute');
			jQuery(this).show();
		});
		
	}
	
	// manipulate the edited content and close editbox 
	function word_mag_close_editbox(){
		var word_mag_edited_item = word_mag_inline.children().clone(true);
		if(word_mag_edit_item){
			word_mag_edit_item.html(word_mag_edited_item);
		}
		word_mag_clear_editbox();
	}
	
	// clear the editbox variables and internal content
	function word_mag_clear_editbox(){
		word_mag_content.hide(0, function(){
			word_mag_content.css('position','relative');
			word_mag_content.slideDown(600);
			word_mag_editbox.children().fadeOut( function(){
				word_mag_inline.children().remove();
				word_mag_edit_item = '';
				word_mag_clone_item = '';
				word_mag_clicked_item = '';
			});
		});
	}

	jQuery.fn.bindEditBox = function(){
		word_mag_clicked_item = jQuery(this);
		word_mag_open_editbox();
	}
});

// Fix the clone problem of <textarea> and <select> elements
(function (original) {
  jQuery.fn.clone = function () {
    var       result = original.apply (this, arguments),
        my_textareas = this.find('textarea, select'),
    result_textareas = result.find('textarea, select');

    for (var i = 0, l = my_textareas.length; i < l; ++i)
      jQuery(result_textareas[i]).val (jQuery(my_textareas[i]).val());

    return result;
  };
}) (jQuery.fn.clone);

