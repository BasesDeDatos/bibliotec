(function() {  
    tinymce.create('tinymce.plugins.word_mag_gallery', {  
        init : function(ed, url) {  
            ed.addButton('word_mag_gallery', {  
                title : 'Add Gallery',  
                image : url + '/images/cp-gallery.png',  
                onclick : function() {  
					ed.focus();
                    ed.selection.setContent('[word_mag_gallery title="GALLERY_TITLE" width="IMAGE_SRC" height="IMAGE_HEIGHT" ]<br/>');  
                }  
            });  
        },  
        createControl : function(n, cm) {  
            return null;  
        }
    });  
    tinymce.PluginManager.add('word_mag_gallery', tinymce.plugins.word_mag_gallery);  
})(); 