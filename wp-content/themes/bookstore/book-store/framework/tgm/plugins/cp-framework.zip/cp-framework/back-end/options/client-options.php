<?php

	/*	
	*	CrunchPress Client Option File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		CrunchPress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) CrunchPress
	*	---------------------------------------------------------------------
	*	This file create and contains the portfolio post_type meta elements
	*	---------------------------------------------------------------------
	*/ 
	
	add_action( 'init', 'create_client' );
	function create_client() {
		$artist_translation = get_option(PLUGIN_NAME_S.'_cp_client_slug','client');
		
		$labels = array(
			'name' => _x('Client', 'Client General Name', 'crunchpress'),
			'singular_name' => _x('Client Item', 'Client Singular Name', 'crunchpress'),
			'add_new' => _x('Add New', 'Add New Client Name', 'crunchpress'),
			'add_new_item' => __('Add New Client', 'crunchpress'),
			'edit_item' => __('Edit Client', 'crunchpress'),
			'new_item' => __('New Client', 'crunchpress'),
			'view_item' => __('View Client', 'crunchpress'),
			'search_items' => __('Search Client', 'crunchpress'),
			'not_found' =>  __('Nothing found', 'crunchpress'),
			'not_found_in_trash' => __('Nothing found in Trash', 'crunchpress'),
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			//'menu_icon' => CP_PATH_URL . '/framework/images/artist-icon.png',
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => 5,
			'supports' => array('title','thumbnail'),
			'rewrite' => array('slug' => $artist_translation, 'with_front' => false)
		  ); 
		  
		register_post_type( 'client' , $args);
		
		
	}
	
	
function client_link_get_meta( $value ) {
	global $post;

	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}

function client_link_add_meta_box() {
	add_meta_box(
		'client_link-client-link',
		__( 'Client Link', 'client_link' ),
		'client_link_client_link_html',
		'client',
		'normal',
		'default'
	);
}
add_action( 'add_meta_boxes', 'client_link_add_meta_box' );

function client_link_client_link_html( $post) {
	wp_nonce_field( '_client_link_client_link_nonce', 'client_link_client_link_nonce' ); ?>

	<p>
		<label for="client_link_client_link_client_link"><?php _e( 'Client URL', 'client_link' ); ?></label><br>
		<input type="text" name="client_link_client_link_client_link" id="client_link_client_link_client_link" value="<?php echo client_link_get_meta( 'client_link_client_link_client_link' ); ?>">
	</p><?php
}

function client_link_client_link_save( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! isset( $_POST['client_link_client_link_nonce'] ) || ! wp_verify_nonce( $_POST['client_link_client_link_nonce'], '_client_link_client_link_nonce' ) ) return;
	if ( ! current_user_can( 'edit_post' ) ) return;

	if ( isset( $_POST['client_link_client_link_client_link'] ) )
		update_post_meta( $post_id, 'client_link_client_link_client_link', esc_attr( $_POST['client_link_client_link_client_link'] ) );
}
add_action( 'save_post', 'client_link_client_link_save' );

/*
	Usage: client_link_get_meta( 'client_link_client_link_client_link' )
*/


	
?>