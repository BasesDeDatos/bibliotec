(function($){
	 "use strict";
	$(document).ready(function(){
		$('#description, #tag-description').parents('.form-field').hide();
	});
})(jQuery);