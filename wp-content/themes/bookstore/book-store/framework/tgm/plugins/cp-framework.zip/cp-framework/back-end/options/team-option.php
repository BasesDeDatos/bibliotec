<?php

	/*	
	*	CrunchPress Team Option File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		CrunchPress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) CrunchPress
	*	---------------------------------------------------------------------
	*	This file create and contains the portfolio post_type meta elements
	*	---------------------------------------------------------------------
	*/
	
	add_action( 'init', 'create_team' );
	function create_team() {
		$artist_translation = get_option(PLUGIN_NAME_S.'_cp_team_slug','team');
		
		$labels = array(
			'name' => _x('Team', 'Team General Name', 'crunchpress'),
			'singular_name' => _x('Team Item', 'Team Singular Name', 'crunchpress'),
			'add_new' => _x('Add New', 'Add New Team Name', 'crunchpress'),
			'add_new_item' => __('Add New Team', 'crunchpress'),
			'edit_item' => __('Edit Team', 'crunchpress'),
			'new_item' => __('New Team', 'crunchpress'),
			'view_item' => __('View Team', 'crunchpress'),
			'search_items' => __('Search Team', 'crunchpress'),
			'not_found' =>  __('Nothing found', 'crunchpress'),
			'not_found_in_trash' => __('Nothing found in Trash', 'crunchpress'),
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			//'menu_icon' => CP_PATH_URL . '/framework/images/artist-icon.png',
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => 5,
			'supports' => array('title','editor','thumbnail'),
			'rewrite' => array('slug' => $artist_translation, 'with_front' => false)
		  ); 
		  
		register_post_type( 'team' , $args);
		
		register_taxonomy(
			"team-cat", array("team"), array(
				"hierarchical" => true,
				"label" => "Team Categories", 
				"singular_label" => "Team Categories", 
				"rewrite" => true));
		register_taxonomy_for_object_type('team-cat', 'artist');
	}
	

function team_options_get_meta( $value ) {
	global $post;

	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}

function team_options_add_meta_box() {
	add_meta_box(
		'team_options-team-options',
		__( 'Team Options', 'team_options' ),
		'team_options_team_options_html',
		'team',
		'normal',
		'default'
	);
}
add_action( 'add_meta_boxes', 'team_options_add_meta_box' );

function team_options_team_options_html( $post) {
	wp_nonce_field( '_team_options_team_options_nonce', 'team_options_team_options_nonce' ); ?>

	<p>
		<label for="team_options_team_options_position"><?php _e( 'Position', 'team_options' ); ?></label><br>
		<input type="text" name="team_options_team_options_position" id="team_options_team_options_position" value="<?php echo team_options_get_meta( 'team_options_team_options_position' ); ?>">
	</p>	<p>
		<label for="team_options_team_options_facebook"><?php _e( 'Facebook', 'team_options' ); ?></label><br>
		<input type="text" name="team_options_team_options_facebook" id="team_options_team_options_facebook" value="<?php echo team_options_get_meta( 'team_options_team_options_facebook' ); ?>">
	</p>	<p>
		<label for="team_options_team_options_twitter"><?php _e( 'Twitter', 'team_options' ); ?></label><br>
		<input type="text" name="team_options_team_options_twitter" id="team_options_team_options_twitter" value="<?php echo team_options_get_meta( 'team_options_team_options_twitter' ); ?>">
	</p>	<p>
		<label for="team_options_team_options_linkedin"><?php _e( 'Linkedin', 'team_options' ); ?></label><br>
		<input type="text" name="team_options_team_options_linkedin" id="team_options_team_options_linkedin" value="<?php echo team_options_get_meta( 'team_options_team_options_linkedin' ); ?>">
	</p>	<p>
		<label for="team_options_team_options_google_"><?php _e( 'Google+', 'team_options' ); ?></label><br>
		<input type="text" name="team_options_team_options_google_" id="team_options_team_options_google_" value="<?php echo team_options_get_meta( 'team_options_team_options_google_' ); ?>">
	</p><?php
}

function team_options_team_options_save( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! isset( $_POST['team_options_team_options_nonce'] ) || ! wp_verify_nonce( $_POST['team_options_team_options_nonce'], '_team_options_team_options_nonce' ) ) return;
	if ( ! current_user_can( 'edit_post' ) ) return;

	if ( isset( $_POST['team_options_team_options_position'] ) )
		update_post_meta( $post_id, 'team_options_team_options_position', esc_attr( $_POST['team_options_team_options_position'] ) );
	if ( isset( $_POST['team_options_team_options_facebook'] ) )
		update_post_meta( $post_id, 'team_options_team_options_facebook', esc_attr( $_POST['team_options_team_options_facebook'] ) );
	if ( isset( $_POST['team_options_team_options_twitter'] ) )
		update_post_meta( $post_id, 'team_options_team_options_twitter', esc_attr( $_POST['team_options_team_options_twitter'] ) );
	if ( isset( $_POST['team_options_team_options_linkedin'] ) )
		update_post_meta( $post_id, 'team_options_team_options_linkedin', esc_attr( $_POST['team_options_team_options_linkedin'] ) );
	if ( isset( $_POST['team_options_team_options_google_'] ) )
		update_post_meta( $post_id, 'team_options_team_options_google_', esc_attr( $_POST['team_options_team_options_google_'] ) );
}
add_action( 'save_post', 'team_options_team_options_save' );

/*
	Usage: team_options_get_meta( 'team_options_team_options_position' )
	Usage: team_options_get_meta( 'team_options_team_options_facebook' )
	Usage: team_options_get_meta( 'team_options_team_options_twitter' )
	Usage: team_options_get_meta( 'team_options_team_options_linkedin' )
	Usage: team_options_get_meta( 'team_options_team_options_google_' )
*/

?>