<?php

	/*	
	*	CrunchPress Services Option File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		CrunchPress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) CrunchPress
	*	---------------------------------------------------------------------
	*	This file create and contains the portfolio post_type meta elements
	*	---------------------------------------------------------------------
	*/
	
	add_action( 'init', 'create_service' );
	function create_service() {
		$artist_translation = get_option(PLUGIN_NAME_S.'_cp_service_slug','service');
		
		$labels = array(
			'name' => _x('Services', 'Service General Name', 'crunchpress'),
			'singular_name' => _x('Service Item', 'Service Singular Name', 'crunchpress'),
			'add_new' => _x('Add New', 'Add New Service Name', 'crunchpress'),
			'add_new_item' => __('Add New Service', 'crunchpress'),
			'edit_item' => __('Edit Service', 'crunchpress'),
			'new_item' => __('New Service', 'crunchpress'),
			'view_item' => __('View Service', 'crunchpress'),
			'search_items' => __('Search Service', 'crunchpress'),
			'not_found' =>  __('Nothing found', 'crunchpress'),
			'not_found_in_trash' => __('Nothing found in Trash', 'crunchpress'),
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			//'menu_icon' => CP_PATH_URL . '/framework/images/artist-icon.png',
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => 5,
			'supports' => array('title','editor','thumbnail'),
			'rewrite' => array('slug' => $artist_translation, 'with_front' => false)
		  ); 
		  
		register_post_type( 'service' , $args);
		
		register_taxonomy(
			"service-cat", array("service"), array(
				"hierarchical" => true,
				"label" => "Service Categories", 
				"singular_label" => "Service Categories", 
				"rewrite" => true));
		register_taxonomy_for_object_type('service-cat', 'artist');
	}
	
	
function services_options_get_meta( $value ) {
	global $post;

	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}

function services_options_add_meta_box() {
	add_meta_box(
		'services_options-services-options',
		__( 'Services Options', 'services_options' ),
		'services_options_services_options_html',
		'service',
		'normal',
		'default'
	);
}
add_action( 'add_meta_boxes', 'services_options_add_meta_box' );

function services_options_services_options_html( $post) {
	wp_nonce_field( '_services_options_services_options_nonce', 'services_options_services_options_nonce' ); ?>

	<p>
		<label for="services_options_services_options_font_awaysome_icon_name_"><?php _e( 'Font Awaysome Icon name.', 'services_options' ); ?></label><br>
		<input type="text" name="services_options_services_options_font_awaysome_icon_name_" id="services_options_services_options_font_awaysome_icon_name_" value="<?php echo services_options_get_meta( 'services_options_services_options_font_awaysome_icon_name_' ); ?>">
	</p>	<p>
		<label for="services_options_services_options_service_link"><?php _e( 'Service Link', 'services_options' ); ?></label><br>
		<input type="text" name="services_options_services_options_service_link" id="services_options_services_options_service_link" value="<?php echo services_options_get_meta( 'services_options_services_options_service_link' ); ?>">
	</p><?php
}

function services_options_services_options_save( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! isset( $_POST['services_options_services_options_nonce'] ) || ! wp_verify_nonce( $_POST['services_options_services_options_nonce'], '_services_options_services_options_nonce' ) ) return;
	if ( ! current_user_can( 'edit_post' ) ) return;

	if ( isset( $_POST['services_options_services_options_font_awaysome_icon_name_'] ) )
		update_post_meta( $post_id, 'services_options_services_options_font_awaysome_icon_name_', esc_attr( $_POST['services_options_services_options_font_awaysome_icon_name_'] ) );
	if ( isset( $_POST['services_options_services_options_service_link'] ) )
		update_post_meta( $post_id, 'services_options_services_options_service_link', esc_attr( $_POST['services_options_services_options_service_link'] ) );
}
add_action( 'save_post', 'services_options_services_options_save' );

/*
	Usage: services_options_get_meta( 'services_options_services_options_font_awaysome_icon_name_' )
	Usage: services_options_get_meta( 'services_options_services_options_service_link' )
*/


?>