<?php 

	/*
	Plugin Name: Cp Framework (Word Mag)
	Plugin URI: http://crunchpress.com/cp-framework
	Description: A simple and easy way to test your theme for all the latest WordPress standards and practices. A great theme development tool!
	Author: Nasir Hayat
	Author URI: http://nasirhayat.com
	Version: 1.0
	*/
	
	// constants
	define('CP_PATH_URL', plugin_dir_url(__FILE__),'cp-framework');           // logical location for CP framework
	define('CP_PATH_SER', plugin_dir_path( __FILE__));                          // Physical location for CP framework
	define( 'FW_BE_URL', CP_PATH_URL . 'back-end' );             // Define URL path of framework directory
	define( 'FW_BE_SER', CP_PATH_SER . 'back-end' );                 // Define server path of framework directory
	
	$word_mag_my_theme = wp_get_theme();
		
	define('THEME_NAME', $word_mag_my_theme->get( 'Name' ));
	define('AJAX_URL', admin_url( 'admin-ajax.php' ));             // Define admin url
	
	define('FONT_SAMPLE_TEXT', 'Font Family'); 				       // Demo font text of the crunchpress panel
	
	define('word_mag','cp');                                   // Short name of theme (used for various purpose in CP framework)
	define('THEME_NAME_F','Word Mag');                            // Full name of theme (used for various purpose in CP framework)
	
    define('IS_word_mag_POSTS','Active' );
	// dashboard option
	
	//include_once(FW_BE_SER. '/options/testimonial-option.php');							// Register meta fields testimonial post_type
	include_once(FW_BE_SER. '/options/service-option.php'); 						// Register meta fields	price post_type
	//include_once(FW_BE_SER. '/options/brand-options.php'); 
	include_once(FW_BE_SER. '/options/team-option.php');
	//include_once(FW_BE_SER. '/options/client-options.php');
	//include_once(FW_BE_SER. '/options/gallery-option.php');
	//include_once(CP_PATH_SER. '/shortcodes/shortcodes.php');
	
	require_once(CP_PATH_SER. '/framework/cp-option.php' );
	require_once(CP_PATH_SER. '/framework/script-handler.php');
	require_once(CP_PATH_SER. '/framework/extensions/filo-sofo.php');
	
	define('PLUGIN_NAME_S','cp' );	
	
	
	if(is_admin()){	
		require_once( CP_PATH_SER. '/framework/extensions/cutom_meta_boxes.php' );
		require_once( CP_PATH_SER. '/framework/extensions/fontloader.php' );
		require_once( CP_PATH_SER. '/framework/options/meta-template.php' );
		require_once( CP_PATH_SER. '/framework/options/post-option.php' );
	 	require_once( CP_PATH_SER. '/framework/options/page-option.php' );
	   }
       require_once( CP_PATH_SER. '/framework/extensions/super-object.php' );
	
	   function themeple_ajax_dummy_data(){
		 if (defined('IS_word_mag_POSTS')) {
		     require_once(  CP_PATH_SER. '/framework/extensions/importer/dummy_data.inc.php' );
			die('themeple_dummy');
		 }
	   }
	   add_action('wp_ajax_themeple_ajax_dummy_data', 'themeple_ajax_dummy_data');
