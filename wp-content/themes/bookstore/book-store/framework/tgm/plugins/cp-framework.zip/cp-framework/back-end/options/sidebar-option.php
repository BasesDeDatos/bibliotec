<?php

add_action('init', 'theme_create_post_type_sidebar');

function theme_create_post_type_sidebar() 
{
	$labels = array(
		'name' => __( 'Sidebars','the-movers'),
		'singular_name' => __( 'Sidebar','the-movers' ),
		'add_new' => __('Add New','the-movers'),
		'add_new_item' => __('Add New Sidebar','the-movers'),
		'edit_item' => __('Edit Sidebar','the-movers'),
		'new_item' => __('New Sidebar','the-movers'),
		'view_item' => __('View Sidebar','the-movers'),
		'search_items' => __('Search Sidebar','the-movers'),
		'not_found' => __('No sidebar found','the-movers'),
		'not_found_in_trash' => __('No sidebar found in Trash','the-movers'), 
		'parent_item_colon' => ''
	);

	$args = array(
		'labels' => $labels,
		'public' => false,
		'publicly_queryable' => false,
		'exclude_from_search' => true,
		'show_ui' => true,
		'query_var' => false,
		'can_export' => true,
		'rewrite' => false,
		'hierarchical' => false,
		'has_archive' => false,
		'show_in_nav_menus' => false,
		'supports' => array('title', 'excerpt')
	); 
	register_post_type( 'sidebar' , $args );
}


#
#Prod edit columns
#
function prod_edit_columns_sidebar($columns)
{
	$columns = array();
	$columns['cb'] = '<input type=\'checkbox\' />';
	$columns['sidebar_name'] = __('Name', 'the-movers');
	$columns['sidebar_shortcode'] = __('Shortcode', 'the-movers');
	$columns['sidebar_desc'] = __('Description', 'the-movers');
	$columns['sidebar_actions'] = __('Actions', 'the-movers');
	
	return $columns;
}



#
#Prod custom columns
#
function prod_custom_columns_sidebar($column)
{
	global $post;

	$name = get_the_title();
	$shortcode = '[sidebar id="'.$post->ID.'"]';
	$desc = get_the_excerpt();

	switch ($column)
	{
		case 'sidebar_name' :	
			echo '<p>'. $name .'</p>';	
		break;
		
		case 'sidebar_shortcode' :	
			echo '<p><span>'. $shortcode .'</span></p>';	
		break;
		
		case 'sidebar_desc' :	
			echo '<p>'. $desc .'</p>';	
		break;	

		case 'sidebar_actions' :	
			echo '<p><a href="'. admin_url('post.php?post='.$post->ID.'&action=edit'). '">'. __('Edit', 'the-movers'). '</a></p>';			
		break;		
	}
}



#
#Remove meta boxes
#
function theme_sidebar_meta_boxes() {
	remove_meta_box( 'slugdiv', 'sidebar' , 'normal' );
	
}


add_action('init', 'theme_create_post_type_slideshow');
add_filter('manage_edit-slideshow_columns', 'prod_edit_columns_slideshow');
add_action('manage_posts_custom_column',  'prod_custom_columns_slideshow');

function theme_create_post_type_slideshow() 
{
	$labels = array(
		'name' => __( 'Slides', 'the-movers'),
		'singular_name' => __( 'Slides', 'the-movers' ),
		'add_new' => __('Add New', 'the-movers'),
		'add_new_item' => __('Add New Slide', 'the-movers'),
		'edit_item' => __('Edit Slide', 'the-movers'),
		'new_item' => __('New Slide', 'the-movers'),
		'view_item' => __('View Slide', 'the-movers'),
		'search_items' => __('Search Slide', 'the-movers'),
		'not_found' => __('No slides found', 'the-movers'),
		'not_found_in_trash' => __('No slides found in Trash', 'the-movers')
	);

	$args = array(
		'labels' => $labels,
		'public' => false,
		'publicly_queryable' => false,
		'exclude_from_search' => true,
		'show_ui' => true,
		'query_var' => false,
		'can_export' => true,
		'rewrite' => false,
		'hierarchical' => false,
		'has_archive' => false,
		'show_in_nav_menus' => false,
		'capability_type' => 'post',
		'menu_position' => 5, 
		'supports' => array('title', 'page-attributes', 'thumbnail', 'editor')
	); 

	register_post_type( 'slideshow' , $args );
}


function prod_edit_columns_slideshow($columns)
{
	$newcolumns = array(
		'cb' => '<input type=\"checkbox\" />',
		'slideshow_id' => __('ID',  'the-movers'),
		'slideshow_thumbnail' => __('Featured Image',  'the-movers'),
		'title' => __('Title',  'the-movers')
	);
	
	$columns= array_merge($newcolumns, $columns);
	
	return $columns;
}


function prod_custom_columns_slideshow($column)
{
	
	global $post;

	$id = $post->ID;

	switch ($column)
	{
		case 'slideshow_id':
		echo '<p>'. $id .'</p>';	
		break;	

		case 'slideshow_thumbnail':
		if ( has_post_thumbnail() ) { the_post_thumbnail('archive-thumb'); } else { echo __('No featured image',  'the-movers'); }
		break;	
	}
	
}



/********************************************
 Theme sidebar
********************************************/
if ( !function_exists( 'od_sidebar' ) )
{
	function od_sidebar($type, $sidebar_id) 
	{
		//$sidebar_id = get_meta_option('custom_sidebar');

	/*	echo '<aside id="sidebar" class="side-widget-area four column">'."\n";
		echo '<div class="inner">';
*/
		if($sidebar_id) 
		{
			dynamic_sidebar('custom-widget-area-'.$sidebar_id);
		}
		else
		{
			dynamic_sidebar($type.'-widget-area'); 
		}

		/*echo '</div>';
		echo '</aside>'."\n";*/
	}
}






/********************************************
 Custom sidebar shortcode
********************************************/
if ( !function_exists( 'theme_sidebar_shortcode' ) )
{
	function theme_sidebar_shortcode($atts, $content = null) 
	{
		extract(shortcode_atts(
			array(
            'id' => ''
		), $atts));

		$output = '';
		if($id)
		{
			$output .= '<div class="custom-widget-area">'."\n";
			ob_start();  dynamic_sidebar('custom-widget-area-'.$id); $output .= ob_get_clean();
			$output .= '</div>'."\n";
		}

		return $output;
	}

	add_shortcode('sidebar', 'theme_sidebar_shortcode');
}



?>