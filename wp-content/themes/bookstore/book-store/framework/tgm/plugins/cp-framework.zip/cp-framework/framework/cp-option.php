<?php

	/*	
	*	crunchpress Options File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		crunchpress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) crunchpress
	*	---------------------------------------------------------------------
	*	This file contains the crunchpress panel elements and create the 
	*	crunchpress panel at the back-end of the framework
	*	---------------------------------------------------------------------
	*/
	
		
	// crunchpress panel navigation elements
	
         $crunchpress_menu = array(				
		    'General' => array(
		    'Logo'=>'word_mag_panel_logo',
			'Favicon'=>'word_mag_panel_favicon',
			//'RTL'=>'word_mag_panel_rtl',
		    esc_html__('Social Profiles', 'word-mag')=>'word_mag_panel_social_network',
			),
		'Layout' => array(
			'Page Style'=>'word_mag_panel_page_style',
			'Footer Options'=>'word_mag_panel_footer_style',
			),
		'Styling' => array(
			//'Colors'=>'word_mag_panel_load_other_color',
			'Background'=>'word_mag_panel_background',
			'Custom Styling'=>'word_mag_panel_custom_style',
			),	
		'Sidebar'=> array(
			'Sidebar Generator'=>'word_mag_panel_sidebar',
			),	
		'Typography' => array(
			'Font Family'=>'word_mag_panel_font',
			'Font Size'=>'word_mag_panel_font_size',
			'Upload Font'=>'word_mag_panel_upload_font'),
		/*'Sliders' => array(
			'Nivo Slider'=>'word_mag_panel_nivo_slider',
			'Flex Slider'=>'word_mag_panel_flex_slider'),*/
		    'Dummy Content' => array(
			'Dummy Content'=>'word_mag_panel_dummy_content'),
	);
	
	$woo_options_arr= array(	
	/*	 esc_html__('WooCommerce', 'word-mag') => array(
			esc_html__('Products Page Style', 'word-mag')=>'word_mag_panel_products_page',
			esc_html__('Products Page Title', 'word-mag')=>'word_mag_panel_products_page_title',
			esc_html__('Install', 'word-mag')=>'word_mag_panel_products_page_hmk',
			),*/
 	 );	
	
	// WooCommerce Options Array
    $woo_options_arr= array(	
		/* esc_html__('WooCommerce', 'word-mag') => array(
			esc_html__('Shop Page Options', 'word-mag')=>'word_mag_panel_products_page',
		),*/
 	);	
	
	// WooCommerce Options Array when not installed
    $woo_options_arr_not_installed= array(	
		/* esc_html__('WooCommerce', 'word-mag') => array(
		 esc_html__('Install', 'word-mag')=>'word_mag_panel_products_page_hmk',
		),*/
 	);	
	
	// WooCommerce Options Array
	$woo_elements_arr= array(
		'word_mag_panel_products_page' => array(
		
		   esc_html__('ITEM FETCH', 'word-mag')=>array(
				'type'=>'inputtext',
				'name'=>'word_mag'.'_products_item_fetch',
				'default'=>'12',
				'description'=>'Input the number of item you want to display at shop page'),
			esc_html__('PAGINATION', 'word-mag')=>array(
				'type'=>'combobox',
				'name'=>'word_mag'.'_products_navi',
				'options'=>array('No', 'Yes'),
				'description'=>'Display pagination on product page'),
				),
		'word_mag_panel_products_page_hmk' => array(		
	      	    esc_html__('Please Activate the Woocommerce to see thoese options', 'word-mag')=>array(
				'type'=>'notice'
				)),
	);	
			
			
	// crunchpress panel elements ( the head of array links to the menu of navigation elements )
	$crunchpress_element = array(
		//General
		'word_mag_panel_page_style' => array(
		   esc_html__('SEARCH/ARCHIVE SIDEBAR', 'word-mag')=>array(
				'type'=>'radioimage',
				'name'=>'word_mag'.'_search_archive_sidebar',
				'default'=>'no-sidebar',
				'options'=>array(
					'1'=>array('value'=>'right-sidebar','default'=>'selected','image'=>'/framework/assets/images/right-sidebar.png'),
					'2'=>array('value'=>'left-sidebar','image'=>'/framework/assets/images/left-sidebar.png'),
					/*'3'=>array('value'=>'both-sidebar','image'=>'/framework/assets/images/both-sidebar.png'),*/
					'4'=>array('value'=>'no-sidebar','image'=>'/framework/assets/images/no-sidebar.png'))),
			esc_html__('SEARCH/ARCHIVE FULL BLOG CONTENT', 'word-mag')=>array(
				'type'=>'combobox',
				'name'=>'word_mag'.'_search_archive_full_blog_content',
				'options'=>array('No', 'Yes'),
				'description'=>'Use this to show full content of the blog in search/archive page. Only use with 1/1 Full Thumbnail'),
			esc_html__('SEARCH/ARCHIVE EXCERPT NUM', 'word-mag')=>array(
				'type'=>'inputtext',
				'name'=>'word_mag'.'_search_archive_num_excerpt',
				'default'=>'285',
				'description'=>'Input the number of characters you want for the length of excerpt of search and archive page.'),
				),
				'word_mag_panel_sidebar' => array(
					esc_html__('CREATE SIDEBAR', 'word-mag')=>array('type'=>'sidebar','name'=>'word_mag'.'_create_sidebar')
				),
				'word_mag_panel_rtl' => array(
				esc_html__('RIGHT TO LEFT TEXT SUPPORT', 'word-mag')=>array('type'=>'radioenabled', 'name'=> 'word_mag'.'_rtl','default'=>'disable','description'=>'Enable Right-to-Left Language Support (Support for Arabic, Urdu, Persion etc).'),
		),
								
		'word_mag_panel_footer_style' => array(
			esc_html__('CHOOSE FOOTER STYLE', 'word-mag')=>array(
				'type'=>'radioimage',
				'name'=>'word_mag'.'_footer_style', 
				'default'=>'footer-style4',
				'options'=>array(
					'1'=>array('value'=>'footer-style1','image'=>'/framework/assets/images/footer-style1.png'),
					'4'=>array('value'=>'footer-style4','image'=>'/framework/assets/images/footer-style6.png'),
					
			)),
		   esc_html__('SHOW FOOTER', 'word-mag')=>array('type'=>'radioenabled', 'name'=> 'word_mag'.'_show_footer'),
		
		    esc_html__('SHOW COPYRIGHT', 'word-mag')=>array('type'=>'radioenabled', 'name'=> 'word_mag'.'_show_copyright'),
		    
			esc_html__('COPYRIGHT LEFT AREA', 'word-mag')=>array('type'=>'textarea','name'=>'word_mag'.'_copyright_left_area','default'=>'Copyright &copy; 2015. Designed by
				<a href="http://crunchpress.com/">crunchpress.com</a>'), 
			
		),

		'word_mag_panel_favicon' => array(
			esc_html__('UPLOAD FAVICON ICON', 'word-mag')=>array('type'=>'upload','name'=> 'word_mag'.'_favicon_image'),
		),
		//Theme Style
		'word_mag_panel_font_size' => array(
			esc_html__('H1 SIZE', 'word-mag')=>array('type'=>'sliderbar','name'=>'word_mag'.'_h1_size','default'=>'30'),
			esc_html__('H2 SIZE', 'word-mag')=>array('type'=>'sliderbar','name'=>'word_mag'.'_h2_size','default'=>'25'),
			esc_html__('H3 SIZE', 'word-mag')=>array('type'=>'sliderbar','name'=>'word_mag'.'_h3_size','default'=>'20'),
			esc_html__('H4 SIZE', 'word-mag')=>array('type'=>'sliderbar','name'=>'word_mag'.'_h4_size','default'=>'18'),
			esc_html__('H5 SIZE', 'word-mag')=>array('type'=>'sliderbar','name'=>'word_mag'.'_h5_size','default'=>'16'),
			esc_html__('H6 SIZE', 'word-mag')=>array('type'=>'sliderbar','name'=>'word_mag'.'_h6_size','default'=>'15'),
			esc_html__('CONTENT SIZE', 'word-mag')=>array('type'=>'sliderbar','name'=>'word_mag'.'_content_size','default'=>'14')
		),
		'word_mag_panel_font' => array(
			esc_html__('HEADER FONT', 'word-mag')=>array('type'=>'font-combobox','name'=>'word_mag'.'_header_font', 'default'=>'- Droid Serif',
				'description'=>'Choose the header font of this theme. This font will be used in all title and header elements including the slider title.'),
			esc_html__('MENU FONT', 'word-mag')=>array('type'=>'font-combobox','name'=>'word_mag'.'_menu_font',
				'description'=>'Choose the font to be used within content. We highly recommended NOT to use CUFON as a content font.'),
			esc_html__('CONTENT FONT', 'word-mag')=>array('type'=>'font-combobox','name'=>'word_mag'.'_content_font',
				'description'=>'Choose the font to be used within content. We highly recommended NOT to use CUFON as a content font.'),
		),
		'word_mag_panel_upload_font' => array(
			esc_html__('UPLOAD FONT', 'word-mag')=>array(
				'type'=>'uploadfont',
				'name'=>'word_mag'.'_upload_font',
				'file'=>'word_mag'.'_upload_font_file')
		),
		
		//Overall Elements
		'word_mag_panel_logo' => array( 
			esc_html__('LOGO', 'word-mag')=>array('type'=>'upload','name'=>'word_mag'.'_logo', 'description'=>'You can upload custom logo image. To remove logo just remove url from logo input field.' ),
			esc_html__('LOGO MARGIN', 'word-mag')=>array(
				'type'=>'inputtext',
				'name'=>'word_mag'.'_logo_margin',
				'default'=>'0px 0px 0px 0px',
				'description'=>'You set logo margin e.g (Top,Right,Bottom,Left)'),
		),
		'word_mag_header_search' => array( 
			esc_html__('HEADER SEARCH TYPE', 'word-mag')=>array(
				'type'=>'combobox',
				'name'=>'word_mag'.'_header_search',
				'options'=>array('Product', 'Standrad'),
				'description'=>'You can specify header search for products or standrad blog search'),
			
		),
		'word_mag_panel_background' => array(			
			esc_html__('BACKGROUND TYPE', 'word-mag')=>array('type'=>'combobox', 'id'=>'word_mag_background_style','default'=>'0','name'=>'word_mag'.'_background_style','options'=>array('0'=>'Pattern','1'=>'Custom Image','2'=>'Color','3'=>'None'),
				'description'=>'You can choose the background you want between our pre-provided petterns and your custom image.'),
			esc_html__('Background Color', 'word-mag')=>array('body_class'=>'word_mag_background_color', 'type'=>'colorpicker','name'=>'word_mag'.'_default_background_color','color_scheme_1'=>'#f2f2f2','description'=>'It will change solid background color'),
			esc_html__('CHOOSE PATTERN','word-mag')=>array(
				'type'=>'radioimage',
				'body_class'=>'word_mag_background_pattern',
				'name'=>'word_mag'.'_background_pattern',
				'default'=>'2',
				'options'=>array(
					'1'=>array('value'=>'1', 'image'=>'/framework/assets/images/pattern/pattern-1.png'),
					'2'=>array('value'=>'2','image'=>'/framework/assets/images/pattern/pattern-2.png'),
					'3'=>array('value'=>'3','image'=>'/framework/assets/images/pattern/pattern-3.png'),
					'4'=>array('value'=>'4','image'=>'/framework/assets/images/pattern/pattern-4.png'),
					'5'=>array('value'=>'5','image'=>'/framework/assets/images/pattern/pattern-5.png'),
					'6'=>array('value'=>'6','image'=>'/framework/assets/images/pattern/pattern-6.png'),
					'7'=>array('value'=>'7','image'=>'/framework/assets/images/pattern/pattern-7.png'),
					'8'=>array('value'=>'8','image'=>'/framework/assets/images/pattern/pattern-8.png'),
					'9'=>array('value'=>'9','image'=>'/framework/assets/images/pattern/pattern-9.png'),
					'10'=>array('value'=>'10','image'=>'/framework/assets/images/pattern/pattern-10.png'),
					'11'=>array('value'=>'11','image'=>'/framework/assets/images/pattern/pattern-11.png'),
					'12'=>array('value'=>'12','image'=>'/framework/assets/images/pattern/pattern-12.png'),
					'13'=>array('value'=>'13','image'=>'/framework/assets/images/pattern/pattern-13.png'),
					'14'=>array('value'=>'14','image'=>'/framework/assets/images/pattern/pattern-14.png'),
					'15'=>array('value'=>'15','image'=>'/framework/assets/images/pattern/pattern-15.png'),
					'16'=>array('value'=>'16','image'=>'/framework/assets/images/pattern/pattern-16.png'),
					'17'=>array('value'=>'17','image'=>'/framework/assets/images/pattern/pattern-17.png'),
					'18'=>array('value'=>'18','image'=>'/framework/assets/images/pattern/pattern-18.png'),
					'19'=>array('value'=>'19','image'=>'/framework/assets/images/pattern/pattern-19.png'),
					'20'=>array('value'=>'20','image'=>'/framework/assets/images/pattern/pattern-20.png'),
					'21'=>array('value'=>'21','image'=>'/framework/assets/images/pattern/pattern-21.png'),
					'22'=>array('value'=>'22','image'=>'/framework/assets/images/pattern/pattern-22.png'),
				)
			),
		esc_html__('CUSTOM BACKGROUND', 'word-mag')=>array(
		'type'=>'upload',
		'name'=>'word_mag'.'_background_custom',
		'body_class'=>'word_mag_background_custom'), 
		),
		
		'word_mag_panel_load_color_scheme' => array(
		 esc_html__('LOAD DEFAULT COLOR','word-mag')=>array('type'=>'button','text'=>'Load Default','id'=>'word_mag_load_default_color_button',
		 		'description'=>'Click this button to load the default elements color of this theme. Then click save changes to save the default value. <br><br> ' .
				'WARNING : All of settings cannot be undo after you click save changes button.'),
	/*	esc_html__('PREDEFINED COLOR SCHEMES','word-mag')=>array(
		'type'=>'radioimage',
		'body_class'=>'word_mag_color_scheme',
		'name'=>'word_mag'.'_color_scheme',
		'default'=>'default',
		'options'=>array(
			'1'=>array('value'=>'color_scheme_1','image'=>'/framework/assets/images/color-schemes/scheme-1.png'),
			'2'=>array('value'=>'color_scheme_2','image'=>'/framework/assets/images/color-schemes/scheme-2.png'),
			'3'=>array('value'=>'color_scheme_3','image'=>'/framework/assets/images/color-schemes/scheme-3.png'),
			'4'=>array('value'=>'color_scheme_4','image'=>'/framework/assets/images/color-schemes/scheme-4.png'),
			'5'=>array('value'=>'color_scheme_5','image'=>'/framework/assets/images/color-schemes/scheme-5.png'),
			'6'=>array('value'=>'color_scheme_6','image'=>'/framework/assets/images/color-schemes/scheme-6.png'),
		)
		),*/
		),	
		
		
		// Load other elements colors
		'word_mag_panel_load_other_color' => array(
	esc_html__('Master Color', 'word-mag')=>array('body_class'=>'word_mag_background_solid', 'type'=>'colorpicker','name'=>'word_mag'.'master_color',
		'color_scheme_1'=>'#cc0066',
		'color_scheme_2'=>'#65ECFC',
		'color_scheme_3'=>'#BB00F8',
		'color_scheme_4'=>'#9FFC66',
		'color_scheme_5'=>'#809F14',
		'color_scheme_6'=>'#809F14',
		'description'=>'It will change overall color scheme of theme.'),
	
		esc_html__('Button Text Color', 'word-mag')=>array('body_class'=>'word_mag_background_solid', 'type'=>'colorpicker','name'=>'word_mag'.'button_text_color',
		'color_scheme_1'=>'#ffffff',
		'color_scheme_2'=>'#65ECFC',
		'description'=>'It will change text color of button in normal state.',
		),	
		
		esc_html__('Button Normal Color', 'word-mag')=>array('body_class'=>'word_mag_background_solid', 'type'=>'colorpicker','name'=>'word_mag'.'button_bg_color',
		'color_scheme_1'=>'#00D8FF',
		'color_scheme_2'=>'#65ECFC',
		'description'=>'It will change button color in normal state.',
		),
		
		esc_html__('Button Hover Text Color', 'word-mag')=>array('body_class'=>'word_mag_background_solid', 'type'=>'colorpicker','name'=>'word_mag'.'button_text_hover_color',
		'color_scheme_1'=>'#FFFFFF',
		'color_scheme_2'=>'#65ECFC',
		'description'=>'It will change button text color in hover state.',
		),	
		
		esc_html__('Button Hover Color', 'word-mag')=>array('body_class'=>'word_mag_background_solid', 'type'=>'colorpicker','name'=>'word_mag'.'button_bg_hover_color',
		'color_scheme_1'=>'#006c7f',
		'color_scheme_2'=>'#65ECFC',
		'description'=>'It will change button color in hover state.',
		),	
		), 
		
		//Load Custom CSS
		'word_mag_panel_custom_style' => array(
		esc_html__('CUSTOM STYLING', 'word-mag')=>array('type'=>'textarea','name'=>'word_mag'.'_custom_styling'), 
		),			
		  
				  'word_mag_panel_social_network' => array(
					esc_html__('Facebook', 'word-mag')=>array('type'=>'inputtext','name'=>'word_mag'.'_facebook',
						'description'=>'Place the URL of your dribbble profile and icon will appear. To remove it, just leave it blank.'),	
					esc_html__('Github', 'word-mag')=>array('type'=>'inputtext','name'=>'word_mag'.'_github',
						'description'=>'Place the URL of your facebook profile and icon will appear. To remove it, just leave it blank.'),
					esc_html__('Linkedin', 'word-mag')=>array('type'=>'inputtext','name'=>'word_mag'.'_linkedin',
						'description'=>'Place the URL of your vimeo channel and icon will appear. To remove it, just leave it blank.'),
					esc_html__('Pinterest', 'word-mag')=>array('type'=>'inputtext','name'=>'word_mag'.'_pinterest',
						'description'=>'Place the URL of your twitter profile and icon will appear. To remove it, just leave it blank.'),
					esc_html__('Dribbble', 'word-mag')=>array('type'=>'inputtext','name'=>'word_mag'.'_dribbble',
						'description'=>'Place the link you want and pinterest icon will appear. To remove it, just leave it blank.'),
					esc_html__('Google+', 'word-mag')=>array('type'=>'inputtext','name'=>'word_mag'.'_google',
						'description'=>'Place the link you want and pinterest icon will appear. To remove it, just leave it blank.'),
					esc_html__('Tumblr', 'word-mag')=>array('type'=>'inputtext','name'=>'word_mag'.'_tumblr',
						'description'=>'Place the link you want and pinterest icon will appear. To remove it, just leave it blank.'),
					esc_html__('Twitter', 'word-mag')=>array('type'=>'inputtext','name'=>'word_mag'.'_twitter',
						'description'=>'Place the link you want and pinterest icon will appear. To remove it, just leave it blank.'),
					esc_html__('Youtube', 'word-mag')=>array('type'=>'inputtext','name'=>'word_mag'.'_youtube',
						'description'=>'Place the link you want and pinterest icon will appear. To remove it, just leave it blank.'),	
					),	
		
		
		// Slider Setting
		'word_mag_panel_nivo_slider' => array(
		esc_html__('SLIDER EFFECTS', 'word-mag')=>array(
		'type'=>'combobox',
		'oldname'=>'effect',
		'name'=>'word_mag'.'_nivo_slider_effect',
		'options'=>array(
			'0'=>'sliceDown', '1'=>'sliceDownLeft', '2'=>'sliceUp',
			'3'=>'sliceUpLeft', '4'=>'sliceUpDown', '5'=>'sliceUpDownLeft',
			'6'=>'fold', '7'=>'fade', '8'=>'random',
			'9'=>'slideInRight', '10'=>'slideInLeft', '11'=>'boxRandom',
			'12'=>'boxRain', '13'=>'boxRainReverse', '14'=>'boxRainGrow',
			'15'=>'boxRainGrowReverse')),
		esc_html__('PAUSE ON HOVER', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'pauseOnHover','name'=>'word_mag'.'_nivo_slider_pause_on_hover',
		'description'=>'Pause the nivo slider when user hover at the slider.'),
		esc_html__('SHOW BULLETS', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'controlNav','name'=>'word_mag'.'_nivo_slider_show_bullets',
		'description'=>'Enable to show the nivo slider navigation bullets.'),
		esc_html__('SHOW LEFT/RIGHT NAVIGATION', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'directionNav','name'=>'word_mag'.'_nivo_slider_show_navigation',
		'description'=>'Enable left/right navigation of the nivo slider.'),
		esc_html__('ONLY SHOW NAVIGATION WHEN HOVER', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'directionNavHide','name'=>'word_mag'.'_nivo_slider_hover_navigation',
		'description'=>'If the left/right navigation is enabled, enabling this option will hide the left/right navigation when the mouse cursor is outside of the slider frame.'),
		esc_html__('ANIMATION SPEED', 'word-mag')=>array('type'=>'inputtext','oldname'=>'animSpeed','name'=>'word_mag'.'_nivo_slider_animation_speed','default'=>'500',
		'description'=>'This is the animation speed during the change of each slide.'),
		esc_html__('PAUSE TIME', 'word-mag')=>array('type'=>'inputtext','oldname'=>'pauseTime','name'=>'word_mag'.'_nivo_slider_pause_time','default'=>'3000',
		'description'=>'This option is the pause time of each slider.'),
		esc_html__('CAPTION OPACITY', 'word-mag')=>array('type'=>'inputtext','oldname'=>'captionOpacity','name'=>'word_mag'.'_nivo_slider_caption_opacity','default'=>'1'),
		
		),
		
		'word_mag_panel_flex_slider' => array(
		esc_html__('SLIDER EFFECTS', 'word-mag')=>array('type'=>'combobox','oldname'=>'animation'
		,'name'=>'word_mag'.'_flex_slider_effect', 'options'=>array('0'=>'fade', '1'=>'slide')),
		esc_html__('PAUSE ON HOVER', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'pauseOnHover','name'=>'word_mag'.'_flex_slider_pause_on_hover','default'=>'disable',
		'description'=>'Pause the flex slider when user hover at the slider.'),
		esc_html__('SHOW BULLETS', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'controlNav','name'=>'word_mag'.'_flex_slider_show_bullets',
		'description'=>'Enable to show the flex slider navigation bullets.'),
		esc_html__('SHOW NAVIGATION', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'directionNav','name'=>'word_mag'.'_flex_slider_show_navigation',
		'description'=>'Enable left/right navigation of the flex slider.'),
		esc_html__('ANIMATION SPEED', 'word-mag')=>array('type'=>'inputtext','oldname'=>'animationDuration','name'=>'word_mag'.'_flex_slider_animation_speed','default'=>'600',
		'description'=>'This is the animation speed during the change of each slide.'),
		esc_html__('PAUSE TIME', 'word-mag')=>array('type'=>'inputtext','oldname'=>'slideshowSpeed','name'=>'word_mag'.'_flex_slider_pause_time','default'=>'7000',
		'description'=>'This option is the pause time of each slider.'),
		esc_html__('PAUSE ON ACTION', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'pauseOnAction','name'=>'word_mag'.'_flex_slider_pause_on_action','default'=>'false'),
		),
		
		 
		'word_mag_panel_refine_slider' => array(
		esc_html__('SLIDER EFFECTS', 'word-mag')=>array(
		'type'=>'combobox',
		'oldname'=>'transition',
		'name'=>'word_mag'.'_refine_slider_effect',
		'options'=>array(
			'0'=>'fade', '1'=>'random', '2'=>'sliceH',
			'3'=>'sliceV', '4'=>'slideH', '5'=>'slideV',
			'6'=>'scale', '7'=>'fan', '8'=>'blockScale',
			'9'=>'kaleidoscope', '10'=>'blindH', '11'=>'blindV',
			'12'=>'cubeH', '13'=>'cubeV')),
		esc_html__('AUTOPLAY', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'autoPlay','name'=>'word_mag'.'_refine_slider_autoplay',
		'description'=>'Autoplay refine slider.'),			
		esc_html__('SHOW LEFT/RIGHT NAVIGATION', 'word-mag')=>array(
		'type'=>'combobox',
		'oldname'=>'controls',
		'name'=>'word_mag'.'_refine_slider_show_navigation',
		'options'=>array(
			'0'=>'null', '1'=>'arrows', '2'=>'thumbs'),
		'description'=>'Enable left/right navigation of the refine slider.'),				
		esc_html__('KEYBOARD NAVIGATION', 'word-mag')=>array('type'=>'radioenabled','oldname'=>'keyNav','name'=>'word_mag'.'_refine_slider_key_navigation',
		'description'=>'Use left/right arrow keys to switch slide.'),
		esc_html__('ANIMATION SPEED', 'word-mag')=>array('type'=>'inputtext','oldname'=>'transitionDuration','name'=>'word_mag'.'_refine_slider_animation_speed','default'=>'500',
		'description'=>'This is the animation speed during the change of each slide.'),
		esc_html__('PAUSE TIME', 'word-mag')=>array('type'=>'inputtext','oldname'=>'delay','name'=>'word_mag'.'_refine_slider_pause_time','default'=>'3000',
		'description'=>'This option is the pause time of each slider.'),
		),
		
		'word_mag_panel_dummy_content' => array(
		esc_html__('Dummy Content', 'word-mag')=>array('type'=>'dummy','name'=>'word_mag'.'_create_sidebar')
		),
		);
	
	// add WooCommerce Options if Plugin is Activated
	if( function_exists('woocommerce_get_template_part')) {
	$crunchpress_menu= array_merge( $crunchpress_menu, (array)$woo_options_arr );	
	$crunchpress_element= array_merge( $crunchpress_element, (array)$woo_elements_arr );
	}else {
	$crunchpress_menu= array_merge( $crunchpress_menu, (array)$woo_options_arr_not_installed );	
	$crunchpress_element= array_merge( $crunchpress_element, (array)$woo_elements_arr );
	
	}
	
	// add action to embeded the panel in to dashboard
	add_action('admin_menu','add_crunchpress_panel');
	function add_crunchpress_panel(){
		$page = add_menu_page('crunchpress Option', THEME_NAME , 'manage_options', 'options', 'create_crunchpress_panel'); 
		add_action('admin_enqueue_scripts','register_cp_framework_panel_scripts');
	}
	
	// add ajax action to hook the functions when save button is pressed 
	add_action('wp_ajax_save_crunchpress_panel','save_crunchpress_panel');
	function save_crunchpress_panel(){
	
		check_ajax_referer(plugin_basename(__FILE__),'security');
		
		global $crunchpress_element;
		$return_data = array('success'=>'-1', 'alert'=>'Save option failed, please try contacting your host provider to increase the post_max_size and suhosin.post.max_vars varialble on the server.');
		foreach($crunchpress_element as $elements){
			foreach($elements as $element){
				// when save sidebar
				if($element['type'] == 'sidebar'){
					$word_mag_sidebar_xml = '<sidebar>';
					if( !empty( $_POST[$element['name']] ) ){
						$word_mag_sidebar = $_POST[$element['name']];     
					}else{
						$word_mag_sidebar = array();
					}
					foreach($word_mag_sidebar as $word_mag_sidebar_name){
						$word_mag_sidebar_xml = $word_mag_sidebar_xml . create_xml_tag('name',$word_mag_sidebar_name);
					}
					$word_mag_sidebar_xml = $word_mag_sidebar_xml . '</sidebar>';
					if(!save_option($element['name'], get_option($element['name']), $word_mag_sidebar_xml)){
						die( json_encode($return_data) );
					}
				// when save uploaded font
				}else if($element['type'] == 'uploadfont'){
					$uploadfont_xml = '<uploadfont>';
					if( !empty($_POST[$element['name']]) && !empty($_POST[$element['file']]) ){
						$uploadfont = $_POST[$element['name']];
						$uploadfont_file = $_POST[$element['file']];
						$num = sizeof($uploadfont);
						for($i=0; $i<$num; $i++){
							$uploadfont_xml = $uploadfont_xml . '<font>';
							$uploadfont_xml = $uploadfont_xml . create_xml_tag('name', $uploadfont[$i]);
							$uploadfont_xml = $uploadfont_xml . create_xml_tag('file', $uploadfont_file[$i]);
							$uploadfont_xml = $uploadfont_xml . '</font>';
						}
					}
					$uploadfont_xml = $uploadfont_xml . '</uploadfont>';
					if(!save_option($element['name'], get_option($element['name']), $uploadfont_xml)){
						die( json_encode($return_data) );
					}
				// do nothing with dummy button
				}else if($element['type'] == 'dummy'){
				
				}else if( !empty($element['name']) ){
					if( !empty( $_POST[$element['name']] ) ){
						$new_option_value = str_replace( "\'" , "'", $_POST[$element['name']]);
						$new_option_value = str_replace( '\"' , '"', $new_option_value);
						$new_option_value = str_replace( '\\\\' , '\\' , $new_option_value);
					}else{
						$new_option_value = '';
					}
					if(!save_option($element['name'], get_option($element['name']), $new_option_value)){
						die( json_encode($return_data) );
					}
				}
			}
		}
		
		// call the function to generate the style-custom.css file.
		word_mag_generate_style_custom();
			die( json_encode( array('success'=>'0') ) );
	}
	
	// update the option if new value is exists and not equal to old one 
	function save_option($name, $old_value, $new_value){
		if(empty($new_value) && !empty($old_value)){
			if(!delete_option($name)){
				return false;
			}
		}else if($old_value != $new_value){
			if(!update_option($name, $new_value)){
				return false;
			}
		}
		return true;
	}
	
	// start creating the crunchpress panel ( by calling function to create menu and elements )
	function create_crunchpress_panel(){
	
		global $crunchpress_menu;
		global $crunchpress_element;
		
		?>
		
		<form name="goodlayer-panel-form" id="goodlayer-panel-form">
			<div class="crunchpress-panel-wrapper">
			<?php
				$word_mag_my_theme = wp_get_theme();
				echo '<div class="panel-menu">';
				echo '<div class="panel-menu-header"><div class="panel-menu-header-strap"></div>';
				echo '<img src="' . WORD_MAG_THEME_PATH_URL . '/framework/assets/images/admin-panel-logo.png" width="180px;" alt="crunchpress"/>';
				echo '</div>';			
					create_crunchpress_menu($crunchpress_menu);
				echo '</div>';
				echo '<div class="panel-elements" id="panel-elements">';
				echo '<div class="panel-element-head"><div class="panel-element-header-strap"></div>';
				echo '<div class="panel-header-left-text">';
				echo '<div class="panel-crunchpress-text">'.$word_mag_my_theme->get( 'Name' ).'</div>';
				echo '<div class="panel-admin-panel-text">'.esc_html__('Version','word-mag') . $word_mag_my_theme->get( 'Version' ).'</div>';
				echo '</div>';
				/*echo '<div class="panel-admin-panel-text fw-version">'.esc_html__('Framework Ver','word-mag') , '</div>';*/
				echo '</div>';	
				echo '<div class="panel-element" id="panel-element-save-complete">';
				echo '<div class="panel-element-save-text">Save Options Complete.</div>';
				echo '<div class="panel-element-save-arrow"></div></div>';
					create_crunchpress_elements($crunchpress_element);
				echo '<div class="panel-element-tail">';
				echo '<div class="tail-save-changes"><div class="loading-save-changes"></div>';
				echo '<input type="submit" value="' . esc_html__('Save Changes','word-mag') . '">';
				echo '</div>';						
				echo '</div>';						
				echo '<input type="hidden" name="action" value="save_crunchpress_panel">';
				echo '<input type="hidden" name="security" value="' . wp_create_nonce(plugin_basename(__FILE__)) . '">';
				echo '</div>';	
			?>
			</div>
		</form>
		<?php
	}
	// Create accordion menu
	function create_crunchpress_menu($menu){
		echo '<div id="panel-nav"><ul>';	
		foreach($menu as $title=>$sub_menu){ 
			echo '<li>';
			echo '<a id="parent" href="#" >';
			echo '<div class="top-menu-bar"></div>';
			echo '<div class="top-menu-image"><img src="' . plugins_url( '/assets/images/admin-panel/', __FILE__ ). '' . str_replace(' ', '', $title) . '.png"/></div>';
			echo '<span class="top-menu-text">' . sprintf(esc_html__('%s','word-mag'),$title ) . '</span>';
			echo '</a>';
			echo '<ul>';
			foreach($sub_menu as $sub_title=>$name){
				echo '<li>';
				echo '<a id="children" href="#" rel=' . $name . '>';
				echo '<div class="child-menu-image"></div>';
				echo '<span class="child-menu-text">' . sprintf(esc_html__('%s','word-mag'),$sub_title ) . '</span>';
				echo '</a>';
				echo '</li>';
			}
			echo '</ul>';
			echo '</li>';
		}
		echo '</ul></div>';
	}
	// decide to create each input element base on the receiving key of elements
	function create_crunchpress_elements($elements){
		foreach($elements as $key => $element){
			echo '<div class="panel-element" id=' . $key . '>';
				foreach($element as $key => $values){
					if( !empty($values['name']) ){
						$values['value'] = get_option($values['name']);
						$values['default'] = (isset($values['default']))? $values['default']: '';
					}
					switch($values['type']){
						case 'upload': word_mag_print_panel_upload($key, $values); break;
						case 'inputtext': word_mag_print_panel_input_text($key, $values); break;
						case 'textarea': word_mag_print_panel_input_textarea($key, $values); break;
						case 'radioenabled': word_mag_print_panel_radio_enabled($key, $values); break;
						case 'radioimage' : word_mag_print_panel_radioimage($key, $values); break;
						case 'combobox': word_mag_print_panel_combobox($key, $values); break;
						case 'font-combobox': word_mag_print_panel_font_combobox($key, $values); break;
						case 'colorpicker': word_mag_print_panel_color_picker($key, $values); break;
						case 'sliderbar': word_mag_print_panel_sliderbar($key, $values); break;
						case 'sidebar': word_mag_print_panel_sidebar($key, $values); break;
						case 'uploadfont': word_mag_print_panel_upload_font($key, $values); break;
						case 'button': word_mag_print_panel_button($key, $values); break;
						case 'dummy': word_mag_print_panel_dummy(); break;
						case 'notice': word_mag_print_panel_notice(); break;
					}		
				}
			echo '</div>';
		}
	}
	
	/*  ---------------------------------------------------------------------
	*	The following section is the template of input elements
	*	---------------------------------------------------------------------
	*/
	
	// Upload => name, value, default
	function word_mag_print_panel_upload($title, $values){
		extract($values);
		if( empty( $body_class ) ){ $body_class = $name; }
		?>
			<div class="panel-body body-<?php  echo esc_html($body_class); ?>">
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label for="<?php  echo esc_html($name); ?>" > <?php printf(esc_html__('%s','word-mag'),$title ); ?> </label>
				</div>
				<div class="panel-input">	
					<div class="input-example-image" id="input-example-image">
					<?php 
					
						$image_src = '';
						
						if(!empty($value)){ 
						
							$image_src = wp_get_attachment_image_src( $value, 'full' );
							$image_src = (empty($image_src))? '': $image_src[0];
							$thumb_src_preview = wp_get_attachment_image_src( $value, '150x150');
							echo '<img src="' . $thumb_src_preview[0] . '" />';
							
						} 
						
					?>			
					</div>
					<input name="<?php  echo esc_html($name); ?>" type="hidden" id="upload_image_attachment_id" value="<?php 
					
						echo ($value == '')? esc_html($default): esc_html($value);
						
					?>" />
					<input id="upload_image_text" class="upload_image_text" type="text" value="<?php  echo esc_html($image_src); ?>" />
					<input class="upload_image_button" type="button" value="Upload" />
				</div>
				<br class="clear">
			</div>
			
		<?php
		
	}
	
	// text => name, value, default
	function word_mag_print_panel_input_text($title, $values){
	
		extract($values);
		
		?>
			<div class="panel-body">
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label for="<?php  echo esc_html($name); ?>" > <?php printf(esc_html__('%s','word-mag'),$title ); ?> </label>
				</div>
				<div class="panel-input">
					<input type="text" name="<?php  echo esc_html($name); ?>" id="<?php  echo esc_html($name); ?>" value="<?php 
						
						echo ($value == '')? esc_html($default): esc_html($value);
						
						 ?>" />
				</div>
				<?php if(isset($description)){ ?>
				
					<div class="panel-description"><?php printf(esc_html__('%s','word-mag'),$description ); ?></div>
					<div class="panel-description-info-img"></div>
					
				<?php } ?>
				<br class="clear">
			</div>
			
		<?php
	
	}
	
	// textarea => name, value, default
	function word_mag_print_panel_input_textarea($title, $values){
	
		extract($values);
		
		?>
		
			<div class="panel-body">
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label for="<?php  echo esc_html($name); ?>"><?php printf(esc_html__('%s','word-mag'),$title ); ?></label>
				</div>
				<div class="panel-input">
					<textarea cols="10" rows="5" name="<?php  echo esc_html($name); ?>" id="<?php  echo esc_html($name); ?>" ><?php
						
						echo ($value == '')? esc_html($default): esc_html($value);
						
					?></textarea>
				</div>
				<?php if(isset($description)){ ?>
				
					<div class="panel-description"><?php printf(esc_html__('%s','word-mag'),$description ); ?></div>
					<div class="panel-description-info-img"></div>
					
				<?php } ?>
				<br class="clear">
			</div>
			
		<?php
		
	}
	
	// radioenabled => name, value
	function word_mag_print_panel_radio_enabled($title, $values){
	
		extract($values);
		
		?>
		
			<div class="panel-body">
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label for="<?php  echo esc_html($name); ?>"><?php printf(esc_html__('%s','word-mag'),$title ); ?></label>
				</div>
				<div class="panel-input">
					<label for="<?php  echo esc_html($name); ?>"><div class="checkbox-switch <?php
						
						echo ($value=='enable' || ($value=='' && empty($default)))? 'checkbox-switch-on': 'checkbox-switch-off'; 

					?>"></div></label>
					<input type="checkbox" name="<?php  echo esc_html($name); ?>" class="checkbox-switch" value="disable" checked>
					<input type="checkbox" name="<?php  echo esc_html($name); ?>" id="<?php  echo esc_html($name); ?>" class="checkbox-switch" value="enable" <?php 
						
						echo ($value=='enable' || ($value=='' && empty($default)))? 'checked': ''; 
					
					?>>
				</div>
				<?php if(isset($description)){ ?>
				
					<div class="panel-description"><?php printf(esc_html__('%s','word-mag'),$description ); ?></div>
					<div class="panel-description-info-img"></div>
					
				<?php } ?>
				<br class="clear">
			</div>
			
		<?php
		
	}
	
	function word_mag_print_panel_radioimage($title, $values){
		
		extract($values);
		
		if( empty( $body_class ) ){ $body_class = $name; }
		
		?>
		
			<div class="panel-body body-<?php  echo esc_html($body_class); ?>">
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label for="<?php  echo esc_html($name); ?>"><?php printf(esc_html__('%s','word-mag'),$title ); ?></label>
				</div>
				<div class="panel-radioimage">
					<?php foreach( $options as $option ){ ?>
						<div class='radio-image-wrapper'>
							<label for="<?php  echo esc_html($option['value']); ?>">
								<img src=<?php echo WORD_MAG_THEME_PATH_URL.$option['image']?> class="<?php  echo esc_html($name); ?>" alt=<?php  echo esc_html($name); ?>>
								<div id="check-list"></div>                                
							</label>
							<input type="radio" name="<?php  echo esc_html($name); ?>" value="<?php  echo esc_html($option['value']); ?>" <?php 
								if($value == $option['value']){
									echo 'checked';
								}else if($value == '' && $default == $option['value']){
									echo 'checked';
								}
							?> id="<?php  echo esc_html($option['value']); ?>" class="<?php  echo esc_html($name); ?>"
                            >                            
						</div>
					<?php } ?>
					<br class="clear">	
				</div>
			</div>		
		<?php
	}
	
	// combobox => name, value, options[]
	function word_mag_print_panel_combobox($title, $values){
	
		extract($values);
		
		if( empty($body) ) $body = "";
		if( empty($id) ) $id = $name;
		
		?>
		
			<div class="panel-body <?php  echo esc_html($body); ?>">	
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label for="<?php  echo esc_html($name); ?>"><?php printf(esc_html__('%s','word-mag'),$title ); ?></label>
				</div>
				<div class="panel-input">	
					<div class="combobox">
						<select name="<?php  echo esc_html($name); ?>" id="<?php  echo esc_html($id); ?>">
						
							<?php foreach($options as $option){ ?>
							
								<option <?php if( $option == esc_html($value) ){ echo 'selected'; }?>><?php  echo esc_html($option); ?></option>
							
							<?php } ?>
							
						</select>
					</div>
				</div>
				<?php if(isset($description)){ ?>
				
					<div class="panel-description"><?php printf(esc_html__('%s','word-mag'),$description ); ?></div>
					<div class="panel-description-info-img"></div>
					
				<?php } ?>
				<br class="clear">
			</div>
			
		<?php
		
	}	
	
	// font-combobox => name, value, options[]
	function word_mag_print_panel_font_combobox($title, $values){
	
		extract($values);
		if(empty($value)){ $value = $default; } 
		$elements = get_font_array();
		
		?>
		
			<div class="panel-body">
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label for="<?php  echo esc_html($name); ?>"><?php printf(esc_html__('%s','word-mag'),$title ); ?></label>
				</div>
				<div class="panel-input">	
					<div class="panel-font-sample" id="panel-font-sample"><?php echo FONT_SAMPLE_TEXT; ?></div> 
					<div class="combobox" id="combobox-font-sample">
						<select name="<?php  echo esc_html($name); ?>" id="<?php  echo esc_html($name); ?>" class="cp-panel-select-font-family">
						
							<?php foreach($elements as $option_name => $status){ ?>
							
								<option <?php if( $option_name==substr(esc_html($value),2) ){ echo 'selected'; }?> <?php  echo esc_html($status); ?>><?php 
										
										echo ($status=='enabled')?  '- ':'';
										 echo esc_html($option_name); 
									
									?></option>
							
							<?php } ?>
							
						</select>
					</div>
				</div>
				<?php if(isset($description)){ ?>
				
					<div class="panel-description"><?php printf(esc_html__('%s','word-mag'),$description ); ?></div>
					<div class="panel-description-info-img"></div>
					
				<?php } ?>
				<br class="clear">
			</div>
			
		<?php
		
	}	
	
	// colorpicker => name, value, default
	function word_mag_print_panel_color_picker($title, $values){
	
		extract($values);
		
		
		if( empty( $body_class ) ){ $body_class = $name; }
		
		?>
			<div class="panel-body body-<?php  echo esc_html($body_class); ?>">
            
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label for="<?php  echo esc_html($name); ?>" > <?php printf(esc_html__('%s','word-mag'),$title ); ?> </label>
				</div>
				<div class="panel-input">
					<input type="text" name="<?php  echo esc_html($name); ?>" class="color-picker" value="<?php 
												
						echo ($value == '')? esc_html( $color_scheme_1): esc_html($value);
						
						?>" color_scheme_1="<?php  echo esc_html($color_scheme_1); ?>"<?php /*?> color_scheme_2="<?php  echo esc_html($color_scheme_2; ?>" color_scheme_3="<?php  echo esc_html($color_scheme_3; ?>" color_scheme_4="<?php  echo esc_html($color_scheme_4; ?>" <?php */?>/>
				</div>
				<?php if(isset($description)){ ?>
				
					<div class="panel-description"><?php printf(esc_html__('%s','word-mag'),$description ); ?></div>
					<div class="panel-description-info-img"></div>
					
				<?php } ?>
				<br class="clear">
			</div>
			
		<?php
	}
	
	// sliderbar => name, value, default
	function word_mag_print_panel_sliderbar($title, $values){
	
		extract($values);
		
		?>
		
			<div class="panel-body">
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label for="<?php  echo esc_html($name); ?>" > <?php printf(esc_html__('%s','word-mag'),$title ); ?> </label>
				</div>
				<div class="panel-input">
					<div id="<?php  echo esc_html($name); ?>" class="sliderbar" rel="sliderbar"></div>
					<input type="hidden" name="<?php  echo esc_html($name); ?>" value="<?php echo ($value == '')? esc_html($default): esc_html($value); ?>" >
					<div id="slidertext"><?php echo ($value == '')? esc_html($default): esc_html($value); ?> px</div>
				</div>
				<?php if(isset($description)){ ?>
				
					<div class="panel-description"><?php printf(esc_html__('%s','word-mag'),$description ); ?></div>
					<div class="panel-description-info-img"></div>
					
				<?php } ?>
				<br class="clear">
			</div>
			
		<?php
		
	}
	
	// sidebar => name, value
	function word_mag_print_panel_sidebar2($title, $values){
	
		extract($values);
		
		?>
		
		<div class="panel-body" id="panel-body">
			<div class="panel-body-gimmick"></div>
			<div class="panel-title">
				<label> <?php printf(esc_html__('%s','word-mag'),$title ); ?> </label>
			</div>
			<div class="panel-input">
				<input type="text" id="add-more-sidebar" value="type title here" rel="type title here">
				<div id="add-more-sidebar" class="add-more-sidebar"></div>
			</div>
				<?php if(isset($description)){ ?>
				
					<div class="panel-description"><?php printf(esc_html__('%s','word-mag'),$description ); ?></div>
					
				<?php } ?>
			<br class="clear">
			<div id="selected-sidebar" class="selected-sidebar">
				<div class="default-sidebar-item" id="sidebar-item">
					<div class="panel-delete-sidebar"></div>
					<div class="slider-item-text"></div>
					<input type="hidden" id="<?php  echo esc_html($name); ?>">
				</div>
				
				<?php 
				
				if(!empty($value)){
					
					$xml = new DOMDocument();
					$xml->loadXML($value);
					
					foreach( $xml->documentElement->childNodes as $word_mag_sidebar_name ){
					
				?>
						<div class="sidebar-item" id="sidebar-item">
							<div class="panel-delete-sidebar"></div>
							<div class="slider-item-text"><?php  echo esc_html($word_mag_sidebar_name->nodeValue); ?></div>
							<input type="hidden" name="<?php  echo esc_html($name); ?>[]" id="<?php  echo esc_html($name); ?>" value="<?php  echo esc_html($word_mag_sidebar_name->nodeValue); ?>">
						</div>
					
				<?php 
					} 
					
				} 
				
				?>
				
			</div>
		</div>
		<?php 
		
	}
	
	// uploadfont => name, value
	function word_mag_print_panel_upload_font($title, $values){
	
		extract($values);
		
		?>
		
		<div class="panel-body" id="panel-body">
			<div class="panel-body-gimmick"></div>
			<div class="panel-title panel-add-more-title">
				<?php printf(esc_html__('%s','word-mag'),$title ); ?>
			</div>
			<div id="add-more-font" class="add-more-font"></div>
			<br class="clear">
			<div id="added-font" class="added-font">
				<div class="default-font-item" id="font-item">
					<div class="inner-font-item">
						<div class="panel-font-title"><?php esc_html_e('Font Name','word-mag'); ?></div>
						<input type="text" id="<?php  echo esc_html($name); ?>" class="word_mag_upload_font_name" readonly>
					</div>
					<div class="inner-font-item">
						<div class="panel-font-title"><?php esc_html_e('Font File','word-mag'); ?></div>
						<input type="hidden" id="<?php  echo esc_html($file); ?>"  class="font-attachment-id">
						<input type="text" class="upload-font-text" readonly>
						<input class="upload-font-button" type="button" value="Upload" />
					</div>
					<div class="panel-delete-font"></div>
				</div>
				<?php 
				
					if(!empty($value)){
						
						$xml = new DOMDocument();
						$xml->loadXML($value);
						
						foreach( $xml->documentElement->childNodes as $each_font ){
						
				?>
				
					<div class="font-item" id="font-item">
						<div class="inner-font-item">
							<div class="panel-font-title"><?php esc_html_e('Font Name','word-mag'); ?></div>
							<input type="text" name="<?php  echo esc_html($name); ?>[]" id="<?php  echo esc_html($name); ?>" value="<?php echo find_xml_value($each_font, 'name'); ?>" class="word_mag_upload_font_name" readonly>
						</div>
						<div class="inner-font-item">
							<div class="panel-font-title"><?php esc_html_e('Font File','word-mag'); ?></div>
							<input type="hidden" name="<?php  echo esc_html($file); ?>[]" id="<?php  echo esc_html($file); ?>" class="font-attachment-id" value="<?php 
									$attachment_id = find_xml_value($each_font, 'file'); 
									 echo esc_html($attachment_id);
								?>" >
							<input type="text" class="upload-font-text" value="<?php echo (empty($attachment_id))? '': wp_get_attachment_url( $attachment_id ); ?>" readonly>
							<input class="upload-font-button" type="button" value="Upload" />
						</div>
						<div class="panel-delete-font"></div>
					</div>
					
				<?php 
				
						}
						
					}
					
				?>
				
			</div>
		</div>
		<?php
		
	}
	
	// print normal button
	function word_mag_print_panel_button($title, $values){
	
		extract($values);
	
		?>

			<div class="panel-body">
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label> <?php printf(esc_html__('%s','word-mag'),$title ); ?> </label>
				</div>
				<div class="panel-input">
					<input type="button" value="<?php echo esc_html($text); ?>" id="<?php echo esc_html($id); ?>" />
				</div>
				<?php if(isset($description)){ ?>
				
					<div class="panel-description"><?php printf(esc_html__('%s','word-mag'),$description ); ?></div>
					<div class="panel-description-info-img"></div>
					
				<?php } ?>
				<br class="clear">
			</div>		
		
		<?php	
	}
	
	// upload dummy data (from xml file)
	function word_mag_print_panel_dummy(){
		foreach ($_REQUEST as $keys=>$values) {
		$$keys = trim($values);
	}
	
	$return_data = array('success'=>'-1', 'alert'=>'Save option failed, please try contacting your host provider to increase the post_max_size and suhosin.post.max_vars varialble on the server.');
		?>

			<div class="panel-body">
				<div class="panel-body-gimmick"></div>
				<div class="panel-title">
					<label> DUMMIES DATA </label>
				</div>
				<div class="panel-input">
					   <div class="wrapper_right themeple_container">
	                            	<input type="hidden" value="<?php echo wp_create_nonce ('themeple_nonce_import_dummy_data');?>" name="themeple-nonce-dummy">
                                    <?php  if(defined('IS_word_mag_POSTS')){  ?>
								        <a class="themeple_btn themeple_btn_active themeple_dummy_data"><input type="button" value="<?php esc_html_e('Import Dummy Data', 'word-mag'); ?>" id="importcontent" /></a>
                                    <?php } else {  ?>
                                       <a class="noplugin"><input type="button" value="<?php esc_html_e('Import Dummy Data', 'word-mag'); ?>" id="noplugin" /></a>
                                    <?php } ?>
								    <div class="js_data" id="themeple_js_data">
									<input type="hidden" value="<?php echo admin_url("admin-ajax.php");?>" name="admin_ajax_url">						
								    </div>
                     		<div id="import-now-loading" class="now-loading"></div>
		     	</div>
            
				</div>
				<div class="panel-description">
					By clicking this button, you can import the dummy post and page to help 
					you create a site that look like theme preview to help you understand the
					function of this theme better. <br><br>
					*** It may takes a while during importing process, make sure not to reload
					the page or make any changes to the database.
				</div>
				<div class="panel-description-info-img"></div>
				<br class="clear">
			</div>		
		
		<?php
	}
	
	
	function word_mag_print_panel_notice(){
		?>
            <style>
			
			</style>
			<div class="panel-body">
				<div class="panel-body-gimmick"></div>
								
				<div class="panel-notice" >
				<div class="warning"><h3>	Please install Woocommerce Plugin to see the options for Products Page. </h3></div>
				 
				</div>
				
				<br class="clear">
			</div>		
		
		<?php
	}
	