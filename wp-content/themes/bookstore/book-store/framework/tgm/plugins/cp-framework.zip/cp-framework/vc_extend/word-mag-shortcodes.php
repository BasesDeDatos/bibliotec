<?php 

$target_arr = array(__("Same window", "crunchpress") => "_self", __("New window", "crunchpress") => "_blank");

function cp_contact_form_field($param, $param_value) {
    $dependency = vc_generate_dependencies_attributes($param);
   
    $param_line = '';
	$param_line .= '<div class="cf_wrapper">';
	$param_line .= '<input name="'.$param['param_name'].'" class="val wpb_vc_param_value wpb-textinput '.$param['param_name'].' '.$param['type'].'" type="hidden" value="'.$param_value.'"/>';
	$param_line .= '<ul class="contact_fields"></ul>
					<div class="form">
						<label for="lb" style="width: 60px;float: left;">Label</label> <input id="lb" type="text" class="label" style="width: 200px; margin-bottom: 4px;" /><br>
						<label for="nm" style="width: 60px;float: left;">Name</label> <input id="nm" type="text" class="name" style="width: 200px; margin-bottom: 4px;" />
						<input type="button" class="add_cf_row" value="add new field"/>
					 </div>';
	$param_line .=  '<script> var builder = new cf_builder({"container": ".cf_wrapper"}); builder.init('.$param_value.');</script>';
	$param_line .= '</div>';
   

    return $param_line;
}
add_shortcode_param('contact_form', 'cp_contact_form_field');


function od_post_settings_project($param, $param_value) {
   $dependency = vc_generate_dependencies_attributes($param);
   
     $selected = '';
				$entries = get_categories('title_li=&orderby=name&hide_empty=0&taxonomy=category');
				$param_line = '';
				$param_line .= '<select name="'.$param['param_name'].'" class="wpb_vc_param_value dropdown wpb-input wpb-select '.$param['param_name'].' '.$param['type'].'">';
                $param_line .= '<option value="All"'.$selected.'>All</option>';
				foreach($entries as $key => $entry) {
                    $selected = '';
                    if ( $entry->term_id == $param_value ) $selected = ' selected="selected"';
                    $sidebar_name = $entry->name;
					
                    $param_line .= '<option value="'.$entry->term_id.'"'.$selected.'>'.$sidebar_name.'</option>';
                }
                $param_line .= '</select>';
        
   
    return $param_line;
}
add_shortcode_param('post-cat', 'od_post_settings_project');

add_shortcode( 'Featured_Post', 'cp_featured_posts' );
	   vc_map( array(
		  "name" => __( "Featured Posts", "crunchpress" ),
		  "base" => "Featured_Post",
		  "class" => "",
		  "category" => __( "Crunchpress", "crunchpress"),
		 // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
		 // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
		  "params" => array(
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Heading", "crunchpress" ),
				"param_name" => "cp_featured_title",
				"value" => __( "Featured Posts", "crunchpress" ),
			 ),
			 
			array(
            "type" => "post-cat",
            "heading" => __("Select category", "crunchpress"),
            "param_name" => "cp_featured_cat",
            "description" => __("Select category.", "crunchpress")
           ),
		
			 array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Numbers of Post", "crunchpress" ),
				"param_name" => "cp_featured_no",
				"value" => __( "3", "crunchpress" ),
			 ),
			 
		   )
	   ) );
	
	function cp_featured_posts($atts, $content = null) {
	$default = array(
	    'cp_featured_no' 	=> '3',
		'cp_featured_cat' 	=> 'All',
		'cp_featured_title' 	=> 'Featured Posts',
		
		
	);
	

	extract(shortcode_atts($default, $atts));
		$output = ' <!--FEATURED POSTS START-->
    <div class="cp-featured-posts">
      <div class="container">
        <div class="holder">
          <h1>'.$cp_featured_title.'</h1>
          <div class="row">';
		     wp_reset_query();
					 global $paged, $wp_query;
	                 query_posts(array('post_type'=>'post', 'cat'=>$cp_featured_cat, 'paged'=>$paged, 'posts_per_page'=>$cp_featured_no)); 
	         	     while( have_posts() ){ the_post(); 
           $output .= '
            <div class="col-md-4 col-sm-4">
              <div class="box">
                <div class="frame">'.get_word_mag_image( get_the_ID(), "360x414" ).'
				 <div class="caption"> <img src="'.get_template_directory_uri().'/assets/images/w-img.png" alt="img"> <a href="' . get_permalink() . '" class="btn-more">'.esc_html__('Read More', 'word-mag').'</a> </div>
                </div>
                <div class="text-box">
                  <h2><a href="' . get_permalink() . '">' .mb_substr( get_the_title(), 0, '30' ). '...</a></h2>
                <em>'.esc_html__('Written by ', 'word-mag').get_the_author().'  / <span>'.get_the_category_list( esc_html__( ', ', 'word-mag' ) ).'</span></em> </div>
              </div>
            </div>';
					 }
		   $output .= '	
          </div>
        </div>
      </div>
    </div>
    <!--FEATURED POSTS END--> ';
     return $output;
}


add_shortcode( 'Banner', 'cp_para_banner' );

	   vc_map( array(
		  "name" => __( "Banner", "crunchpress" ),
		  "base" => "Banner",
		  "class" => "",
		  "category" => __( "Crunchpress", "crunchpress"),
		  "params" => array(
			
			 array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Heading", "crunchpress" ),
				"param_name" => "cp_banner_heading",
				"value" => __( "Full Width Image", "crunchpress" ),
			 ),
			
			 array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "About Author", "crunchpress" ),
				"param_name" => "cp_banner_author",
				"value" => "",
			 ),
			  array(
				"type" => "textarea",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Content", "crunchpress" ),
				"param_name" => "cp_banner_content",
				"value" => __( "", "crunchpress" ),
			 ),
			 array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Continue Reading Heading", "crunchpress" ),
				"param_name" => "cp_banner_link_heading",
				"value" => __( "Continue Reading", "crunchpress" ),
			 ),
			  array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Continue Reading URL", "crunchpress" ),
				"param_name" => "cp_banner_link",
				"value" => __( "http://yoururl.com", "crunchpress" ),
			 ),
			 
		   )
	   ) );

	function cp_para_banner($atts, $content = null) {
	$default = array(
		'cp_banner_heading' 	=> 'Full Width Image',
		'cp_banner_author' 	=> base64_decode('Written by Rachel Barkl'),
		'cp_banner_content' 	=> 'Hand-crafted artisanal espresso essential the highest quality remarkable ANA, Helsinki Marylebone intricate. Carefully curated the best Singapore ryokan international quality of life discerning airport.',
		'cp_banner_link_heading' 	=> 'Continue Reading',
		'cp_banner_link' 	=> 'http://yoururl.com',
		
		
	);
	extract(shortcode_atts($default, $atts));
    $output = '
	   <!--PARALLAX SECTION START-->
    <section class="cp-parallax-section-1">
      <div class="holder">
        <div class="caption">
          <div class="inner container">
            <h2>'.$cp_banner_heading.'</h2>
            <em class="italic">'.$cp_banner_author.'</em>
            <p>'.$cp_banner_content.'</p>
            <a href="'.$cp_banner_link.'">'.$cp_banner_link_heading.'</a></div>
        </div>
      </div>
    </section>
    <!--PARALLAX SECTION END--> ';
	
     return $output;
}


function cp_heading($param, $param_value) {
   $dependency = vc_generate_dependencies_attributes($param);
   
				$param_line = '<h1>this is </h1>';
        
   
    return $param_line;
}
add_shortcode_param('post-heading', 'cp_heading');



add_shortcode('Gallery', 'cp_gallery');

vc_map(array(
	"name" => __("Gallery", 'crunchpress'),
	"base" => "Gallery",
	"category" => __('Crunchpress', 'crunchpress'),
	"params" => array(
	 array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Gallery Title", 'crunchpress' ),
				"param_name" => "cp_gallery_title",
				"value" => __( "Gallery", 'crunchpress' ),
			 ),
			 
			 array(
			  "type" => "dropdown",
			  "heading" => __("Columns", "js_composer"),
			  "param_name" => "gallery_col",
			  "value" => array(1, 2, 3),
			  "admin_label" => true,
			  "description" => __("Select columns count.", "js_composer")
			),
			 array(
			  "type" => "dropdown",
			  "heading" => __("Masonary", "js_composer"),
			  "param_name" => "gallery_mas",
			  "value" => array("No", "Yes"),
			  "admin_label" => true,
			  "description" => __("Enable Masonary Effect", "js_composer")
			),
			 array(
            "type" => "attach_images",
            "heading" => __("Images", "crunchpress"),
            "param_name" => "gallery_images",
            "value" => "",
            "description" => __("Select images from media library.", "js_composer")
        ),
	)
));



function cp_gallery( $atts, $content = null ) { // New function parameter $content is added!
   extract(shortcode_atts(array(
		'cp_gallery_title' => 'Gallery',
		'gallery_images' => '',
		'gallery_col' => '2',
		'gallery_mas' => 'No',
		
		
	), $atts));
	global $gallery_masid, $loop_entry;
	if($gallery_col == "1") {
		    $gallery_img_size = "730x500";
			$gallery_img_class = "col-md-12 col-sm-6";
	}
	elseif($gallery_col == "2") {
		    $gallery_img_size = "555x555";
			$gallery_img_class = "col-md-6 col-sm-6";
	}
	elseif($gallery_col == "3") {
		    $gallery_img_size = "350x350";
			$gallery_img_class = "col-md-4 col-sm-6";
	}
    if($gallery_mas  == "Yes") {
		 $gallery_masid = "gallery-grid-1-masonrywrap";
	     $loop_entry = "loop-entry";  
		  $gallery_img_size = "full"; 
	}
	$output = '<section class="gallery-page">
    
	    <ul class="row gallery" id="'.$gallery_masid.'">';
	   $gallery_images = explode( ',', $gallery_images);
		foreach($gallery_images as $attach_id) {
			 $img = wp_get_attachment_image_src($attach_id, $gallery_img_size);
			 $img_full = wp_get_attachment_image_src($attach_id, 'Full');
		 $output .= '<li class="'.$gallery_img_class . $loop_entry.'">
            <div class="box">
              <div class="frame"><img src="'.$img[0].'"/></div>
              <div class="caption">
                <div class="inner">
                  <div class="zoom-row"> <a href="'.$img_full[0].'" class="zoom" data-rel="prettyPhoto[gallery1]" rel="prettyPhoto[gallery1]"><i class="fa fa-search"></i></a> <a href="'.$img_full[0].'" class="link"><i class="fa fa-link"></i></a> </div>
                  <h2>'.get_the_title($attach_id).'</h2>
                  <b>June 15</b> </div>
              </div>
            </div>
          </li>';
		
	}
      $output .= '  
          
        </ul>
      
 
    </section>';
       
	
    return  $output;
}



add_shortcode('Blog', 'cp_blog');

vc_map(array(
	"name" => __("Blog", 'crunchpress'),
	"base" => "Blog",
	"category" => __('Crunchpress', 'crunchpress'),
	"params" => array(
	 array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Gallery Title", 'crunchpress' ),
				"param_name" => "cp_blog_title",
				"value" => __( "Blog", 'crunchpress' ),
			 ),
			 
			  array(
				"type" => "post-cat",
				"heading" => __("Select category", "crunchpress"),
				"param_name" => "cp_blog_cat",
				"description" => __("Select category.", "crunchpress")
              ),
		      array(
			    "type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Number of Posts", 'crunchpress' ),
				"param_name" => "cp_blog_num",
				"value" => __( "8", 'crunchpress' ),
			 ),
			  array(
			    "type" => "dropdown",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Disply Post", 'crunchpress' ),
				"param_name" => "cp_blog_display",
				"value" =>  array(__("Full", "crunchpress") => '', __("Excrept", "crunchpress")),
			 ),
			  array(
			    "type" => "dropdown",
				"holder" => "div",
				"class" => "",
				"heading" => __( "Blog Style", 'crunchpress' ),
				"param_name" => "cp_blog_style",
				"value" =>  array(
				 __("Style-1", "crunchpress") => 'Style-1',
				 __("Style-2", "crunchpress") => 'Style-2',
				 __("Style-3", "crunchpress") => 'Style-3',
				 __("Style-4", "crunchpress") => 'Style-4',
				// __("Style-5", "crunchpress") => 'Style-5',
				),
			 ),
			 
	)
));



function cp_blog( $atts, $content = null ) { // New function parameter $content is added!
   extract(shortcode_atts(array(
		'cp_blog_title' => 'Gallery',
		'cp_blog_cat' => 'All',
		'cp_blog_num' => '8',
		'cp_blog_display' => 'Excrept',
		'cp_blog_style' => 'Style-1',
		
	), $atts));
		
	if ($cp_blog_style == "Style-1") {
	$output = ' <!--POSTS SECTION START-->
    <section class="cp-post-section-1 blog_style_1 blog-posts-wrapper">
      <div class="holder">
        <div class="container">
          <ul id="blog-masonrywrap">';
		   wp_reset_query();
		   		 global $paged, $wp_query;
						if(empty($paged)){
							$paged = (get_query_var('page')) ? get_query_var('page') : 1; 
						}
		             query_posts(array('post_type'=>'post', 'cat'=>$cp_blog_cat, 'paged'=>$paged, 'posts_per_page'=>$cp_blog_num)); 
	         	     while( have_posts() ){ the_post(); 
					 $thumbnail_types = get_post_meta( get_the_ID(), 'post-option-inside-thumbnail-types', true);
           $output .= '
            <li class="loop-entry">
              <div class="box">
                <div class="frame">'.word_mag_blog_thumbnail( get_the_ID(), "554x380" ).'</div>';
				if($thumbnail_types == "Quote"){}else{$output .= '<div class="text-box">
				 <h2><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>
                    <em>'.esc_html__('Written by ', 'word-mag').get_the_author().'  / <span>'.get_the_category_list( esc_html__( ', ', 'word-mag' ) ).'</span></em>
                  <p>'.mb_substr( get_the_excerpt(), 0, '350' ).'...</p>
                  <a href="'.esc_url(get_permalink()).'" class="btn-continue">'.esc_html__('Continue Reading','word-mag').'</a> </div>';}
              $output .= '</div>
            </li>';
					 }
            $output .= '
          </ul>
        </div>
      </div>
    </section>
	<div class="clearfix"></div>
    <!--POSTS SECTION END-->';
	 $output .= word_mag_pagination();
	wp_reset_query();
	$output .= "
	<script>
     //MASONARY BLOG
    function attWorkGrid_1() {
        var options = {
            itemWidth: 555, // Optional min width of a grid item
            autoResize: true, // This will auto-update the layout when the browser window is resized.
            container: $('#blog-masonrywrap'), // Optional, used for some extra CSS styling
            offset: 30, // Optional, the distance between grid items
            flexibleWidth: 555 // Optional, the maximum width of a grid item
        };
        var handler = $('#blog-masonrywrap li');
        handler.wookmark(options);
    }

    jQuery(document).ready(function($) {
        attWorkGrid_1();
    });
    $('#blog-masonrywrap li div div a img').load(function() { // (yasir bhai) Only Change this line if you need to
        attWorkGrid_1();
    });
    </script>";
	}if ($cp_blog_style == "Style-2") { 
	
     $output = '<section class="cp-post-page blog_style_2 blog-posts-wrapper">
      <div class="container">
        <div class="holder"> 
          <!--POST 1 START-->
		  ';
		   wp_reset_query();
					 global $paged, $wp_query;
					 	if(empty($paged)){
							$paged = (get_query_var('page')) ? get_query_var('page') : 1; 
						}
	                 query_posts(array('post_type'=>'post', 'cat'=>$cp_blog_cat, 'paged'=>$paged, 'posts_per_page'=>$cp_blog_num)); 
	         	     while( have_posts() ){ the_post(); 
			 $thumbnail_types = get_post_meta( get_the_ID(), 'post-option-inside-thumbnail-types', true);	 
					
           $output .= '
          <div class="post-box" >
            <div class="post-page-heading">
               <h2><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>
            </div>
			
            <div class="frame">
              <div class="thumb-box">';
			  global $size;
			  $inside_thumbnail_type = get_post_meta(get_the_ID(), 'post-option-inside-thumbnail-types', true);
			  if( $inside_thumbnail_type == "Slider") {
				    $slider_xml = get_post_meta( get_the_ID(), 'post-option-inside-thumbnail-xml', true); 
					
			  	if(!empty($slider_xml)) {	
                    $slider_xml_dom = new DOMDocument();
                    $slider_xml_dom->loadXML($slider_xml);
					$slider_xml = $slider_xml_dom->documentElement;
					
					$i = 0;
					foreach($slider_xml->childNodes as $slider){
					 $i++;
					 	
						$imageid = find_xml_value($slider, 'image');
						if($i == 1 ){
							$word_mag_item_size_new_w = "700";
						    $word_mag_item_size_new_h = "378";
							}
					    elseif($i == 2 ){
							$word_mag_item_size_new_w = "300";
						    $word_mag_item_size_new_h = "378";
							}else{
						    $word_mag_item_size_new_w = "167";
						    $word_mag_item_size_new_h = "108";
							}	
						$thumbnail = wp_get_attachment_image_src( $imageid , $size );
							if( !empty($thumbnail)){
								 $output .= '<a><img style="width:'. $word_mag_item_size_new_w .'px; height:'. $word_mag_item_size_new_h .'px; " src="' .$thumbnail[0].'" width="'. $word_mag_item_size_new_w .'px" height="'. $word_mag_item_size_new_h .'px" alt="no image"/></a>';
							}
							
							}
				         }
				      }else{
					      $output .= word_mag_blog_thumbnail( get_the_ID(), "964x620" );  
				       }
			  
			 $output .= '</div>
            </div>
            <div class="text-box">
			'.mb_substr( get_the_content(), 0, '500' ).'...
			
			<div class="clearfix"></div>
			<em>'.esc_html__('Posted on','word-mag').' '.get_the_date().' '.esc_html__('under','word-mag').' '.get_the_category_list( esc_html__( ', ', 'word-mag' ) ).'</em>
			</div>
          </div>';
					 }
           $output .= '
          
          
        </div>
      </div>
    </section>';
	 $output .= word_mag_pagination();
	wp_reset_query();
	
	}if ($cp_blog_style == "Style-3") { 
	
     $output = '
	<!--SCROLL SECTION START-->
    <div class="cp-scroll-page blog_style_3 blog-posts-wrapper">
      <div id="content-1" class="content">
        <ul>';
		 
		   wp_reset_query();
					 global $paged, $wp_query;
	                 query_posts(array('post_type'=>'post', 'cat'=>$cp_blog_cat, 'paged'=>$paged, 'posts_per_page'=>$cp_blog_num)); 
	         	     while( have_posts() ){ the_post(); 
				  $thumbnail_types = get_post_meta( get_the_ID(), 'post-option-inside-thumbnail-types', true); 
					
           $output .= '
		
          <li class="loop-entry">
            <div class="box">
              <div class="text-box">
                  <h2><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>
               <em>'.esc_html__('Posted on','word-mag').' '.get_the_date().' '.esc_html__('under','word-mag').' '.get_the_category_list( esc_html__( ', ', 'word-mag' ) ).'</em> </div>
              <div class="frame">'.word_mag_blog_thumbnail( get_the_ID(), "361x335" ).'</div>';
				if($thumbnail_types == "Quote"){}else{$output .= '
              <div class="text-box">
                <p>'.mb_substr( get_the_excerpt(), 0, '350' ).'...</p>
              <a href="'.esc_url(get_permalink()).'" class="btn-continue">'.esc_html__('Continue Reading','word-mag').'</a> </div>';
				}
			  $output .= '
            </div>
          </li>';
         
					 }
           $output .= '
        </ul>
      </div>
    </div>
    <!--SCROLL SECTION END--> ';
	
	 $output .= word_mag_pagination();
	wp_reset_query();
	}if ($cp_blog_style == "Style-4") { 
	
     $output = '
	 <section class="theme-4-post blog-posts-wrapper">
      <div class="container">';
		 
		   wp_reset_query();
					 global $paged, $wp_query;
					 	if(empty($paged)){
							$paged = (get_query_var('page')) ? get_query_var('page') : 1; 
						}
	                 query_posts(array('post_type'=>'post', 'cat'=>$cp_blog_cat, 'paged'=>$paged, 'posts_per_page'=>$cp_blog_num)); 
	         	     while( have_posts() ){ the_post(); 
		
		  $thumbnail_types = get_post_meta( get_the_ID(), 'post-option-inside-thumbnail-types', true);
         
           $output .= '
		   <div class="cp-post-box-2">
          <div class="row">
            <div class="col-md-2">
              <div class="left-box"> <strong class="date">'.get_the_date().'<br>
                2015</strong> <em>'.esc_html__('by','word-mag').' '.get_the_author().'<br>
                </em> <span>'.esc_html__('Featured Post','word-mag').'</span> </div>
            </div>
            <div class="col-md-10">
                 <div class="frame">'.word_mag_blog_thumbnail( get_the_ID(), "945x650" ).'</div>';
				if($thumbnail_types == "Quote"){}else{ 
				$output .= '
              <div class="text-box">
                 <h2><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>
                <div class="inner">   <p>'.mb_substr( get_the_excerpt(), 0, '350' ).'...</p>
                  <em>'.esc_html__('Posted on','word-mag').' '.get_the_date().' '.esc_html__('under','word-mag').' '.get_the_category_list( esc_html__( ', ', 'word-mag' ) ).'</em>  <a href="'.esc_url(get_permalink()).'" class="btn-continue">'.esc_html__('Continue Reading','word-mag').'</a> </div>
              </div>';
				}
			   $output .= '
            </div>
          </div>
        </div>
		
         ';
         
					 }
           $output .= '
      </div>
    </div>';
	
	 $output .= word_mag_pagination();
	wp_reset_query();
	}
	
	
    return  $output;
}




function vs_contact_form1_func( $atts, $content = null ) { // New function parameter $content is added!
   extract(shortcode_atts(array(
		'title' => 'Contact Us',
		'contact_form' => '',
		'admin_email' => '',
		'css_animation' => '',
		'contact_address' => 'PO Box 4321 Lorum Street, New York City, United States Amercia.',
		'contact_phone' => '+61 5 6346 2281',
		'contact_fax' => '+61 5 6346 2281',
		'contact_heading' => 'Stay <span>In Touch</span>',
		'contact_email' => 'info@company.com',
		'contact_dis' => 'Donec in elit vitae diam faucibus suscipit in tortor. Morbi eget rutrum vel et diam.',
		
	), $atts));
	$fields = json_decode(str_replace('``', '"', $contact_form));

	$css_class =  '';
	$css_class .= $css_animation;
	
    $id = rand(1, 100);
	$output  = '';
	$output  .= '
	
	<div class="row">
          <div class="col-md-5">
            <div class="addres-box">
              <h2>'.$contact_heading.'</h2>
              <p>'.$contact_dis.'</p>
              <address>
              <ul>
                <li><i class="fa fa-map-marker"></i>'.$contact_address.'</li>
                <li><i class="fa fa-phone"></i>'.$contact_phone.'</li>
                <li><i class="fa fa-fax"></i>'.$contact_fax.'</li>
                <li><i class="fa fa-envelope"></i><a href="mailto:'.$contact_email.'">'.$contact_email.'</a></li>
              </ul>
              </address>
            </div>
          </div>
          <div class="col-md-7">
            <div class="form-box">
              <h2>Send <span>An Email</span></h2>
              <form action="#">
                <div class="row">
                  <div class="col-md-6">
                    <input name="" type="text" placeholder="name (required)" required="">
                  </div>
                  <div class="col-md-6">
                    <input name="" type="text" placeholder="email (required)" required="">
                  </div>
                  <div class="col-md-12">
                    <input name="" type="text" placeholder="subject" required="">
                  </div>
                  <div class="col-md-12">
                    <textarea name="" cols="10" rows="10" placeholder="message"></textarea>
                  </div>
                  <div class="col-md-12">
                    <input name="" type="submit" value="Submit">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
	
	';	

 
    return $output;
}
add_shortcode('vs_contact_form1', 'vs_contact_form1_func');


vc_map(array(
	"name" => __("Contact Form", 'crunchpress'),
	"base" => "vs_contact_form1",
	"category" => __('Crunchpress', 'crunchpress'),
	"params" => array(
	
		array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", "crunchpress"),
         "param_name" => "title",
         "value" => __("CONTACT FORM","crunchpress"),
         "description" => __("Contact Form Title.","crunchpress")
        ),
		
		
		array(
			"type" => "textfield",
			"heading" => __('Contact form e-mail', 'crunchpress'),
			"param_name" => "admin_email",
			"value" => '',//get_option('admin_email'),
			"description" => __("You can specify custom e-mail for this form(WARNING: this e-mail will be visible in DOM)", "crunchpress")
		),
		
		array(
			"type" => "textfield",
			"heading" => __('Stay In Tuch', 'crunchpress'),
			"param_name" => "contact_heading",
			"value" => 'Stay <span>In Touch</span>',//get_option('admin_email'),
		),
		array(
			"type" => "textfield",
			"heading" => __('Address', 'crunchpress'),
			"param_name" => "contact_dis",
			"value" => 'Donec in elit vitae diam faucibus suscipit in tortor. Morbi eget rutrum vel et diam.',//get_option('admin_email'),
		),
		array(
			"type" => "textfield",
			"heading" => __('Address', 'crunchpress'),
			"param_name" => "contact_address",
			"value" => 'PO Box 4321 Lorum Street, New York City, United States Amercia.',//get_option('admin_email'),
		),
		array(
			"type" => "textfield",
			"heading" => __('Phone Number', 'crunchpress'),
			"param_name" => "contact_phone",
			"value" => '+61 5 6346 2281',//get_option('admin_email'),
		),
			array(
			"type" => "textfield",
			"heading" => __('Fax Number', 'crunchpress'),
			"param_name" => "contact_fax",
			"value" => '+61 5 6346 2281',//get_option('admin_email'),
		),
			array(
			"type" => "textfield",
			"heading" => __('Email', 'crunchpress'),
			"param_name" => "contact_email",
			"value" => 'info@company.com',//get_option('admin_email'),
		),
		
		
	)
));





//////////////////////////////vc_contact_information////////////////////////////////////////////////////////////////////////////////
function vc_contact_information_func( $atts, $content = null ) { // New function parameter $content is added!
   extract( shortcode_atts( array(
      'title' => 'Address',
      'map_address' => '',
      'map_markers' => '',
      'image_markers' => '',
    ), $atts ) );
    global $css_animation;
    $width_class = '';
	$css_class =  '';
	$css_class .= $css_animation;
	
	$img_id = preg_replace('/[^\d]/', '', $image_markers);
    $map_thumbnail = wpb_getImageBySize(array( 'attach_id' => $img_id, 'thumb_size' => 'latest-post', 'class' => '' ));
	$map_thumbnail = $map_thumbnail['p_img_large'][0];  
    
	$id = rand(1, 100);
	
	$output  = '<div class="contact-info'.$id.' '. $css_class .'">
	     <div class="page-content contact-info">
		    <div id="map-canvas"></div>';

						
	$output .=  '</div></div> ';
                   
 
 
	$output .=  '<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
	<script  type="text/javascript" >
		function initialize() {
		  var myLatlng = new google.maps.LatLng('. $map_address .');
		  var myLatlng2 = new google.maps.LatLng('. $map_markers .');
		  var image = "'. $map_thumbnail .'";
		  
		  
		  var mapOptions = {
			zoom: 14,
			center: myLatlng,
			mapTypeControl: false,
			scrollwheel: false,
			mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
			navigationControl: false,
			navigationControlOptions: {style: google.maps.NavigationControlStyle.SMALL},
			mapTypeId: google.maps.MapTypeId.ROADMAP
		  };
		  var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);

		  var marker = new google.maps.Marker({
			  position: myLatlng2,
			  map: map,
			  icon: image
		  });
		}

		google.maps.event.addDomListener(window, "load", initialize);

    </script>
	<style type="text/css" >
			  body #map-canvas img {
				max-width: none !important;
			  }
			  #map-canvas {
				height: 500px;
				margin: 0px;
				padding: 0px
			  }
    </style>';
	
	
 
   return $output;
}
add_shortcode('vc_contact_information', 'vc_contact_information_func');

vc_map( array(
   "name" => __("Contact Information", 'crunchpress'),
   "base" => "vc_contact_information",
    "wrapper_class" => "clearfix",
	"category" => __('Crunchpress', 'crunchpress'),
	"description" => __('Contact Map', 'crunchpress'),
   "params" => array(
   
		array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", "crunchpress"),
         "param_name" => "title",
         "value" => __("CONTACT INFORMATION","crunchpress"),
         "description" => __("Block title.","crunchpress")
        ),
		
		array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Google Map Address (51.451955,-0.055755)", "crunchpress"),
         "param_name" => "map_address",
         "value" => "",
         "description" => __("Google Map Address.","crunchpress")
        ),
		
		array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Google Map Markers", "crunchpress"),
         "param_name" => "map_markers",
         "value" => "",
         "description" => ""
        ),
		
		array(
		  "type" => "attach_image",
		  "heading" => __("Marker image", "crunchpress"),
		  "param_name" => "image_markers",
		  "value" => "",
		  "description" => __("Select marker image from media library.", "crunchpress")
		),
		
	
   )
) );


add_shortcode('About', 'cp_about');

vc_map(array(
	"name" => __("About", 'crunchpress'),
	"base" => "About",
	"category" => __('Crunchpress', 'crunchpress'),
	"params" => array(
	         array(
	           "type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => __( "About Title", 'crunchpress' ),
				"param_name" => "cp_about_title",
				"value" => __( "Hello <span>Guys!</span>", 'crunchpress' ),
			 ),
			 
			 
	    array(
		  "type" => "attach_image",
		  "heading" => __("Author image", "crunchpress"),
		  "param_name" => "author_image",
		  "value" => "",
		  "description" => __("Select image from media library.", "crunchpress")
		),
		
		array(  
	        "type" => "textarea_raw_html",
			"holder" => "div",
			"heading" => __("Discription", "crunchpress"),
			"param_name" => "about_disc",
			"value" => base64_encode('<p>Donec in elit vitae diam faucibus suscipit ac in tortor.</p>
      <p>Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu. Vivamus sodales semper sollicitudin. Aliquam libero enim, ultricies sit amet turpis et, blandit tincidunt erat. Integer scelerisque erat a condimentum tempus. Sed ut convallis lorem. Proin porttitor eros velit, non lacinia lacus gravida non.</p>
      <p>Aenean eu felis felis. Ut vel arcu accumsan, vestibulum tellus sit amet, dignissim odio...</p>
      <strong class="name">John Doe</strong>
      <div class="btn-box">
      <a href="#" class="btn-download"><i class="fa fa-cloud-download"></i>Download</a>
      <a href="#" class="btn-contact"><i class="fa fa-envelope"></i>Contact Me! </a>
      </div>'),
			"description" => __("Enter your HTML content.", "js_composer")
		),
		
		array(  
	        "type" => "textarea_raw_html",
			"holder" => "div",
			"heading" => __("Contact Details", "crunchpress"),
			"param_name" => "about_contact",
			"value" => base64_encode('<ul>
			  <li>Lorum Ipsum</li>
			  <li>+123 456 789</li>
			  <li><a href="mailto:">Info@dummy.com</a></li>
			  <li><a href="#">www.dummy.com</a></li>
			  <li>321 Lorum, NY, US America.</li>
			  </ul>'),
			"description" => __("Enter your HTML content.", "js_composer")
		),
	   
	   
		
	)
));



function cp_about( $atts, $content = null ) { // New function parameter $content is added!
   extract(shortcode_atts(array(
		'cp_about_title' => 'Hello <span>Guys!</span>',
		'author_image' => '',
		'about_disc' => base64_encode('<p>Donec in elit vitae diam faucibus suscipit ac in tortor.</p>
      <p>Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu. Vivamus sodales semper sollicitudin. Aliquam libero enim, ultricies sit amet turpis et, blandit tincidunt erat. Integer scelerisque erat a condimentum tempus. Sed ut convallis lorem. Proin porttitor eros velit, non lacinia lacus gravida non.</p>
      <p>Aenean eu felis felis. Ut vel arcu accumsan, vestibulum tellus sit amet, dignissim odio...</p>
      <strong class="name">John Doe</strong>
      <div class="btn-box">
      <a href="#" class="btn-download"><i class="fa fa-cloud-download"></i>Download</a>
      <a href="#" class="btn-contact"><i class="fa fa-envelope"></i>Contact Me! </a>
      </div>'),
	  'about_contact' => base64_encode('<ul>
			  <li>Lorum Ipsum</li>
			  <li>+123 456 789</li>
			  <li><a href="mailto:">Info@dummy.com</a></li>
			  <li><a href="#">www.dummy.com</a></li>
			  <li>321 Lorum, NY, US America.</li>
			  </ul>'),
	  
	  
	
	), $atts));
	

	$img = wp_get_attachment_image_src($author_image, "large");
	
	$output = '
	
	<section class="cp-about-1">
      <div class="cp-about-row-3">
      <div class="container-fluid">
      <div class="row">
      <div class="col-md-6">
      <div class="left-box">
      <h2>'.$cp_about_title.'</h2>
	  '. rawurldecode(base64_decode(strip_tags($about_disc))).'
    
      </div>
      <address>
      '. rawurldecode(base64_decode(strip_tags($about_contact))).'
      </address>
      </div>
      <div class="col-md-6"><div class="frame"><a href="#"><img src="'.$img[0].'" alt="img"></a></div></div>
      </div>
      </div>
      </div>
      
       <!--Services Row Start-->
      <div class="cp-services-holder">
        <div class="container">
          <!--Services Inner Start-->
          <div class="cp-services-inner">
             <!-- Nav tabs -->
              <ul class="nav nav-tabs" role="tablist">
                <li class="active">
                  <a href="#tab-01" aria-controls="tab-01" role="tab" data-toggle="tab"><i class="fa fa-book"></i> <span>Education</span></a>
                </li>
                <li>
                  <a href="#tab-02" aria-controls="tab-02" role="tab" data-toggle="tab"><i class="fa fa-briefcase"></i> <span>Employment</span></a>
                </li>
                <li>
                  <a href="#tab-03" aria-controls="tab-03" role="tab" data-toggle="tab"><i class="fa fa-folder-open"></i><span>Services</span></a>
                </li>
              </ul> <!-- Nav tabs End -->

              <!-- Tab panes -->
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="tab-01">
                  <div class="row">
                    <div class="col-md-5 col-sm-6">
                      <div class="cp-services-text">
                        <h4>Our Education System</h4>
                        <p>Donec in elit vitae diam faucibus suscipit ac in tortor. Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu. </p>

                        <p>Vivamus sodales semper sollicitudin. Aliquam libero enim, ultricies sit amet turpis et, blandit tincidunt erat. </p>

                        <!--Services Listed Start-->
                        <ul class="cp-services-listed">
                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-ship"></i>
                              </span>
                              <div class="cp-text">
                                <h5>World Wide Ship</h5>
                                <span>All Orders Over $90.00</span>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-usd"></i>
                              </span>
                              <div class="cp-text">
                                <h5>Money Back</h5>
                                <span>100% Money Back - 30 Days</span>
                              </div>
                            </div>
                          </li>

                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-phone"></i>
                              </span>
                              <div class="cp-text">
                                <h5>Best Support</h5>
                                <span>Fast & Pro 24/7</span>
                              </div>
                            </div>

                          </li>
                        </ul><!--Services Listed End-->
                      </div>
                    </div>
                    <div class="col-md-7 col-sm-6">
                      <figure class="cp-thumb">
                        <img src="'.ASSETS_FRONT.'/images/services-img.jpg" alt="">
                      </figure>
                    </div>
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="tab-02">
                  <div class="row">
                     <div class="col-md-7 col-sm-6">
                      <figure class="cp-thumb">
                        <img src="'.ASSETS_FRONT.'/images/services-img.jpg" alt="">
                      </figure>
                    </div>
                    <div class="col-md-5 col-sm-6">
                      <div class="cp-services-text">
                        <h4>Employment</h4>
                        <p>Donec in elit vitae diam faucibus suscipit ac in tortor. Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu. </p>

                        <p>Vivamus sodales semper sollicitudin. Aliquam libero enim, ultricies sit amet turpis et, blandit tincidunt erat. </p>

                        <!--Services Listed Start-->
                        <ul class="cp-services-listed">
                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-ship"></i>
                              </span>
                              <div class="cp-text">
                                <h5>World Wide Ship</h5>
                                <span>All Orders Over $90.00</span>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-usd"></i>
                              </span>
                              <div class="cp-text">
                                <h5>Money Back</h5>
                                <span>100% Money Back - 30 Days</span>
                              </div>
                            </div>
                          </li>

                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-phone"></i>
                              </span>
                              <div class="cp-text">
                                <h5>Best Support</h5>
                                <span>Fast & Pro 24/7</span>
                              </div>
                            </div>

                          </li>
                        </ul><!--Services Listed End-->
                      </div>
                    </div>
                   
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="tab-03">
                  <div class="row">
                    <div class="col-md-12 col-sm-12">
                      <div class="cp-services-text">
                       <p>Donec in elit vitae diam faucibus suscipit ac in tortor. Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu. Vivamus sodales semper sollicitudin. Aliquam libero enim, ultricies sit amet turpis et, blandit tincidunt erat.</p>

                        <p>Vivamus sodales semper sollicitudin. Aliquam libero enim, ultricies sit amet turpis et, blandit tincidunt erat. </p>

                        <!--Services Listed Start-->
                        <ul class="cp-services-listed cp-services-listed2">
                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-ship"></i>
                              </span>
                              <div class="cp-text">
                                <h5>World Wide Ship</h5>
                                <span>All Orders Over $90.00</span>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-usd"></i>
                              </span>
                              <div class="cp-text">
                                <h5>Money Back</h5>
                                <span>100% Money Back - 30 Days</span>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-phone"></i>
                              </span>
                              <div class="cp-text">
                                <h5>Best Support</h5>
                                <span>Fast & Pro 24/7</span>
                              </div>
                            </div>
                          </li>

                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-ship"></i>
                              </span>
                              <div class="cp-text">
                                <h5>World Wide Ship</h5>
                                <span>All Orders Over $90.00</span>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-usd"></i>
                              </span>
                              <div class="cp-text">
                                <h5>Money Back</h5>
                                <span>100% Money Back - 30 Days</span>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class="inner-holder">
                              <span class="cp-icon">
                                <i class="fa fa-phone"></i>
                              </span>
                              <div class="cp-text">
                                <h5>Best Support</h5>
                                <span>Fast & Pro 24/7</span>
                              </div>
                            </div>
                          </li>

                        </ul><!--Services Listed End-->
                      </div>
                    </div>
                   
                  </div>
                </div>
              </div>
          </div><!--Services Inner End-->
        </div>
      </div><!--Services Row End--> ';
	  
	      
	  
	   $output.= ' <div class="cp-authors">
        <div class="container">
          <h2>Our Authors</h2>
          <div class="row">';
 	 wp_reset_query();
 		 global $paged, $wp_query, $cp_blog_cat, $cp_blog_num;
 			 query_posts(array('post_type'=>'team', 'cat'=>$cp_blog_cat, 'paged'=>$paged, 'posts_per_page'=>4));
  				 while( have_posts() ){ the_post(); 
 					 $output.= '<div class="col-md-3">
              <div class="box">
                <div class="frame">'.get_word_mag_image( get_the_ID(), "250x330" ).'</div>
                <div class="caption"> <strong class="title">' . get_the_title() . '</strong> <em>'.get_post_meta( get_the_ID(), 'team_options_team_options_position', true ).'</em>
                  <div class="social-icons">
                    <ul>
                      <li><a href="'.get_post_meta( get_the_ID(), 'team_options_team_options_facebook', true ).'"><i class="fa fa-facebook-f"></i></a></li>
                      <li><a href="'.get_post_meta( get_the_ID(), 'team_options_team_options_twitter', true ).'"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="'.get_post_meta( get_the_ID(), 'team_options_team_options_linkedin', true ).'"><i class="fa fa-google-plus"></i></a></li>
                      <li><a href="'.get_post_meta( get_the_ID(), 'team_options_team_options_google_', true ).'"><i class="fa fa-linkedin"></i></a></li>
                      <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                      <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>';			
				 }
			
 $output.= '</div>
        </div>
      </div>
	 
	  <div class="cleafix"></div>
	   <div class="cp-brands">
        <div class="container">
          <div class="brands-slider">
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-1.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-2.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-3.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-4.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-1.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-2.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-3.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-1.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-2.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-3.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-4.jpg" alt="img"></a></div>
          </div>
        </div>
      </div>
	  
    </section>';
	
	
 		
    return  $output;
}


/*/////////////////////////////
 VC Shortcode for About Us 2
 /////////////////////////////*/ 
add_shortcode('about_us_style_2', 'about_us_style_2' );
vc_map( array( 
    'name' => __('About Us 2', 'word-mag' ),
	   'base' => 'about_us_style_2',
	   'class' => '',
	   'category' => __( 'Crunchpress', 'word-mag'),
	   'params' => array(
			    array(
				'heading' => __( 'Heading', 'word-mag' ),
				'param_name' => 'about_us_2_heading',
				'type' => 'textfield',
				'value' => 'About Word Mag',
				'holder' => 'div',
				 ),
			    array(
				'heading' => __( 'About Us Content', 'word-mag' ),
				'param_name' => 'about_us_2_content',
				'type' => 'textarea',
				'value' => 'Donec in elit vitae diam faucibus suscipit ac in tortor.  Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu. Vivamus sodales semper sollicitudin. Aliquam libero enim, ultricies sit amet turpis et, blandit tincidunt erat. Integer scelerisque erat a condimentum tempus. Sed ut convallis lorem. Proin porttitor eros velit, non lacinia lacus gravida non.  Aenean eu felis felis. Ut vel arcu accumsan, vestibulum tellus sit amet, dignissim odio.',
				'holder' => 'div',
				 ),
			    array(
				'heading' => __( 'Display Services', 'word-mag' ),
				'param_name' => 'about_us_2_display_service',
				'type' => 'radio',
				'value' => 'Services',
				'holder' => 'div',
				'options' => array(
				'' => __( 'Please enter your desired value.', 'word-mag' ),
				),
				 ),
    )
  )
);
function about_us_style_2($atts, $content = null) {
$default = array(
				'about_us_2_heading' => 'About Word Mag',
				'about_us_2_content' => 'Donec in elit vitae diam faucibus suscipit ac in tortor.  Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu. Vivamus sodales semper sollicitudin. Aliquam libero enim, ultricies sit amet turpis et, blandit tincidunt erat. Integer scelerisque erat a condimentum tempus. Sed ut convallis lorem. Proin porttitor eros velit, non lacinia lacus gravida non.  Aenean eu felis felis. Ut vel arcu accumsan, vestibulum tellus sit amet, dignissim odio.',
				'about_us_2_display_service' => 'Services',
);
extract(shortcode_atts($default, $atts));
 $output = ' <!--ABOUT 1 PAGE START-->
    <section class="cp-about-1">
      <div class="about-row-2">
        <div class="container">
          <div class="row">
            <div class="col-md-5">
              <h2>About <span>Word Mag</span></h2>
              <p>Donec in elit vitae diam faucibus suscipit ac in tortor.</p>
              <p>Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu. Vivamus sodales semper sollicitudin. Aliquam libero enim, ultricies sit amet turpis et, blandit tincidunt erat. Integer scelerisque erat a condimentum tempus. Sed ut convallis lorem. Proin porttitor eros velit, non lacinia lacus gravida non.</p>
              <p>Aenean eu felis felis. Ut vel arcu accumsan, vestibulum tellus sit amet, dignissim odio.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="cp-services">
        <div class="container">
          <h2>Services</h2>
          <div class="row">
            <div class="col-md-4">
              <div class="box"> <i class="fa fa-paint-brush"></i> <strong class="title">Designs &amp; Interfaces</strong>
                <p>Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu.</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="box"> <i class="fa fa-cog"></i> <strong class="title">Highly Customizable</strong>
                <p>Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu.</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="box"> <i class="fa fa-tablet"></i> <strong class="title">Responsive Design</strong>
                <p>Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu.</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="box"> <i class="fa fa-clock-o"></i> <strong class="title">Optimised for Speed</strong>
                <p>Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu.</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="box"> <i class="fa fa-recycle"></i> <strong class="title">Features &amp; Plugins</strong>
                <p>Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu.</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="box"> <i class="fa fa-support"></i> <strong class="title">Dedicated Support</strong>
                <p>Morbi eget erat sit amet velit interdum rutrum vel et diam. Sed in consectetur nisl. In non tellus consectetur, porttitor urna a, hendrerit arcu.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="cp-subscribe">
        <div class="container">
          <div class="holder">
            <h2>Subscribe <span>Our Newsletter</span></h2>
            <form action="#" method="post">
              <input name="email" type="text" placeholder="email" required>
              <input name="submit" type="submit" value="Submit">
            </form>
            <p>Morbi eget erat sit - amet velit interdum rutrum vel et </p>
          </div>
        </div>
      </div>
      <div class="cp-authors">
        <div class="container">
          <h2>Our Authors</h2>
          <div class="row">
            <div class="col-md-3">
              <div class="box">
                <div class="frame"><a href="#"><img src="'.ASSETS_FRONT.'/images/authors-img-1.png" alt="img"></a></div>
                <div class="caption"> <strong class="title">David Anderson</strong> <em>Senior Author</em>
                  <div class="social-icons">
                    <ul>
                      <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                      <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                      <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                      <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="box">
                <div class="frame"><a href="#"><img src="'.ASSETS_FRONT.'/images/authors-img-2.png" alt="img"></a></div>
                <div class="caption"> <strong class="title">David Anderson</strong> <em>Senior Author</em>
                  <div class="social-icons">
                    <ul>
                      <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                      <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                      <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                      <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="box">
                <div class="frame"><a href="#"><img src="'.ASSETS_FRONT.'/images/authors-img-3.png" alt="img"></a></div>
                <div class="caption"> <strong class="title">David Anderson</strong> <em>Senior Author</em>
                  <div class="social-icons">
                    <ul>
                      <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                      <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                      <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                      <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="box">
                <div class="frame"><a href="#"><img src="'.ASSETS_FRONT.'/images/authors-img-4.png" alt="img"></a></div>
                <div class="caption"> <strong class="title">David Anderson</strong> <em>Senior Author</em>
                  <div class="social-icons">
                    <ul>
                      <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                      <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                      <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                      <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="cp-brands">
        <div class="container">
          <div class="brands-slider">
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-1.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-2.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-3.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-4.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-1.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-2.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-3.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-1.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-2.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-3.jpg" alt="img"></a></div>
            <div class="slide"><a href="#"><img src="'.ASSETS_FRONT.'/images/brands/brand-img-4.jpg" alt="img"></a></div>
          </div>
        </div>
      </div>
    </section>
    <!--ABOUT A PAGE END--> ';
 return $output;
 }


/*/////////////////////////////
 VC Shortcode for About Us 3
 /////////////////////////////*/ 
add_shortcode('about_us_3', 'about_us_3' );
vc_map( array( 
    'name' => __('About Us 3', 'word-mag' ),
	   'base' => 'about_us_3',
	   'class' => '',
	   'category' => __( 'Crunchpress', 'word-mag'),
	   'params' => array(
			    array(
				'heading' => __( 'About Us Heading', 'word-mag' ),
				'param_name' => 'about_us_3_heading',
				'type' => 'textfield',
				'value' => 'Mark Anderson',
				'holder' => 'div',
				 ),
			    array(
				'heading' => __( 'Sub Heading', 'word-mag' ),
				'param_name' => 'about_us_3_sub_heading',
				'type' => 'textfield',
				'value' => 'Article Writer',
				'holder' => 'div',
				 ),
			    array(
				'heading' => __( 'Content', 'word-mag' ),
				'param_name' => 'about_us_3_sub_content',
				'type' => 'textarea',
				'value' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dolor nisl, interdum ac enim consectetur, convallis facilisis metus. Nam ac bibendum nisl. Vivamus nec neque pharetra, blandit lorem et, feugiat sapien. Integer elementum imperdiet imperdiet. Phasellus iaculis nec sapien lobortis tempus. Vestibulum tellus lacus, condimentum ac arcu sit amet, suscipit ornare ex. In blandit sed augue eget tristique.  Quisque porttitor rhoncus orci quis tincidunt. Nunc fringilla, nisl id sollicitudin semper, velit dolor congue ex, non maximus est elit quis odio. Praesent molestie odio eu aliquet sagittis. Curabitur et tempor nibh.  Duis leo nibh, vulputate ut sagittis vel, dignissim ac augue. Donec tristique eu diam non tincidunt. Sed ac erat eget sem egestas finibus feugiat sit amet dui. ',
				'holder' => 'div',
				 ),
    )
  )
);
function about_us_3($atts, $content = null) {
$default = array(
				'about_us_3_heading' => 'Mark Anderson',
				'about_us_3_sub_heading' => 'Article Writer',
				'about_us_3_sub_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dolor nisl, interdum ac enim consectetur, convallis facilisis metus. Nam ac bibendum nisl. Vivamus nec neque pharetra, blandit lorem et, feugiat sapien. Integer elementum imperdiet imperdiet. Phasellus iaculis nec sapien lobortis tempus. Vestibulum tellus lacus, condimentum ac arcu sit amet, suscipit ornare ex. In blandit sed augue eget tristique.  Quisque porttitor rhoncus orci quis tincidunt. Nunc fringilla, nisl id sollicitudin semper, velit dolor congue ex, non maximus est elit quis odio. Praesent molestie odio eu aliquet sagittis. Curabitur et tempor nibh.  Duis leo nibh, vulputate ut sagittis vel, dignissim ac augue. Donec tristique eu diam non tincidunt. Sed ac erat eget sem egestas finibus feugiat sit amet dui. ',
);
extract(shortcode_atts($default, $atts));
 $output = '<!--ABOUT 1 PAGE START-->
    <section class="cp-about-1">
      <div class="container">
        <div class="about-text-row">
          <div class="row">
            <div class="col-md-5">
              <div class="left-box">
                <div class="frame"><a href="#"><img src="'.ASSETS_FRONT.'/images/about/about-img-1.jpg" alt="img"></a></div>
                <div class="about-social">
                  <ul>
                    <li class="color-1"><a href="#"><i class="fa fa-facebook-f"></i></a><a href="#" class="btn-like">Like</a></li>
                    <li class="color-2"><a href="#"><i class="fa fa-twitter"></i></a><a href="#" class="btn-like">Follow</a></li>
                    <li class="color-3"><a href="#"><i class="fa fa-rss"></i></a><a href="#" class="btn-like">Join</a></li>
                    <li class="color-4"><a href="#"><i class="fa fa-youtube"></i></a><a href="#" class="btn-like">Subscribe</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-7">
              <div class="text-box">
                <h2>Mark <span>Anderson</span></h2>
                <span class="title">Article Writer</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dolor nisl, interdum ac enim consectetur, convallis facilisis metus. Nam ac bibendum nisl. Vivamus nec neque pharetra, blandit lorem et, feugiat sapien. Integer elementum imperdiet imperdiet. Phasellus iaculis nec sapien lobortis tempus. Vestibulum tellus lacus, condimentum ac arcu sit amet, suscipit ornare ex. In blandit sed augue eget tristique.</p>
                <p>Quisque porttitor rhoncus orci quis tincidunt. Nunc fringilla, nisl id sollicitudin semper, velit dolor congue ex, non maximus est elit quis odio. Praesent molestie odio eu aliquet sagittis. Curabitur et tempor nibh.</p>
                <p>Duis leo nibh, vulputate ut sagittis vel, dignissim ac augue. Donec tristique eu diam non tincidunt. Sed ac erat eget sem egestas finibus feugiat sit amet dui. </p>
                <strong class="name">Mark Anderson</strong> </div>
            </div>
          </div>
        </div>
        <div class="cp-calender-row">
          <h2>Post Calender</h2>
          <div class="calender-box">
            <div class="event-calender">
              <div id="calendar"></div>
            </div>
          </div>
        </div>
        <div class="cp-popular-post">
          <h2>Popular Posts</h2>
          <div class="row">
            <div class="col-md-4">
              <div class="box">
                <div class="frame"><a href="#"><img src="'.ASSETS_FRONT.'/images/about/popular-post-img-1.jpg" alt="img"></a></div>
                <div class="text-box">
                  <h2><a href="#">Happiness <span>in those<br>
                    wheels, forever!</span></a></h2>
                  <a href="#" class="btn-continue">Continue Reading</a> </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="box">
                <div class="frame"><a href="#"><img src="'.ASSETS_FRONT.'/images/about/popular-post-img-2.jpg" alt="img"></a></div>
                <div class="text-box">
                  <h2><a href="#">Let’s have <span>in those<br>
                    a moment
                    of Slience. </span></a></h2>
                  <a href="#" class="btn-continue">Continue Reading</a> </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="box">
                <div class="frame"><a href="#"><img src="'.ASSETS_FRONT.'/images/about/popular-post-img-3.jpg" alt="img"></a></div>
                <div class="text-box">
                  <h2><a href="#">Most inspiring <span>in those<br>
                    Health &amp; Fitness Mantras</span></a></h2>
                  <a href="#" class="btn-continue">Continue Reading</a> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="share-idea-row">
        <div class="container">
          <form action="#">
            <strong class="title">Share Your Idea</strong>
            <h2>Contact <span>With me</span></h2>
            <div class="row">
              <div class="col-md-6">
                <input name="" type="text" placeholder="name" required>
              </div>
              <div class="col-md-6">
                <input name="" type="text" placeholder="email" required>
              </div>
              <div class="col-md-12">
                <textarea name="" cols="10" rows="10" placeholder="detail"></textarea>
              </div>
              <div class="col-md-12">
                <input name="" type="submit" value="Submit">
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="cp-milestones">
        <div class="container"> <strong class="title">My Milestones</strong>
          <div class="row">
            <div class="col-md-3">
              <div class="box"> <strong class="number counter">2734</strong> <span>Active Articles</span> </div>
            </div>
            <div class="col-md-3">
              <div class="box"> <strong class="number counter">77113</strong> <span>Likes</span> </div>
            </div>
            <div class="col-md-3">
              <div class="box"> <strong class="number counter">256</strong> <span>Unique Members</span> </div>
            </div>
            <div class="col-md-3">
              <div class="box"> <strong class="number counter">8</strong> <span>Years Of Existence</span> </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--ABOUT A PAGE END--> ';
 return $output;
 }
